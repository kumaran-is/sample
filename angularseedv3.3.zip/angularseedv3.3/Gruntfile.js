/*grutnfile*/
"use strict";

module.exports = function(grunt) {
  // automatically load all  the grunt tasks matching the `grunt-*` pattern
  require('load-grunt-tasks')(grunt);
  //Displays the elapsed execution time of grunt tasks when done
  // Time how long each tasks take. Can help when optimizing build times
  require('time-grunt')(grunt);

  var path = require('path');
 
   //allows to break up large Gruntfile config  into several individual task files.
  require('load-grunt-config')(grunt, {
    configPath: path.join(process.cwd(), 'build/gruntTasks'), //path to task json files, defaults to grunt dir
    init: true //auto grunt.initConfig
  });

  // notification when files are edited
  grunt.event.on('watch', function(action, filepath, target) {
    grunt.log.writeln(target + ': ' + filepath + ' has ' + action);
  });

  //loading the Jenkins plugin
  grunt.loadNpmTasks('grunt-jenkins');

  // Tell Grunt to register our custom tasks
  grunt.registerTask(
    'default',
    'Basic build for development purpose that copies all the source files to dist directory',
    [ 'clean:build','copy:vendor','copy:scripts','copy:html','copy:partials',
      'copy:stylesheets','copy:images','copy:favicon','copy:fonts','replace:defaultCacheBustVer']
  );

  grunt.registerTask(
    'server',
    'Start static web server "nodejs connect middleware",watch for file changes and enables live reload of changes to browser',
    [ 'connect','watch']
  );

  grunt.registerTask(
   'reports',
   'Scans source code to generate quality reports',
    ['clean:reports','mkdir:jscpdreports','concurrent:staticCodeAnalyzer',
    'concurrent:htmlStaticValidators','concurrent:qualityReports',
     'concurrent:jsdocs','concurrent:perfMetrics']
  );

  grunt.registerTask(
   'precompress',
   'Precompressing (Gzip or Deflate) static files like js,css and html',
    ['compress','clean:gzstylesheets','clean:gzscripts','clean:gzhtml','clean:gzvendor']
  );

  grunt.registerTask(
    'unit-test',
    'Execute unit testing, code coverage & test reports using Jasmine & Karma',
    [ 'clean:unittestreports','karma']
  );

  grunt.registerTask(
    'e2e-test',
    'Execute E2E testing & generates test reports using Protractor',
    [ 'clean:e2etestreports','mkdir:e2etestxmlreports','protractor']
  );

  grunt.registerTask(
    'e2e-test-coverage',
    'Execute E2E testing, generates coverage and test reports using protractor',
    ['clean:instrumented','clean:e2ecoveragereports','mkdir:e2ecoveragexmlreports','instrument',
    'copy:coverageE2E','protractor_coverage','makeReport']
  );

  grunt.registerTask(
    'test',
    'Execute both unit testing and E2E testing with code coverage using Jasmine, Karma and Protractor',
    [ 'unit-test','e2e-test','e2e-test-coverage']
  );

  grunt.registerTask(
   'base-build',
   'Base E2E integration build for other  environments - Dev-int,Nightly, QA & Production',
    [ 'clean:build','copy:vendor','copy:scripts','copy:html','copy:favicon','copy:fonts','useminPrepare','uncss',
      'autoprefixer','htmlmin:partials','cssmin','requirejs','uglify','usemin','dom_munger:release',
      'htmlmin:index','clean:scripts','clean:stylesheets','imagemin','manifest']
  );

  grunt.registerTask(
      'on-commit',
      'On every file commit,executes default build and unit testing',
      [ 'default','unit-test']
  );

  grunt.registerTask(
    'dev-int',
    'Development integration build for development integration  environment',
    [ 'base-build','replace:devCacheBustVer']
  );

  grunt.registerTask(
   'nightly-base',
   'Base Build for nightly build',
    [ 'base-build','replace:releaseCacheBustVer']
  );

  grunt.registerTask(
   'nightly',
   'Development Integration Build for development integration environment',
    ['nightly-base','reports','test']
  );

  grunt.registerTask(
    'qa',
    'Build for QA release',
    ['ngtemplates', 'base-build','clean:partials','replace:releaseCacheBustVer']
  );

  grunt.registerTask(
    'prod',
    'Build for production release ',
      ['ngtemplates','base-build','clean:partials','replace:releaseCacheBustVer','precompress']
  );

};