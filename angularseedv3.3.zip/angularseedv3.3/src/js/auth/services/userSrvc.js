﻿/**
*@ngdoc service
*@name app.auth.userSrvc
*@function
*@description
* <P>
* Cookie Service
* Creates a cookie when the user logs in successfully, the cookie stores the user name, 
* roles. The cookie is to validate if the login session is active. 
* The service also help to store the username to be accessed throughout the 
* application.
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/

define(['../module'], function (serviceModule) {
    'use strict';
    serviceModule.factory('userSrvc',function () {

        var currentUser = {};

        return {
            /**
             * @ngdoc method
             * @name app.auth.userSrvc#add
             * @methodOf app.auth.userSrvc
             * @description
             * @param {object} obj description
             */
            setCurrentUser: function (obj) {
                this.currentUser = obj;
            },
            /**
             * @ngdoc method
             * @name app.auth.userSrvc#clear
             * @methodOf app.auth.userSrvc
             * @description
             */
            clearCurrentUser: function () {
               this.currentUser = null;
            },
            /**
             * @ngdoc method
             * @name app.auth.userSrvc#isLogged
             * @methodOf app.auth.userSrvc
             * @description
             * @returns {string} USER_NAME
             */
            getCurrentUser: function () {
                return this.currentUser;
            }
        };
    
    });

});
