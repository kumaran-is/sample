﻿/**
*@ngdoc service
*@name app.auth.sessionSrvc
*@function
*@description
* <P>
* sessionSrvc
* Creates a cookie when the user logs in successfully, the cookie stores the user name, 
* roles. The cookie is to validate if the login session is active. 
* The service also help to store the username to be accessed throughout the 
* application.
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/

define(['../module'], function (serviceModule) {
    'use strict';
    serviceModule.factory('sessionSrvc', 
        ['appConfig',
        function (appConfig) {

        return {
            /**
             * @ngdoc method
             * @name app.auth.sessionSrvc#add
             * @methodOf app.auth.sessionSrvc
             * @description
             * @param {object} obj description
             */
            add: function (obj) {
 //               cookieStore.put(appConfig.COOKIE_NAME, obj);
            },
            /**
             * @ngdoc method
             * @name app.auth.sessionSrvc#clear
             * @methodOf app.auth.sessionSrvc
             * @description
             */
            clear: function () {
   //             cookieStore.remove(appConfig.COOKIE_NAME);
            }
            
        };

    }]);

});
