﻿/**
*@ngdoc service
*@name app.auth.cookieSrvc
*@function
*@description
* <P>
* Cookie Service
* Creates a cookie when the user logs in successfully, the cookie stores the user name, 
* roles. The cookie is to validate if the login session is active. 
* The service also help to store the username to be accessed throughout the 
* application.
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/

define(['../module', 'jquery-cookie'], function (serviceModule) {
    'use strict';
    serviceModule.factory('cookieService', 
        ['cookieStore', 'appConfig',
        function (cookieStore,appConfig) {

        var currUserInfo = function (prop) {
            var userInfo = cookieStore.get(appConfig.COOKIE_NAME);
            if (userInfo && userInfo.hasOwnProperty(prop) ) {
                return userInfo[prop];  
            }
            else{
              return null;  
            }
            
        };

        return {
            /**
             * @ngdoc method
             * @name app.auth.cookieSrvc#add
             * @methodOf app.auth.cookieSrvc
             * @description
             * @param {object} obj description
             */
            add: function (obj) {
                cookieStore.put(appConfig.COOKIE_NAME, obj);
            },
            /**
             * @ngdoc method
             * @name app.auth.cookieSrvc#clear
             * @methodOf app.auth.cookieSrvc
             * @description
             */
            clear: function () {
                cookieStore.remove(appConfig.COOKIE_NAME);
            },
            /**
             * @ngdoc method
             * @name app.auth.cookieSrvc#isLogged
             * @methodOf app.auth.cookieSrvc
             * @description
             * @returns {string} USER_NAME
             */
            isLogged: function () {
                return Boolean(currUserInfo(appConfig.USER_NAME));
            },
            /**
             * @ngdoc method
             * @name app.auth.cookieSrvc#updateUserInfo
             * @methodOf app.auth.cookieSrvc
             * @description
             */
            updateUserInfo: function() {                
                this.currentUser = currUserInfo(appConfig.USER_NAME);
                this.currentUserRole = currUserInfo(appConfig.ROLE);
            },            
            currentUser: currUserInfo(appConfig.USER_NAME),
            currentUserRole: currUserInfo(appConfig.ROLE),
            currentUserInfo: currUserInfo
        };
    }]);

    serviceModule.provider('cookieStore', function CookieStoreFactory() {
        var self = this;
        self.defaultOptions = {};
        /**
         * @ngdoc method
         * @name app.auth.cookieStore#setDefaultOptions
         * @methodOf app.auth.cookieSrvc
         * @description
         * @param {object} options description
         */
        self.setDefaultOptions = function (options) {
            self.defaultOptions = options;
        };

        
        self.$get = function () {
            return {
                /**
                 * @ngdoc method
                 * @name app.auth.cookieStore#get
                 * @methodOf app.auth.cookieSrvc
                 * @description
                 * @param {string} name description
                 * @returns {object} angular.fromJson(jsonCookie) description
                 */
                get: function (name) {
                    var jsonCookie = $.cookie(name);
                    if (jsonCookie) {
                        return angular.fromJson(jsonCookie);
                    }
                },
                /**
                 * @ngdoc method
                 * @name app.auth.cookieStore#$get
                 * @methodOf app.auth.cookieSrvc
                 * @description
                 * @param {object} name description
                 * @param {object} value description
                 * @param {object} options description
                 */
                put: function (name, value, options) {
                   options = $.extend({}, self.defaultOptions, options);
                    $.cookie(name, angular.toJson(value), options);
                },
                 /**
                 * @ngdoc method
                 * @name app.auth.cookieStore#$get
                 * @methodOf app.auth.cookieSrvc
                 * @description
                 * @param {object} name description
                 * @param {object} options description
                 */
                remove: function (name, options) {
                    options = $.extend({}, self.defaultOptions, options);
                    $.removeCookie(name, options);
                }
            };
        };
    });

    serviceModule.config(['cookieStoreProvider', 'appConfig', function (cookieStoreProvider, appConfig) {
        
        //Set the Minutes to hold the cache value
        var minutes = appConfig.EXPIRY_MINUTE;
        var expiryDate = new Date();
        expiryDate.setTime(expiryDate.getTime() + (minutes * 60 * 1000));

        cookieStoreProvider.setDefaultOptions({
            path: '/',
            expires: expiryDate
        });
    }]);
});
