/**
*@ngdoc service
*@name app.auth.authSrvc
*@function
*@description
* <P>
* login service
* this helps in login into the application based on user credentials
* this connects to the node express server for user authentication 
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['../module'], function (serviceModule) {
    'use strict';
    serviceModule.factory('authSrvc', 
        ['$q', 'restClientFactory', 'cookieService', 
        function ($q, restClientFactory, cookieService) {  

            var authRestangular = restClientFactory.getAuthRestangular();

                return {
                    /**
                     * @ngdoc method
                     * @name app.auth.authSrvc#isAuthenticated
                     * @methodOf app.auth.authSrvc
                     * @description To check if user is logged on
                     * @returns {object} true or false
                     */
                    isAuthenticated: function () {
                        return cookieService.isLogged();
                    },
                    /**
                     * @ngdoc method
                     * @name app.auth.authSrvc#isAuthorized
                     * @methodOf app.auth.authSrvc
                     * @description To check if the user is authorized
                      
                     * @returns {object} true or false
                     */
                    isAuthorized: function (authorizedRoles){
                        //if  param is not of array type, then convert it to array format 
                        if (!angular.isArray(authorizedRoles)) {
                          authorizedRoles = [authorizedRoles];
                        }
                        return (this.isAuthenticated() &&
                          authorizedRoles.indexOf(cookieService.currentUserRole) !== -1);
                    },
                    /**
                     * @ngdoc method
                     * @name app.auth.authSrvc#login
                     * @methodOf app.auth.authSrvc
                     * @description Logs in the with user credentials
                     * @param {object} credentials User credentials
                     * @returns {object} defer.promise
                     */
                    login: function (credentials) {
                        var deferred = $q.defer();

                        //Always use POST when sending username and password
                        //GET will store the query string in history
                        authRestangular.one('authenticate').post('', credentials)
                            .then(
                                function (resp) {
                                    deferred.resolve(resp);
                                    console.log('inside login the respons is ==>',resp);
                                    cookieService.add({ username: resp.username, token: resp.token, role: resp.role });
                                    //Update CurrentUser for the triggering the watches
                                    cookieService.updateUserInfo();
                                },
                                function (resp) {
                                    deferred.reject('AUTHENTICATION_FAILED');
                                    cookieService.clear();
                                }
                            );
                        return deferred.promise;
                    },
                   /**
                     * @ngdoc method
                     * @name app.auth.authSrvc#logout
                     * @methodOf app.auth.authSrvc
                     * @description Logs out current user
                     */
                    logout: function () {
                        cookieService.clear();
                        //Update CurrentUser for the triggering the watches
                        cookieService.updateUserInfo();
                    },

                    /**
                     * @ngdoc method
                     * @name app.auth.authSrvc#signup
                     * @methodOf app.auth.authSrvc
                     * @description
                     * @param {object} data Requested user credentials
                     * @returns {object} resp Response     
                     *
                     */
                    signup: function(data) {
                        var deferred = $q.defer();
                        authRestangular.one('regUser').post('',data).then(
                            function(resp){
                              deferred.resolve(resp);
                            },        
                            function(resp){
                                if(resp.status === 0){
                                    // Show the application defined error from server via notification service 
                                    deferred.reject('ERROR_SC_0');
                                }
                                else{
                                    deferred.reject('SIGNUP_FAILED');
                                }
                             
                            }
                        );
                        return deferred.promise;
                    }

                };
    }]);
});
