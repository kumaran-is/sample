/**

*<p>
* Define and loads all the module components and act as container for all the components
* belongs to 'auth' module.
*</p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(
	[
		'./router',
		'./controllers/loginCtrl',
		'./controllers/signupCtrl',
		'./services/cookieSrvc',
		'./services/sessionSrvc',
		'./services/userSrvc',
		'./services/authSrvc'
	],
	function(){
		'use strict';
});
