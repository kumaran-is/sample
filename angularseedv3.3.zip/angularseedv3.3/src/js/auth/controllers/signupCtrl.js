/**
*@ngdoc object
*@name app.auth.signupCtrl
* @requires $scope
 * @requires $translate
 * @requires authSrvc
*@description
* <P>
* Reg Control
* this helps in signup a new user into the application based on user data
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['../module'], function (controllerModule) {
  'use strict';
  controllerModule.controller('signupCtrl',
   ['$scope','authSrvc','$sanitize','$state','logger',
    function ($scope,authSrvc,$sanitize,$state,logger) {
      var log = logger.getLogger('loginCtrl');
      $scope.errMsg = '';

     /**
      * @ngdoc method
      * @name app.auth.signupCtrl#regUser
      * @methodOf app.auth.signupCtrl
      * @description Used to signup new user
      */
      $scope.regUser = function() {
        $scope.errMsg = '';
        //sanitize the input values that are sent to server
        var sanitizedCredential = {};
        sanitizedCredential.firstName = $sanitize($scope.credentials.firstName);
        sanitizedCredential.lastName = $sanitize($scope.credentials.lastName);
        sanitizedCredential.userName = $sanitize($scope.credentials.userName);
        sanitizedCredential.password1 = $sanitize($scope.credentials.password1);
        sanitizedCredential.password2 = $sanitize($scope.credentials.password2);
          
        var resPromise = authSrvc.signup(sanitizedCredential);
        resPromise.then(
          function(response){
            log.debug(response);
            // after successful signup redirect to listpage
            $state.go('listPageState');
          },
          function(response){
            log.error(response);
            $scope.errMsg = response;     
          }
        );
      }; 

  }]);

});

