/**
*@ngdoc object
*@name app.auth.loginCtrl
*@requires $scope
*@requires authSrvc
*@requires $state
*@description
* <P>
* Login Control
* this helps in logging a signup user into the application based on user data
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['../module'], function (controllerModule) {
  'use strict';
  controllerModule.controller('loginCtrl', 
    ['$scope',
    '$location','$translate','authSrvc','$state','logger',
    function ($scope,$translate,$location,authSrvc,$state,logger) {
        var log = logger.getLogger('loginCtrl');
        $scope.credentials = {
          username: '',
          password: ''
        };
        $scope.errMsg = '';

        /**
         * @ngdoc method
         * @name app.auth.loginCtrl#loginFeature
         * @methodOf app.auth.loginCtrl
         * @description 
         */
        $scope.loginFeature = function(){
            $scope.errMsg = '';
            var promise = authSrvc.login($scope.credentials);
            promise.then(
                function(response){
                    log.debug(response);
                    $state.go('listPageState');
                },
                function(response){
                    log.error(response);
                    $scope.errMsg = response;
                }
            );
        };

    }]);
});
