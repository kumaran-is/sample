/**
*@ngdoc overview
*@name router
*@requires $stateProvider
*@requires $urlRouterProvider
*@description
*<p>
* To define application states,listens and routes application state change to
* appropriate controller and partials using ui-router. ui-router is a third Party AngularJS
* module developed by AngularJS team to support Nested/Parallel views .
* Read More : https://github.com/angular-ui/ui-router/wiki
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['./module'], function (authModule) {
	'use strict';
	return authModule.config(['$stateProvider', 
		function ($stateProvider) {

		/* define nested view for home page. A page can have only one state but can made of 
         one or more views to create a page. */ 
		$stateProvider .state('loginPageState', {
			url:'/login',
			parent:'defaultPageState',
			views:{
				'center@baseLayoutState':{templateUrl:'partials/auth/login.html',controller:'loginCtrl'}
			}
		});

		/* define nested view for home page. A page can have only one state but can made of 
         one or more views to create a page. */ 
		$stateProvider .state('signupPageState', {
			url:'/signup',
			parent:'defaultPageState',
			views:{
				'center@baseLayoutState':{templateUrl:'partials/auth/signup.html',controller:'signupCtrl'}
			}
		});
	}]);
});
