/**
*@ngdoc object
*@name app.auth
*@requires app.auth.authCtrl
*@requires app.auth.signupCtrl
*@requires app.auth.cookieService
*@requires app.auth.authSrvc
*@description
* <p>
* Defines an application module "app.auth" at global namespace.Modules are the logical 
* entities that divides your app into smaller self  contained unit of functionality.
* It implements javascript module design pattern.
* that makes the code clear, consistent, understandable, and maintainable.
* This module is the entry point for 'auth' module, organize and  inject dependencies
* required for 'auth' module. Loads all the dependent module components.
* Also loads sub modules(if required) and wire them up into the 'auth' module.
* Act as container for all the objects managed by 'auth' module.
* Module defines following features related to auth  module :-
* <ul>
*   <li>Display the list of features supported by AngularJS seed project by fetching the data from backend REST service.</li>
*   <li> Display appropriate error message to user in case of REST service failure.</li>
* </ul>
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['angular'], function (angular) {
	'use strict';
	return angular.module('app.auth', []);
});
