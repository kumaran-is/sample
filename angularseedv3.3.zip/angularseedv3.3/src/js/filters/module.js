/**
*@ngdoc object
*@name app.filters
*@description
*<p>
* Defines a core module "app.filters" at global namespace.Modules are the logical entities that divides your app into smaller self 
* contained unit of functionality.It implements javascript module design pattern.
* that makes the code clear, consistent, understandable, and maintainable.
* This module is the entry point for 'filters' module, organize and  inject dependencies
* required for 'filters' module. Loads all the dependent module components.
* Also loads sub modules(if required) and wire them up into the 'filters' module.
* Act as container for all application wide reusable custom angularjs filters.
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['angular'], function (angular) {
	'use strict';
	return angular.module('app.filters', []);
});
