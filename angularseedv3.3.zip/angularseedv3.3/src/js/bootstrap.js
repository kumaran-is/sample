/**
*@ngdoc overview
*@name bootstrap
*@description
* <p>
* Kickstarts the angular application by loading Angular application wide main 
*  module "app.js" to the windows document node.
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define([
'require',
'angular',
'app',
'router',
'templates'
], function (require, angular) {
	'use strict';
	/*
	* As soon as  DOM Ready event is detected ,load the Angular application module 
	* to the windows document module and kick start the application. Angular 
	* application main module should be initialized only after when DOM is ready
	*/
	require(['requirejs-domready!'], function (document) {

	/*This function is called once the DOM is ready.
	*  Read more: http://docs.angularjs.org/api/ng/function/angular.bootstrap
	*/
		angular.bootstrap(document, ['app'], {
			/*
			Strict mode throws an error whenever a angularJS component tries to use implicit depenedency injection
			Implicit way  of describing Dependecies : Example the following source code will broke when miinified 
			since it does not add the required metadata
			angular.module("MyApp").controller("HomeCtrl", function ($scope,HomeSrvc));
			Rightway of describing Dependecnies : 
			angular.module("MyApp").controller("HomeCtrl",["$scope", "HomeSrvc",function ($scope,HomeSrvc)]);;
			*/
			strictDi: true
		});
	});
});
