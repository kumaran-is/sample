/**
* @fileoverview
*<p>
* Define and loads all the module components and act as container for all the components
* belongs to 'feature1' module.
*</p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(
[   
	'./router',
	'./controllers/createCtrl',
	'./controllers/listCtrl',
	'./controllers/modifyCtrl',
	'./controllers/deleteCtrl',
	'./services/seedCapabilitySrvc'
],
 function () {
 'use strict';
});
