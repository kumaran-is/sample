/**
*@ngdoc service
*@name app.capabilities.seedCapabilitySrvc
*@description
* <p>
*  This layer represent presentation logic and fetch application data from REST service,
*  Responsible for XHR calls, local storage, stashing in memory, or any other data operations. 
*  Enable Facade pattern  with the single responsibility of interacting with the external Web 
*  service.Makes REST calls using thirdparty library Restangularjs,it follow declarative 
*  approach  and simplifies common GET, POST, DELETE, and  UPDATE requests with a minimum of 
*  client code. Request URL and Response data are cached using thirdparty Angular-cache plugin.
*  Service is always a singleton instance and reused across application layers. Always move
*  logic from Controller  to services and factories.Logic may be reused by multiple controllers 
*  when placed within a service or factory Logic in a service can more easily be isolated in a unit test,
*  while the calling logic in the controller can be easily mocked.Removes dependencies and hides 
*  implementations details from the controller
*  Read more: https://github.com/mgonto/restangular
*  Read more : http://mgonto.github.io/restangular-talk/
*  Rest URL used  in this seed project : 
*  https://api.mongolab.com/api/1/databases/angulardb/collections/Angularfeatures/?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['../module'], function (serviceModule) {
	'use strict';
	serviceModule.factory('seedCapabilitySrvc',['restClientFactory','$angularCacheFactory','$q','notificationSrvc','appConfig', 
	function(restClientFactory,$angularCacheFactory,$q,notificationSrvc,appConfig){
		var feature1Restangular = restClientFactory.getFeature1Restangular();
		return {
			
			getSeedFeatures:function(){
				var deferred = $q.defer();
				//commented to disable caching functionality, to enable just uncomment and comment the next line
				//feature1Restangular.one('angularseed').withHttpConfig( {timeout: appConfig.REST_REQ_TIMEOUT,cache: $angularCacheFactory.get('defaultCache')} ).get().then(
				feature1Restangular.one('angularseed').withHttpConfig( {timeout: appConfig.REST_REQ_TIMEOUT } ).get().then(
				function(resp){
					deferred.resolve(resp);
				},
				function(resp){
				
					if(resp.status === 0){
						// Show the application defined error from server via notification service 
						//notificationSrvc.notifyError('Sorry! We are currently experiencing technical difficulties please try again later.');
						deferred.reject('ERROR_SC_0');
					}
					else{
						deferred.reject('Something went wrong',resp);
						/*Any unknow application error from server is thrown as exceptiom/error to exceptionSrvc.js  */
						throw new Error(resp.data);
					}
				});
			
				return deferred.promise;
			},

			addSeedFeature: function(newfeature) {

				console.log('Inside seedCapabilitySrvc addAngularSeedFeatures() request data is',newfeature);
				var deferred = $q.defer();
				feature1Restangular.one('angularseed').post('',newfeature)
				.then(
					function(resp){
						console.log('Inside seedCapabilitySrvc addAngularSeedFeatures() respone  => ',resp);
						//notificationSrvc.notifySuccess(''Transaction complete successfully'');
						deferred.resolve('SUCCESS_RECORD_INSERTED');
					},
					function(resp){
						console.log('Inside Factory1 seedCapabilitySrvc addSeedFeature() respone  => ',resp);
						if(resp.status === 0){
							// Show the application defined error from server via notification service 
							//notificationSrvc.notifyError('Sorry! We are currently experiencing technical difficulties please try again later.');
							deferred.reject('ERROR_SC_0');
						}
						else{
							deferred.reject('Something went wrong',resp);
							/*Any unknow application error from server is thrown as exceptiom/error to exceptionSrvc.js  */
							throw new Error(resp.data);
						}
					}
				);
				return deferred.promise;
			},

			modifySeedFeature: function(modifiedData,id) {
				console.log('Inside seedCapabilitySrvc modifyFeatures() request data ',modifiedData);
				var deferred = $q.defer();
				feature1Restangular.one('angularseed',id).customPUT(modifiedData)
				.then(
					function(resp){
						console.log('Inside seedCapabilitySrvc modifySeedFeature() respone  => ',resp);
						//notificationSrvc.notifySuccess(''Transaction complete successfully'');
						deferred.resolve('SUCCESS_RECORD_UPDATED');
					},
					function(resp){
						console.log('Inside seedCapabilitySrvc modifySeedFeature() respone  => ',resp);
						if(resp.status === 0){
							// Show the application defined error from server via notification service 
							//notificationSrvc.notifyError('Sorry! We are currently experiencing technical difficulties please try again later.');
							deferred.reject('ERROR_SC_0');
						}
						else{
							deferred.reject('Something went wrong',resp);
						/*	Any unknow application error from server is thrown as exceptiom/error to exceptionSrvc.js  */
							throw new Error(resp.data);
						}
					}
				);
				return deferred.promise;
			},

			removeSeedFeature: function(id) {
				console.log('Inside remove request data ',id);
				var deferred = $q.defer();
				feature1Restangular.one('angularseed',id).remove()
				.then(
					function(resp){
						console.log('Inside seedCapabilitySrvc removeSeedFeature() respone  => ',resp);
						//notificationSrvc.notifySuccess(''Transaction complete successfully'');
						deferred.resolve('SUCCESS_RECORD_DELETED');
					},
					function(resp){
						console.log('Inside seedCapabilitySrvc removeSeedFeature() respone  => ',resp);
						if(resp.status === 0){
							// Show the application defined error from server via notification service 
							//notificationSrvc.notifyError('Sorry! We are currently experiencing technical difficulties please try again later.');
							deferred.reject('ERROR_SC_0');
						}
						else{
							deferred.reject('Something went wrong in seedCapabilitySrvc removeSeedFeature()',resp);
							/*Any unknow application error from server is thrown as exceptiom/error to exceptionSrvc.js  */
							throw new Error(resp.data);
						}
					}); 
				return deferred.promise;
			}
		};
	}]);
});
