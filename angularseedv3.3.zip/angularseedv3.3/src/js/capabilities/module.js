/**
*@ngdoc object
*@name app.capabilities
*@requires app.capabilities.createCtrl
*@requires app.capabilities.listCtrl
*@requires app.capabilities.modifyCtrl
*@requires app.capabilities.deleteCtrl
*@requires app.capabilities.seedCapabilitySrvc
*@description
* <p>
* Defines an application module "app.capabilities" at global namespace.Modules are the logical entities that divides your app into smaller self 
* contained unit of functionality.It implements javascript module design pattern.
* that makes the code clear, consistent, understandable, and maintainable.
* This module is the entry point for 'capabilities' module, organize and  inject dependencies
* required for 'capabilities' module. Loads all the dependent module components.
* Also loads sub modules(if required) and wire them up into the 'capabilities' module.
* Act as container for all the objects managed by 'capabilities' module.
* Module defines following features related to capabilities  module :-
* <ul>
*   <li>Display the list of features supported by AngularJS seed project by fetching the data from backend REST service.</li>
*   <li> Display appropriate error message to user in case of REST service failure.</li>
* </ul>
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['angular'], function (angular) {
	'use strict';
	return angular.module('app.capabilities', []);
});
