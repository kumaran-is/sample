/**
*@ngdoc overview
*@name router
*@requires $stateProvider
*@description
*<p>
* To define application states,listens and routes application state change to
* appropriate controller and partials using ui-router. ui-router is a third Party AngularJS
* module developed by AngularJS team to support Nested/Parallel views .
* Read More : https://github.com/angular-ui/ui-router/wiki
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['./module'], function (capabilitiesModule) {
	'use strict';
	return capabilitiesModule.config(['$stateProvider','appConfig', 
		function ($stateProvider,appConfig) {

		/* define nested view for home page. A page can have only one state but can made of 
         one or more views to create a page. */
		$stateProvider .state('listPageState', {
			url:'/list',
			parent:'defaultPageState',
			views:{
				'center@baseLayoutState':{templateUrl:'partials/capabilities/list.html', controller:'listCtrl'}
			},

			/* 
				Use a Route Resolver : (1) A controller may require data before it loads.That data may come from a 
				promise via factory service,Using a route resolve allows the promise to resolve before the 
				controller logic executes (2) If you want to conditionally cancel a route before the controller is
				activated,use a route resolver (3) if you want to resolve dependencies before the controller 
				is activated 
			*/
		
			resolve:{				
				getSeedCapabilityList:function(seedCapabilitySrvc){
					return seedCapabilitySrvc.getSeedFeatures();
				}
			},
			/*This callback function called when a state is entered.This functions have
			access to  the resolved data */
			onEnter: function(){
				console.log('entering onEnter callbackfunction in listPageState');
			},
			onExit: function(){
				console.log('entering onExit callbackfunction in listPageState');
			},
			data: {
				authorizedRoles: [appConfig.ADMIN, appConfig.GUEST]
				//authorizedRoles: appConfig.ACCESS_LEVELS.USER;
			}
		});

		/* define nested view for home page. A page can have only one state but can made of 
         one or more views to create a page. */ 
		$stateProvider .state('createPageState', {
			url:'/add',
			parent:'defaultPageState',
			views:{
				'center@baseLayoutState':{templateUrl:'partials/capabilities/create.html',controller:'createCtrl'}
			},
			resolve:{				
				getSeedCapabilityList:function(seedCapabilitySrvc){
					return seedCapabilitySrvc.getSeedFeatures();
				}
			},
			/*This callback function called when a state is entered.This functions have
			access to  the resolved data */
			onEnter: function(){
				console.log('entering onEnter callbackfunction in createPageState');
			},
			onExit: function(){
				console.log('entering onExit callbackfunction in createPageState');
			},
			data: {
				authorizedRoles: [appConfig.ADMIN]
			}
		});

		/* define nested view for home page. A page can have only one state but can made of 
         one or more views to create a page. */ 
		$stateProvider .state('modifyPageState', {
			url:'/modify',
			parent:'defaultPageState',
			views:{
				'center@baseLayoutState':{templateUrl:'partials/capabilities/modify.html',controller:'modifyCtrl'}
			},
			resolve:{
				
				getSeedCapabilityList:function(seedCapabilitySrvc){
					return seedCapabilitySrvc.getSeedFeatures();
				}
			},
			/*This callback function called when a state is entered.This functions have
			access to  the resolved data */
			onEnter: function(){
				console.log('entering onEnter callbackfunction in modifyPageState');
			},
			onExit: function(){
				console.log('entering onExit callbackfunction in modifyPageState');
			},
			data: {
				authorizedRoles: [appConfig.ADMIN]
			}
		});

		/* define nested view for home page. A page can have only one state but can made of 
         one or more views to create a page. */ 
		$stateProvider .state('deletePageState', {
			url:'/remove',
			parent:'defaultPageState',
			views:{
				'center@baseLayoutState':{templateUrl:'partials/capabilities/delete.html',controller:'deleteCtrl'}
			},
			resolve:{
				
				getSeedCapabilityList:function(seedCapabilitySrvc){
					return seedCapabilitySrvc.getSeedFeatures();
				}
			},
			/*This callback function called when a state is entered.This functions have
			access to  the resolved data */
			onEnter: function(){
				console.log('entering onEnter callbackfunction in deletePageState ');
			},
			onExit: function(){
				console.log('entering onExit callbackfunction in deletePageState');
			},
			data: {
				authorizedRoles: [appConfig.ADMIN]
			}
		});
	}]);
});
