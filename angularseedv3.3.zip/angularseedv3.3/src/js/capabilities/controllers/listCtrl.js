/**
*@ngdoc object
*@name app.capabilities.listCtrl
*@description
* <P>
* Receives and responds to user actions/events (keystrokes,mouse clicks, mouse movements,
* gestures, etc.).Invokes appropriate services to get application data from backend 
* service and updates View state via scope.This layer is kept thin. It does not contain
* business rules or knowledge, but only coordinates tasks and delegates work between
* View(partials) and Services.View(main.html) and Controller(mainCtrl.js) are structured 
* and bounded one-to-one to each other.Controllers responsibility to glue the Model (data)
* with the View to enable two-way binding.
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['../module'], function (controllerModule) {
	'use strict';
	controllerModule.controller('listCtrl',
	['$scope','$translate','notificationSrvc','getSeedCapabilityList','logger',
  function ($scope,$translate,notificationSrvc,getSeedCapabilityList,logger) {
    var log = logger.getLogger('listCtrl');
    $scope.features = '';
    $scope.errMsg = '';
    log.debug('inside list controller');

    /* getSeedCapabilityList is a promise resolvedd by resolve property of $stateProvider defined in router.js */
    $scope.features = getSeedCapabilityList;
   
  }]);
});
