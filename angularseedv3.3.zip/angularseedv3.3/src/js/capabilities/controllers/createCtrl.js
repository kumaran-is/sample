/**
*@ngdoc object
*@name app.capabilities.createCtrl
*@description
* <P>
* Receives and responds to user actions/events (keystrokes,mouse clicks, mouse movements,
* gestures, etc.).Invokes appropriate services to get application data from backend 
* service and updates View state via scope.This layer is kept thin. It does not contain
* business rules or knowledge, but only coordinates tasks and delegates work between
* View(partials) and Services.Controllers responsibility to glue the Model (data)
* with the View to enable two-way binding. Controller and View are structured 
* and bounded one-to-one to each other.Reusing controllers with several views are not recommended.
* Avoid doing DOM manipulation in controller, all DOM  manipulations should be moved to directives
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['../module'], function (controllerModule) {
	'use strict';
	controllerModule.controller('createCtrl',
	['$scope','$translate','notificationSrvc','seedCapabilitySrvc','appConfig','logger','$sanitize',
	function ($scope,$translate,notificationSrvc,seedCapabilitySrvc,appConfig,logger,$sanitize) {

    var log = logger.getLogger('createCtrl');
    $scope.features = '';
    $scope.successMsg = '';
    $scope.errMsg = '';
    $scope.addStatus = appConfig.STATUS;


   /*$scope.interacted = function(field) {
      return $scope.submitted || field.$dirty;
    };
    */

    /* getSeedCapabilityList is a promise resolvedd by resolve property of $stateProvider defined in router.js */
	//	$scope.features = getSeedCapabilityList;
    
    /**
     * @ngdoc method
     * @name app.capabilities.createCtrl#createFeature
     * @methodOf app.capabilities.createCtrl
     * @description Insert capability feature 
    */
    $scope.createFeature = function() {
    $scope.successMsg = '';
    $scope.errMsg = ''; 
    var features = {};
    features.name = $scope.newfeatures.name;
    //sanitize the input value that is sent to server
    features.Description = $sanitize($scope.newfeatures.Description);
    features.Status = $scope.newfeatures.Status;   
         

   var resPromise = seedCapabilitySrvc.addSeedFeature(features);
   //   var resPromise =  seedCapabilitySrvc.addSeedFeature(sanitizedFeatures);
      resPromise.then(
        function(response){
          log.debug(response);
        
          //Reset the form values
          $scope.newfeatures = {};
          $scope.newfeatures.name = '';
          $scope.newfeatures.Description = '';
          $scope.newfeatures.Status = $scope.addStatus[0];
          $translate(response).then(function (translation) {
            $scope.successMsg = translation;
            notificationSrvc.notifySuccess($scope.successMsg);
          });
      
        },
        function(response){
          
          $translate(response).then(function (translation) {
            $scope.errMsg = translation;
            notificationSrvc.notifyError($scope.errMsg);
          });
        });
      $scope.createForm.$setPristine();
    };

	}]);

});
