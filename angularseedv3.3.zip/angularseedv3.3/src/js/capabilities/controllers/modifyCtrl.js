/**
*@ngdoc object
*@name app.capabilities.modifyCtrl
*@description
* <P>
* Receives and responds to user actions/events (keystrokes,mouse clicks, mouse movements,
* gestures, etc.).Invokes appropriate services to get application data from backend 
* service and updates View state via scope.This layer is kept thin. It does not contain
* business rules or knowledge, but only coordinates tasks and delegates work between
* View(partials) and Services.View(main.html) and Controller(mainCtrl.js) are structured 
* and bounded one-to-one to each other.Controllers responsibility to glue the Model (data)
* with the View to enable two-way binding.
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['../module'], function (controllerModule) {
	'use strict';
	controllerModule.controller('modifyCtrl',
	['$scope','$translate','notificationSrvc','getSeedCapabilityList','seedCapabilitySrvc','appConfig','logger','$sanitize',
	function ($scope,$translate,notificationSrvc,getSeedCapabilityList,seedCapabilitySrvc,appConfig,logger,$sanitize) {
        var log = logger.getLogger('modifyCtrl');
        $scope.features = '';
        $scope.errMsg = '';
        $scope.successMsg = '';
        $scope.updateStatus = appConfig.STATUS;
      

        /* getSeedCapabilityList is a promise resolvedd by resolve
           property of $stateProvider defined in router.js */
        $scope.features = getSeedCapabilityList;
        
          
        /**
         * @ngdoc method
         * @name app.capabilities.modifyCtrl#editFeature
         * @methodOf app.capabilities.modifyCtrl
         * @description
         * @param {object} feature edit user credentials
         */
        $scope.editFeature  =  function(feature){
            log.debug('<<<<<<<< Inside editFeature >>>>>>>>>>',feature);
            feature.mode  = 'editmode';
        };

        /**
         * @ngdoc method
         * @name app.capabilities.modifyCtrl#cancel
         * @methodOf app.capabilities.modifyCtrl
         * @description
         * @param {object} feature cancel user credentials
        */
        $scope.cancel  =  function(feature){
            log.debug('<<<<<<<< Inside cancel >>>>>>>>>>');
            feature.mode  = '';
        };

        /**
         * @ngdoc method
         * @name app.capabilities.modifyCtrl#update
         * @methodOf app.capabilities.modifyCtrl
         * @description
         * @param {object} feature update user credentials
         */
        $scope.update  =  function(feature){
            $scope.successMsg = '';
            $scope.errMsg = '';
            log.debug('<<<<<<<< Inside update >>>>>>>>>>',feature._id.$oid);
            var updateObj = {};
            updateObj.name = feature.name;
            //sanitize the data sent to server
            updateObj.Description = $sanitize(feature.Description);
            updateObj.Status = feature.Status;
            log.debug('Edited Feature >>>>',updateObj);
            var resPromise =  seedCapabilitySrvc.modifySeedFeature(updateObj,feature._id.$oid);
            resPromise.then(
            function(response){
                log.debug(response);
                $translate(response).then(function (translation) {
                    $scope.successMsg = translation;
                    notificationSrvc.notifySuccess($scope.successMsg);
                });
                feature.mode  = '';
            },
            function(response){
                log.debug(response);
                $translate(response).then(function (translation) {
                    $scope.errMsg = translation;
                    notificationSrvc.notifyError($scope.errMsg);
                });
               feature.mode  = '';     
            });
        };

	}]);
});
