/**
*@ngdoc object
*@name app.common
*@requires app.common.headerCtrl
*@description
* <p>
* Defines an application module "app.feature1" at global namespace.Modules are the logical entities that divides your app into smaller self 
* contained unit of functionality.It implements javascript module design pattern.
* that makes the code clear, consistent, understandable, and maintainable.
* This module is the entry point for 'feature1' module, organize and  inject dependencies
* required for 'feature1' module. Loads all the dependent module components.
* Also loads sub modules(if required) and wire them up into the 'feature1' module.
* Act as container for all the objects managed by 'feature1' module.
* Module defines following features related to feature1  module :-
* <ul>
*   <li>Display the list of features supported by AngularJS seed project by fetching the data from backend REST service.</li>
*   <li> Display appropriate error message to user in case of REST service failure.</li>
* </ul>
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['angular'], function (angular) {
	'use strict';
	return angular.module('app.common', []);
});
