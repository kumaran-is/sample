/**
*@ngdoc object
*@name app.common.footerCtrl
*@description
* <P>
* Receives and responds to user actions/events (keystrokes,mouse clicks, mouse movements,
* gestures, etc.).Invokes appropriate services to get application data from backend 
* service and updates View state via scope.This layer is kept thin. It does not contain
* business rules or knowledge, but only coordinates tasks and delegates work between
* View(partials) and Services.View(footer.html) and Controller(footerCtrl) are structured 
* and bounded one-to-one to each other.Controllers responsibility to glue the Model (data) 
* with the View to enable two-way binding.
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['../module'], function (controllerModule) {
	'use strict';
	controllerModule.controller('footerCtrl',
		function () {
		});
});
