/**
*@ngdoc object
*@name app.common.headerCtrl
*@description
* <P>
* Receives and responds to user actions/events (keystrokes,mouse clicks, mouse movements,
* gestures, etc.).Invokes appropriate services to get application data from backend 
* service and updates View state via scope.This layer is kept thin. It does not contain
* business rules or knowledge, but only coordinates tasks and delegates work between
* View(partials) and Services.View(header.html) and Controller(headerCtrl.js) are structured
* and bounded one-to-one to each other.Controllers responsibility to glue the Model (data)
* with the View to enable two-way binding.
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['../module'], function (controllerModule) {
	'use strict';
	controllerModule.controller('headerCtrl',
	['$scope','$location','$state','$translate','cookieService','authSrvc','logger',
	function ($scope,$location,$state,$translate,cookieService,authSrvc,logger) {
            var log = logger.getLogger('headerCtrl');
		$scope.authenticated = authSrvc.isAuthenticated();
            $scope.currentUser = cookieService.currentUser;

            //Options for languages dropdown
            $scope.languages = [{
                  name: 'English',
                  value: 'en_EN'
            }, {
                  name: 'French',
                  value: 'fr_FR'
            }];
            $scope.selectedLanguage = 'en_EN';

		/**
             * @ngdoc method
             * @name app.common.headerCtrl#isActive
             * @methodOf app.common.headerCtrl
             * @param {object} viewLocation display
             * @description
             */
		$scope.isActive = function (viewLocation) {
                  return ($location.path() === viewLocation);
		};
                
		/**
             * @ngdoc method
             * @name app.common.headerCtrl#logout
             * @methodOf app.common.headerCtrl
             * @description
             */
		$scope.logout = function () {

                  log.debug('headerCtrl ==> Inside logout function >>>');  
                  authSrvc.logout();
          };

            /**
             * @ngdoc method
             * @name app.common.headerCtrl#changeLanguage
             * @methodOf app.common.headerCtrl
             * @description
             */
		$scope.changeLanguage = function () {
                  $translate.use($scope.selectedLanguage);
            };
	}]);
});
