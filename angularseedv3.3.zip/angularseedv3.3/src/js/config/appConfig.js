/**
*@ngdoc object
*@name app.config.appConfig
*@description
* <p>
* Define application wide constants and Configuration values using angular constant service.
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(
	['./module'],
	function (configModule) {
		'use strict';
		configModule.constant('appConfig', {

			// to display error message as  'toastr' or 'popup'
			SHOW_ERROR_AS:'toastr',   
			// to display success message as  'toastr' or 'popup' 
			SHOW_SUCCESS_AS:'toastr', 
			SUCCESS_MSG_TITLE:'Alert!',
			ERROR_MSG_TITLE:'Alert!',
			REST_REQ_TIMEOUT:180000, //  3 mins
			DATEFORMAT:'dd-MM-yyyy',
			TIMEFORMAT:'HH:mm:ss',
			//Define REST end point URL to post log messages to remote server.
			LOGGING_URL:'https://api.mongolab.com/api/1/databases/angulardb/collections/logManagement?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X',
			IS_LOG_ENABLED:true,
			IS_AJAXLOG_ENABLED:true,
			LOG_LEVEL:'ALL',
			IS_STATECHANG_EVENTS_ENABLED:true,
			IS_VIEWCONTENT_EVENTS_ENABLED:true,
			IS_OVERRIDE_HTTPHEADERS_ENABLED:false,
			STATUS: ['Open','In-Progress','Closed'],
			CAPABILITIES_REST_ENDPOINT_BASEURL:'Https://api.mongolab.com/api/1/databases/angulardb/collections/',
			AUTH_REST_ENDPOINT_BASEURL:'http://localhost:4000/',


			// User Roles 
			ADMIN: '3',
			GUEST: '2',

			ACCESS_LEVELS : {
				'PUBLIC': ['1','2','3'],
				'USER' : ['2','3'],
				'ADMIN': ['3']
			},
            
            //user constant 
			USER_NAME: 'username',
			TOKEN: 'token',
			ROLE: 'role',
		
			//cookie config
			COOKIE_NAME: 'sessionAuth',
			EXPIRY_MINUTE: 20
		});
		
});
