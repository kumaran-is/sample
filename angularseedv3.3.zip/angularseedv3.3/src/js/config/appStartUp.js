/**
*@ngdoc object
*@name app.config.appStartup
*@description
* <p>
* To configure or define global settings and functions that should be registered during
* application startup phase(config & run)
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['./module'], function (configModule) {
	'use strict';

     /* Setting global configration during application startup - config phase  */
     configModule.config(['appConfig','$httpProvider',function(appConfig,$httpProvider) {

      /* Interceptors are service factories that are registered with the $httpProvider by adding
        them to the $httpProvider.interceptors array. Registering interceptors using application
        config to intercep all the outbound REST request & incomming REST response.Interceptors are
        executed in the order it is placed. */

      $httpProvider.interceptors.push('errorInterceptor');
      $httpProvider.interceptors.push('authInterceptor');

     
     /* Override default HTTP headers to every request  */
     if (appConfig.IS_OVERRIDE_HTTPHEADERS_ENABLED) 
     {
        /* headers that are common for all requests */
        $httpProvider.defaults.headers.common = {'My-Header': 'Setting custom header values to all the request' };

        /* headers that are common for all POST requests */
        $httpProvider.defaults.headers.post = {'My-Header': 'Setting custom header values to POST request' };

        /* headers that are common for all PUT requests */
        $httpProvider.defaults.headers.put = {'My-Header': 'Setting custom header values to PUT reqest' };
      } 

    }]); // end of config

    /* Setting global settings/features during application startup - run phase  */
    configModule.run(['appConfig','$rootScope','$state','$stateParams', 'authSrvc', 'logger',
        function (appConfig, $rootScope, $state, $stateParams, authSrvc,logger) {
           var log = logger.getLogger('appStartUp');

          /* State change events listener can be set at runtime.All these events are
          fired at the $rootScope level. Flag to enable or disable state change events */

          if (appConfig.IS_STATECHANG_EVENTS_ENABLED) {
            /* This fires when the state transition begins from one page to another page.
            Pre-processs operations/tasks can be done here before showing the next page.
            Ex: compare users access permissions with incoming route's access level */
            $rootScope.$on('$stateChangeStart', function (event, next) {
                if(next.data) {
                  var authorizedRoles = next.data.authorizedRoles;
                   console.log('authorizedRoles  is  ==> ' + authorizedRoles);
                  if (!authSrvc.isAuthorized(authorizedRoles)) {
                    event.preventDefault();
                    $state.go('loginPageState');
                  }
                }
            }); 
   
            /* This fires once the state transition is complete.This will be fired after 
            resolve dependencies or promised are resolved successfully and onExit callback
            function is invoked  but before the controller is instantiated
            Ex: compare users access permissions with incoming route's access level */
            $rootScope.$on('$stateChangeSuccess', function() {});

            /* This fires when an error occurs during transition */
            $rootScope.$on('$stateChangeError', function (event, toState, toParams, fromState, fromParams, error) {
              event.preventDefault();
              console.log('Event Name is  ==> ' + event.name + ' error status is ',error);
               // log error to remote server 
              log.error('Event Name is  ==> ' + event.name);
              /* if a routing error occurs or backedn server is down or any system error, you route
               them to a friendly screen with more details or recovery options. Here i am  
               redirecting user  to technicalIssue  page */
              $state.go('underMaintenancePageState');
              
            });

            /* This fires when an error occurs during transition.Also fired if any of the promises of
            resolve are rejected */
            $rootScope.$on('$stateNotFound', function (event) {
              event.preventDefault();
              console.log('Event Name is  ==> ' + event.name);
              // log error to remote server 
              log.error('Event Name is  ==> ' + event.name);
               /* if a routing state or page is not found , you route them to a friendly screen with 
               more details . Here i am  redirecting user  to  Technical  difficulties page */
                $state.go('technicalIssuePageState');
          }); 
        }
  
      if (appConfig.IS_VIEWCONTENT_EVENTS_ENABLED){

         /*Runs on individual scopes, so putting it in the 'run' doesn't work.It should be in 
         the controller. This is Fired once the view begins loading, before the DOM is rendered. 
         This happens immediatley after $routeChangeSuccess event is fired and controller
         get instantiated   */
        $rootScope.$on('$viewContentLoading', function (event, viewConfig){
           console.log('Event Name is  ==> ' + event.name); 
           console.log('viewConfig  is  ==> ' + viewConfig);

           //viewConfig.targetView not defined - commenting this out  
           // console.log(' Target View is ==> ' + viewConfig.targetView);
        });
        
        /* This fires after dom is loaded */
        $rootScope.$on('$viewContentLoaded', function (event){
           console.log('Event Name is  ==> ' + event.name); 
        });
      }    
  }]);  //end of run
});
