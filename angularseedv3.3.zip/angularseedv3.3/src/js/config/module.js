/**
*@ngdoc object
*@name app.config
*@requires app.config.appConfig
*@requires app.config.aopConfig
*@requires app.config.appStartUp
*@requires app.config.messages
*@description
*<p>
* Defines a core module "app.config" at global namespace.Modules are the logical entities that divides your app into smaller self 
* contained unit of functionality.It implements javascript module design pattern.
* that makes the code clear, consistent, understandable, and maintainable.
* This module is the entry point for 'config' module, organize and  inject dependencies
* required for 'config' module. Loads all the dependent module components.
* Also loads sub modules(if required) and wire them up into the 'config' module.
* Act as container for all the objects managed by 'config' module.
* Module defines all the application related configurations & constants features.
*<ul>
*<li> appConfig.js : To define all application wide constants & configuration values.</li>
*<li> aopConfig.js : Implemented method level logger in servicelayer using AOP with AngularJS</li>
*<li> messages.js :  User defined validation,exception & error messages with i18n support.</li>
*<li> restURLConfig.js : To configure REST end point base urls ,default request & response Interceptors,path & query params.</li>
* </ul>
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['angular'], function (angular)
 {
	'use strict';
	return angular.module('app.config', ['pascalprecht.translate','AngularAOP']);
});
