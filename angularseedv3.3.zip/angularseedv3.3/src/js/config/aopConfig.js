/**
*@ngdoc object
*@name app.config.aopConfig
*@description
* AOP features implemented for logging using angular-aop module.
* It is a micro-framework for aspect-oriented programming with AngularJS.
* This module defines AOP configurations Joint point & advice for logger
* which logs the method calls and thrown exception.AOP logger applies aspects
* (logging functionality defined in the advice i.e loging.js) to all service's methods,
* before and after the methods and when an error is throw by the method.
* Read More: https://github.com/mgechev/angular-aop
* <p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(
['./module'],
 function (configModule) {
	'use strict';
	// global configuration (application wide)
	configModule.config(['$provide','executeProvider','$injector',function ($provide, executeProvider,$injector) {

      var seedCapabilitySrvc = $injector.get('seedCapabilitySrvc'),
      var authSrvc = $injector.get('authSrvc'),
		executeProvider.annotate($provide, {
			
			seedCapabilitySrvc: [{
	//executes given service(seedCapabilitySrvc) before and after the matched methods are invoked.
				jointPoint: 'around',
				advice: 'aopLoggerAdvice'
			},{
	//executes when an Error is thrown by method from the given set of matched methods
				jointPoint: 'onThrowOf',
				advice: 'aopLoggerAdvice'
			}],
			authSrvc: [{
				jointPoint: 'around',
				advice: 'aopLoggerAdvice'
			},{
					jointPoint: 'onThrowOf',
				advice: 'aopLoggerAdvice'
			}]  
		});
	}]);
});
