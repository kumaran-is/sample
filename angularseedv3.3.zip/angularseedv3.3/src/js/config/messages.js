/**
*@ngdoc object
*@name app.config.messages
*@description
*<p>
* Define application wide validations,exceptions & error messages 
* using angular constant service.
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(
['./module'], 
function (configModule)
{
	'use strict';
	// global configuration (application wide)
	return configModule.config(
		['$translateProvider',
			function ($translateProvider) {
			$translateProvider.translations('en_US',{

			// error or exception messages goes here
			ERROR_SC_0: 'Sorry! We are currently experiencing technical difficulties please try again later.',
			ERROR_SC: 'Error Occured While Calling Rest Service.Please try again later.',
			ERROR_02:'Sorry for the inconvenience caused. Please contact our help desk 1800-200-2345!',
			ERROR_03:'Invalid Username or Password!',
			ERROR_REST_TIMEOUT: 'Sorry! Rest Call Timeout',
			AUTHENTICATION_FAILED:'Authentication Failed.Pleaser try again.',
			SIGNUP_FAILED:'Signup Failed.Pleaser try again.',

			//  success message
			SUCCESS_TRANSACTION: 'Transaction complete successfully',	
			SUCCESS_RECORD_INSERTED:'Record Sucessfully Inserted',
			SUCCESS_RECORD_UPDATED:'Record Sucessfully Updated',
			SUCCESS_RECORD_DELETED:'Record Sucessfully Deleted',

			// front end validation messages goes here	
			MINLENGTHEXP: 'Please enter a minimum value',
			NUMEXP: 'Enter only Numbers!',
			MANDATORYEXP: 'Field should not be empty',
			EMAILEXP: 'Enter a valid Email Id',
			ISALPHABETEXP: 'The value should be a-z/A-Z',
			ISALPHANUMERICEXP: 'The value should be a-z/A-Z and 1-9',
			ISDATEEXP: 'Enter a valid Date',

			// Label or  text content goes here 
			WELCOME_MESSAGE:'Welcome to AngularJS Seed Project',
			MAIN_SUBHEADING1:'Enter AngularJS Seed Project Features and Capabilities',
			MAIN_SUBHEADING2:'AngularJS Seed Project Features and Capabilities',
			SNO:'#',
			HEADER_TITLE:'Seed Project',
			FOOTER_TITLE:'angularseedproject© 2014',
			ANGULARJS_DESCRIPTION: 'AngularJS Seed project is single page web application scaffolding that can be used as a starting point for more feature-rich single page web application. It is structured by adopting module pattern and contains bunch of AngularJS libraries, third party libraries, HTML, CSS and re-usable assets to quickly jump start..',
			WELCOME_USER: 'Welcome',

			// HTML Field names
			
			//For signup screen
			FIRSTNAME_LBL:'First Name',
			LASTNAME_LBL:'Last Name',
			USERNAME_LBL:'User Name',
			EMAIL_LBL:'Email address',
			PASSWORD_LBL:'Password',
			CONFIRMPASSWORD_LBL:'Confirm Password',
			GENDER_LBL:'Gender',
			MALE_LBL:'Male',
			FEMALE_LBL:'Female',
			SUBMIT_LBL:'Submit',
			RESET_LBL:'Reset',
			LOGIN_LNK:'Already have an account ? Click here!!',
			SIGNUP_TITLE:'New User ? Signup',
			
			//For Login screen
			LOGIN_LBL:'Login',

			SIGNUP_LNK:'New User ? Signup here',
			
			//For Menus & Toolbars
			SIGNUP_LBL:'Signup',
			LOGOUT_LBL:'Log out',
			WELCOME_LBL:'Welcome',
			REMOVE_LBL: 'Remove',
			LIST: 'List',

			//footer.hmtl
			FOOTER_COPYRIGHT:'© 2014 Angular Seed Project',

			//For List screen
			SNO_LBL:'Serial Number',
			NAME_LBL:'Name',
			DESCRIPTION_LBL:'Description',
			STATUS_LBL:'Status',
			//For Remove screen
			ACTION_LBL: 'Action',
			DELETE_LBL: 'Delete',
			//For Edit screen
			MODIFY: 'Modify',
			EDIT_LBL: 'Edit',
			CANCEL: 'Cancel',

			//For Add screen
			ADD: 'Add',			
			Status: {'Open': 'Open','In-Progress': 'In-Progress','Closed': 'Closed'},
			Menu: {'List': 'List','Add': 'Add','Modify': 'Modify','Remove': 'Remove'},

			// Generic error validations 
			FIELD_REQUIRED:'This field cannot be blank',
			FIELDVALUE_TOO_LONG:'The value for this field is too long',
			FIELDVALUE_TOO_SHORT:'The value for this field is too short',
			TEXT_CHAR_ONLY:'Textual characters only',
			INVALID_EMAIL_FORMAT:'Invalid Email format',
			PASSWORD_NOT_SAME:'Password are not same!',
            
            // Scenario Specific error validations 
			USERNAME_REQUIRED:'Enter User name',
			PASSWORD_REQUIRED:'Enter Password',
			FIRSTNAME_REQUIRED:'Enter First name',
			EMAIL_REQUIRED:'Enter Email',
			NAME_REQUIRED: 'Enter name',
			DESCRIPTION_REQUIRED: 'Enter description',
			GENDER_REQUIRED:'Select a Gender',
			
			
			//popovers
			FIRSTNAME_POP: 'Enter first name',
			LASTNAME_POP: 'Enter last name',
			USERNAME_POP: 'Enter user name',
			EMAIL_POP: 'Enter email',
			PASSWORD_POP: 'Enter password',
			CONFIRMPASSWORD_POP: 'Confirm password',
			NAME_POP: 'Enter name',
			DESCRIPTION_POP: 'Enter description'
		});
		
		$translateProvider.translations('fr_FR',{
			// error or exception messages goes here
			ERROR_SC_0: 'Désolé! Nous rencontrons actuellement des difficultés techniques s\'il vous plaît essayer à nouveau plus tard.',
			ERROR_SC: 'Une erreur s\'est produite lors de l\'appel de repos Service.Please réessayer plus tard.',
			ERROR_02:'Désolé pour la gêne occasionnée. S\'il vous plaît contacter notre service d\'assistance 1800-200-2345',
			ERROR_03:'Nom d\'utilisateur ou mot de passe invalide !',
			ERROR_REST_TIMEOUT: 'Désolé! Reste Appel Timeout',
			AUTHENTICATION_FAILED:'Échec de l\'authentification.Pleaser réessayer.',
			SIGNUP_FAILED:'Se échoué.Pleaser réessayer.',


			//  success message
			SUCCESS_TRANSACTION: 'Opération terminée avec succès',	
			SUCCESS_RECORD_INSERTED:'Fiche Sucessfully Inséré',
			SUCCESS_RECORD_UPDATED:'Record Sucessfully Mise à jour',
			SUCCESS_RECORD_DELETED:'Fiche Sucessfully supprimés',

			// front end validation messages goes here	
			MINLENGTHEXP: 'S\'il vous plaît entrer une valeur minimale',
			NUMEXP: 'Entrez uniquement des chiffres!',
			MANDATORYEXP: 'Champ ne doit pas être vide',
			EMAILEXP: 'Entrez une adresse email valide Id',
			ISALPHABETEXP: 'La valeur doit être un-z / A-Z ',
			ISALPHANUMERICEXP: 'La valeur doit être un-z / A-Z et 1-9',
			ISDATEEXP: 'Entrez une date valide',

			// Label or  text content goes here 
			WELCOME_MESSAGE:'Bienvenue à Seed Project AngularJS',
			MAIN_SUBHEADING1:'Entrez AngularJS Caractéristiques et capacités des projets de semences',
			MAIN_SUBHEADING2:'AngularJS Caractéristiques et capacités des projets de semences',
			SNO:'#',
			HEADER_TITLE:'Projet de semences',
			FOOTER_TITLE:'projet de semences angulaire© 2014',
			ANGULARJS_DESCRIPTION: 'Projet Semences AngularJS est une application simple échafaudage page Web qui peut être utilisé comme un point de départ pour plus seule page application Web riche en fonctionnalités. Il est structuré en adoptant motif du module et contient tas de AngularJS bibliothèques, des tiers, HTML, CSS et actifs réutilisables pour sauter rapidement début ..',
			WELCOME_USER: 'Bienvenue',

			// HTML Field names
			//For signup screen
			FIRSTNAME_LBL:'prénom',
			LASTNAME_LBL:'nom de famille',
			USERNAME_LBL:'Nom d\'utilisateur',
			EMAIL_LBL:'Adresse e-mail',
			PASSWORD_LBL:'mot de passe',
			CONFIRMPASSWORD_LBL:'Confirmez le mot de passe',
			GENDER_LBL:'sexe',
			MALE_LBL:'mâle',
			FEMALE_LBL:'femelle',
			SUBMIT_LBL:'Proposez',
			RESET_LBL:'réinitialiser',
			LOGIN_LNK:'Vous avez déjà un compte ? Cliquez ici !!',
			SIGNUP_TITLE:'Nouvel utilisateur ? S\'inscrire',
			//For Login screen
			LOGIN_LBL:'Connexion',
			SIGNUP_LNK:'Nouvel utilisateur ? Abonnez-vous ici',
			//For Menus & Toolbars
			SIGNUP_LBL:'S\'inscrire',
			LOGOUT_LBL:'Déconnexion',
			WELCOME_LBL:'Bienvenue',
			REMOVE_LBL: 'Retirez',
			LIST: 'liste',

			//footer.hmtl
			FOOTER_COPYRIGHT:'© 2014 Projet de semences angulaire',

			//For List screen
			SNO_LBL:'le numéro de série',
			NAME_LBL:'nom',
			DESCRIPTION_LBL:'description',
			STATUS_LBL:'statut',

			//For Remove screen
			ACTION_LBL: 'action',
			DELETE_LBL: 'Supprimez',

			//For Edit screen
			MODIFY: 'modifier',
			EDIT_LBL: 'Modifier le',
			CANCEL: 'annuler',

			//For Add screen
			ADD: 'Ajoutez',
			Status: {'Open': 'ouvert','In-Progress': 'En cours','Closed': 'fermé'},
			Menu: {'List': 'liste','Add': 'ajouter','Modify': 'modifier','Remove': 'supprimer'},

			// Generic error validations
			FIELD_REQUIRED:'Ce champ ne peut être vide',
			FIELDVALUE_TOO_LONG:'La valeur de ce champ est trop long',
			FIELDVALUE_TOO_SHORT:'La valeur de ce champ est trop court',
			TEXT_CHAR_ONLY:'Caractères textuels ne',
			INVALID_EMAIL_FORMAT:'Format e-mail valide',
			PASSWORD_NOT_SAME:'Mot de passe ne sont pas identiques!',
			
			// Scenario Specific error validations
			USERNAME_REQUIRED:'Entrez le nom d\'utilisateur',
			PASSWORD_REQUIRED:'Entrez le mot de passe',
			FIRSTNAME_REQUIRED:'Entrez Prénom',
			EMAIL_REQUIRED:'Saisissez votre email',
			NAME_REQUIRED: 'Entrez le nom',
			DESCRIPTION_REQUIRED: 'Entrez description',
			GENDER_REQUIRED:'Sélectionnez un Sexe',
			
			//popovers
			FIRSTNAME_POP: 'Inscrivez le prénom',
			LASTNAME_POP: 'Entrez le nom',
			USERNAME_POP: 'Entrez le nom dutilisateur',
			EMAIL_POP: 'Entrez e-mail',
			PASSWORD_POP: 'Entrez le mot de passe',
			CONFIRMPASSWORD_POP: 'Confirmez le mot de passe',
			NAME_POP: 'Entrez le nom',
			DESCRIPTION_POP: 'Entrez description'
		});
			
        /* Explicitly set the preferred language */
		//$translateProvider.preferredLanguage('en_US');

		/* Determine automatically the preferred language based on users window.navigator object */
		$translateProvider.determinePreferredLanguage();

		/*If a translation id is not present in the particular language translation table, angular-translate
			will search for it in the registered fallback language i.e english translation table */
		$translateProvider.fallbackLanguage('en_US');
	}]);
});
