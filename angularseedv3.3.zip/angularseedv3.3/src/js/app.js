/**
*@ngdoc object
*@name app
*@requires app.capabilities
*@requires app.config
*@requires app.common
*@requires app.auth
*@requires app.util
*@requires app.common
*@requires ui.router
*@requires ui.bootstrap
*@requires AngularAOP
*@requires jmdobry.angular-cache
*@requires restangular
*@description
*<p>
* Application entry point, organize, initialize, inject dependencies
* and coordinates the various pieces of application.Loads sub modules
* and wire them up into the main module. Act as container
* for all angular managed objects or modules
* </p>
* @project AngularJS Seed 
* @timestamp
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define([
	'angular',
	'angular-animate',
	'angular-aop',
	'angular-cache',
	'angular-messages',
	'angular-sanitize',
	'angular-touch',
	'angular-translate',
	'angular-ui-bootstrap',
	'ui-route',
	'bootstrap-ui',
	'restangular',
	'./config/moduleLoader',
	'./util/moduleLoader',
	'./directives/moduleLoader',   
	//'./filters/moduleLoader',      Module to hold user defined angularjs filters 
	'./common/moduleLoader',
	'./auth/moduleLoader',
	'./capabilities/moduleLoader',
	'./interceptors/moduleLoader'
], function (angular) {
	'use strict';
	return angular.module('app', [
	'ngAnimate',
	'AngularAOP',
	'jmdobry.angular-cache',
	'ngMessages',
	'ngSanitize',
	'ngTouch',
	'ui.router',
	'ui.bootstrap',
	'restangular',
	'app.config',
	'app.util',
	'app.directives',
//	'app.filters',
	'app.common',
	'app.auth',
	'app.capabilities',
	'app.interceptors'
	

	]);
});
