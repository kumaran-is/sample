/**
*@ngdoc directive
*@name app.directives.pwCheck
*@description
* <P>
* Check for same password while signingup user
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['../module'], function (directives) {
    'use strict';
    directives.directive('pwCheck', [function () {
        return {
            require: 'ngModel',
             /**
             * @ngdoc method
             * @name app.directives.pwCheck#link
             * @methodOf app.directives.pwCheck
             
             * @param {object} scope password check
             * @param {object} elem password check
             * @param {object} attrs password check
             * @param {object} ctrl password check
             * @description   
             *
             */
            link: function (scope, elem, attrs, ctrl) {
                    var firstPassword = '#' + attrs.pwCheck;
                    elem.add(firstPassword).on('keyup', function () {
                        scope.$apply(function () {
                            var v = elem.val() === $(firstPassword).val();
                            ctrl.$setValidity('pwmatch', v);
                        });
                    });
            }
        };
    }]);    
});
