/**
* @fileoverview
* <P>
* Pagination Service
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['../module'], function(directivesModule) {
	'use strict';
	directivesModule.factory('paginationService',function(){
		return function (config) {
			var paginator = {
				pageSize: config.limit||10,
				pageNo: 1,
				includeRowIndex:config.includeRowIndex,
				displayHeaders: config.displayHeaders,
				objectKeys: config.objectKeys,
				hasNextItems: false,
				currentIndex: 0,
				dataLoader: config.dataLoader,
				_loadData: function(){
					var dataItems = this.dataLoader(this.currentIndex, (this.currentIndex + this.pageSize + 1));
					this.items = dataItems.slice(0, this.pageSize);
					this.hasNextItems = dataItems.length === this.pageSize + 1;
				},
				next: function (){
					this.currentIndex += this.pageSize;
					this._loadData();
					this.pageNo++;
				},
				previous: function (){
					var idx = this.currentIndex - this.pageSize;
					this.currentIndex = idx < 0 ? 0:idx;
					this._loadData();
					this.pageNo--;
				},
				hasPrevious: function (){
					return this.currentIndex > 0;
				},
				hasNext: function (){
					return this.hasNextItems;
				},
				pagInfo: function () {
					return 'Page No: ' + this.pageNo;
				},
				hasRecords: function (){
					return this.items && this.items.length > 0;
				},
				getRowIndex: function(index){
					return this.currentIndex + index + 1;
				}
			};
			paginator._loadData();
			return paginator;
		};
	});
});
