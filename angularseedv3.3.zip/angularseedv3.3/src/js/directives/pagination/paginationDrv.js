/**
* @fileoverview
* <P>
* Pagination
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['../module'], function (directivesModule) {
    'use strict';
    directivesModule.directive('paginationDrv',function(){
		return {
			templateUrl:'/src/partials/directives/pagination.html',
			restrict:'E',
			scope:{
				paginator:'=config'
			}
		};
	});
});
