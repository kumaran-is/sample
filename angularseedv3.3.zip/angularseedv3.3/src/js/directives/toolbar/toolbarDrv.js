﻿/**
*@ngdoc directive
*@name app.directives.toolDrv
*@description
* <P>
* Authentication toolbar
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/

define(['../module'], function (directives) {
    'use strict';
    directives.directive('toolDrv', ['authSrvc', 'cookieService',
        function (authSrvc, cookieService) {
        return {
            templateUrl: '/src/partials/directives/toolbar.html',
            restrict: 'E',
             /**
             * @ngdoc method
             * @name app.directives.toolDrv#link
             * @methodOf app.directives.toolDrv
             * @param {object} $scope authentication 
             * @description
             */
            link: function ($scope) {

                $scope.authenticated = authSrvc.isAuthenticated();
                $scope.currentUser = cookieService.currentUser;

                //Watcher for currentuser
                $scope.$watch(function () {
                    return cookieService.currentUser;
                }, function () {
                    $scope.currentUser = cookieService.currentUser;
                    $scope.authenticated = authSrvc.isAuthenticated();
                });

            }
        };
    }]);
});
