/**
* @fileoverview
*<p>
* Define and loads all the module components and act as container for all the components
* belongs to 'directives' module.
*</p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(
	[
		'./pagination/paginationDrv',
		'./pagination/paginationService',
		'./toolbar/toolbarDrv',
		'./menubar/menuService',
		'./menubar/menubarDrv',
		'./authDrv/pwCheck'
	], function () {
		'use strict';
});
