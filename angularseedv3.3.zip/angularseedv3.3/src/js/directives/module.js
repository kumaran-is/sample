/**
*@ngdoc object
*@name app.directives
*@requires app.directives.toolDrv
*@name app.directives.menuService
*@requires app.directives.menubarDrv
*@requires app.directives.pwCheck
*@description
*<p>
* Defines a  core module "app.directives" at global namespace.Modules are the logical entities that divides your app into smaller self 
* contained unit of functionality.It implements javascript module design pattern.
* that makes the code clear, consistent, understandable, and maintainable.
* This module is the entry point for 'directives' module, organize and  inject dependencies
* required for 'directives' module. Loads all the dependent module components.
* Also loads sub modules(if required) and wire them up into the 'directives' module.
* Act as container for all application wide reusable custom angularjs directives.
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['angular'], function (angular) {
	'use strict';
	return angular.module('app.directives', []);
});
