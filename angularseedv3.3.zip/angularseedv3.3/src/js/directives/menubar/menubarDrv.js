﻿/**
*@ngdoc directive
*@name app.directives.menubarDrv
*@description
* <P>
* Menu bar
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/

define(['../module'], function (directivesModule) {
    'use strict';

    directivesModule.directive('menubarDrv', 
        ['authSrvc','menuService', 'cookieService', 
        function (authSrvc,MenuService, cookieService) {
        return {
            templateUrl: '/src/partials/directives/menubar.html',
            restrict: 'E',
            controller: ['$scope', '$translate',function($scope, $translate){
              $scope.translate = $translate;
            }],
               /**
             * @ngdoc method
             * @name app.directives.menubarDrv#link
             * @methodOf app.directives.menubarDrv
             * @param {object} $scope success 
             * @description
             */
            link: function ($scope) {

                $scope.menus = [];
                 $scope.authenticated = authSrvc.isAuthenticated();
                var successCb = function (menus) {
                    $scope.menus = menus;
                };

                //Watcher for currentuser
                $scope.$watch(function () {                    
                    return cookieService.currentUser;
                }, function () {
                    if(cookieService.currentUser) {
                        MenuService.getMenu(successCb);
                         $scope.authenticated = authSrvc.isAuthenticated();
                    }
                });
            }
        };
    }]);
});
