﻿/**
*@ngdoc directive
*@name app.directives.menuService
*@description
* <P>
* Menu bar service
* </p> 
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/

define(['../module'], function (directivesModule) {
    'use strict';

    directivesModule.factory('menuService',['restClientFactory', '$q','appConfig', 
        function (restClientFactory, $q,appConfig) {
        var authRestangular = restClientFactory.getAuthRestangular();
        return {
             /**
             * @ngdoc method
             * @name app.directives.menuService#getMenu
             * @methodOf app.directives.menuService
             * @param {object} $successCb getMenu
             * @param {object} $successCb getMenu

             * @description
             */
            getMenu: function (successCb, errorCb) {
               authRestangular.one('menu').withHttpConfig( {timeout: appConfig.REST_REQ_TIMEOUT } )
               .get('').then(function (resp) {
                         console.log('menuService  response is >> ',resp);
                            successCb(resp);
                        },
                        function (resp) {
                            if (errorCb) {
                                errorCb(resp);
                            }
                        }
                    );
            }
        };
    }]);
});
