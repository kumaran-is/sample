/**
*@ngdoc service
*@name app.util.authInterceptors
*@description
* <p>
* Auth Interceptor Module to handle authentication & authorization pre-processing of 
* request or postprocessing of responses. Intercept requests before they are handed to
* the server and responses before they are handed
* over to the application code that initiated these requests
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.4
* @author Advanced Javascript Solutions COE
*/
define(['./module'], function (interceptorModule) {
	'use strict';

 
  /* Define custom auth interceptors to intercept REST request & reponse calls.
     Iterceptors are service factories injected with dependencies (if specified)
     and returns the interceptor */
	interceptorModule.factory('authInterceptor', 
		['$q', 'cookieService','ToastrSrvc','appConfig','logger',
		function($q, cookieService,ToastrSrvc,appConfig,logger){
       var log = logger.getLogger('authInterceptor');
		return {
						
         /* 
           Optional Method :request interceptors get called with a http config object. 
           The function is free to modify the config object or create a new one.The 
           function needs to return the config object directly,or a promise containing 
           the config or a new config object.
          */
        request: function(config) {
            log.debug('<<<<<<<< Inside authInterceptor request function() config is >>>>>>>>>>',config);
            console.log('<<<<<<<< Inside authInterceptor request function() config is >>>>>>>>>>',config);
              if (cookieService.currentUserInfo(appConfig.TOKEN)) {
                  config.headers['x-auth-token'] = cookieService.currentUserInfo(appConfig.TOKEN);
              }
              return config || $q.when(config);
          // return config;
        },

       
         /* 
           Optional Method :requestError interceptors gets called when a previous interceptor
           threw an error or resolved with a rejection.
          */
        requestError: function(errorRequest) {
            // do something on error
          log.error('<<<<<<<< Inside authInterceptor requestError function() errorRequest is >>>>>>>>>>',errorRequest );
            console.log('Inside authInterceptor requestError() method',errorRequest);
            return $q.reject(errorRequest);
          },
       
       /* 
           Optional Method :response interceptors get called with http response object. 
           The function is free to modify the response object or create a new one.The 
           function needs to return the response object directly, or as a promise containing 
           the response or a new response object. 
         */
          response: function(response) {
            log.debug('<<<<<<<< Inside authInterceptor response function() response is >>>>>>>>>>',response );
            //console.log('Inside authInterceptor response() method',response);
            return response;
          },

         /* optional Method : responseError interceptor gets called when a previous interceptor 
            threw an error or resolved with a rejection. */
         responseError: function(errorResponse) {
            // do something on error or recover from error by retrying REST calls
            log.error('<<<<<<<< Inside authInterceptor responseError function() errorResponse is >>>>>>>>>>',errorResponse );
            console.log('Inside authInterceptor responseError() method',errorResponse);
            if(errorResponse.status === 401)
            {
                ToastrSrvc.notifyError('Invalid Username or Password!');                
            }
            else if(errorResponse.status === 403) 
            {
                ToastrSrvc.notifyError('Auth Forbidden:Access Denied');                
            }
            else if(errorResponse.status === 419) 
            {
                ToastrSrvc.notifyError('Access Denied');                
            }
            return $q.reject(errorResponse);
          }
     };
  }]);
});
