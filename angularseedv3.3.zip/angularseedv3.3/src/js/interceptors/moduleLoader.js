/**
* @fileoverview
*<p>
* Define and loads all the module components and act as container for all the components
* belongs to 'Interceptors' module.
*</p>
* @project AngularJS Seed
* @Date
* @version 3.2
* @author Advanced Javascript Solutions COE
*/
define(
['./errorInterceptor',
'./authInterceptor'],
 function () {
'use strict';
 });
