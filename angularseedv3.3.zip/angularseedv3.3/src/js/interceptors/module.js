/**
*@ngdoc object
*@name app.util
*@requires app.interceptors.authInterceptor
*@description
*<p>
* Defines a core module "app.interceptors" at global namespace.
* This module is the entry point for 'interceptors' module, organize and  inject dependencies
* required for 'interceptors' module. Loads all the dependent module components.
* Also loads sub modules(if required) and wire them up into the 'interceptors' module.
* Act as container for all application wide reusable request & response Interceptors.
* </p>
* @project AngularJS Seed
* @Date
* @version 3.2
* @author Advanced Javascript Solutions COE
*/
define(['angular'], function (angular) {
	'use strict';
	return angular.module('app.interceptors', []);
});
