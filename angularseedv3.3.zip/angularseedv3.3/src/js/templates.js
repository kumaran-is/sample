/**
*@ngdoc overview
*@name templates
*@description
* <p>
*  To pre-load all the html partials in a javascript array into $templateCache
*  during start of the application for quick retrieval
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.2.0
* @author Advanced Javascript Solutions COE
*/
define('templates', ['./app'], function(app) { 
  'use strict';
  return app.run([function () {   
  }]);
});