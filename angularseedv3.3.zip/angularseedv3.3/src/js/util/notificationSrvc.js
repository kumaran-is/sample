/**
*@ngdoc service
*@name app.util.notificationSrvc
*@description
* <p>
* Service to display theerror messgaes either as modal window or toastr window.
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['./module'], function (utilModule) {
	'use strict';
	utilModule.factory('notificationSrvc',
		['appConfig',
		'ToastrSrvc',
		'PopupSrvc', 
		function(appConfig,ToastrSrvc,PopupSrvc){
		return {
			/**
             * @ngdoc method
             * @name app.util.notificationSrvc#notifyError
             * @methodOf app.util.notificationSrvc
             * @description To notify error messages in popup or in toastr
             * @param {object} msg Message to notify error        
             * @returns {object} message
             */
			notifySuccess:function(msg){
				if(appConfig.SHOW_SUCCESS_AS === 'popup'){
					PopupSrvc.notifySuccess(msg);
				}
				else{
					ToastrSrvc.notifySuccess(msg);
				}
			},
			/**
             * @ngdoc method
             * @name app.util.notificationSrvc#notifyError
             * @methodOf app.util.notificationSrvc
             * @description To notify success messages in popup or in toastr
             * @param {object} msg Message to notify success        
             * @returns {object} message
             */
			notifyError:function(msg){
				if(appConfig.SHOW_SUCCESS_AS === 'popup'){
					PopupSrvc.notifyError(msg);
				}
				else{
					ToastrSrvc.notifyError(msg);
				}
			}
		};
	}]);
});
