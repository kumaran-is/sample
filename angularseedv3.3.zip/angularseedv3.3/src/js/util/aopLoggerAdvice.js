/**
*@ngdoc service
*@name app.util.aopLoggerAdvice
*@description
* <p>
* Module defines cross-cuttinng  concerns (logging functionality-definition 
* of logging service which logs the method calls and thrown exception:) i.e advice as a
* separate service for Angular AOP(aopConfig.js). AOP applies aspect to all 
* service's methods.Logging mechanism is implemented using JavaScript logging
*  framework log4javascript 
* Read More: https://github.com/mgechev/angular-aop
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['./module','angular'], function (utilModule,angular) {
	'use strict';
	utilModule.factory('aopLoggerAdvice',['logger', function(logger){
		return function (args) {
			var log = logger.getLogger(args.method);
			if (args.exception) {
				log.error('%cException: '  +  args.exception.message  +  '. ' + 
				args.method  +  ' .',
				'color: red; text-weight: bold; font-size: 1.2em;');
			}
			var throwData = (args.exception) ? ' and threw: '  +  args.exception.message : '';
			log.debug('Method: '  +  args.method  +  ', Pointcut: '  +  args.when  +  ', with arguments: '  + 
			angular.toJson(args.args)  +  throwData  +  '   resolveArgs ' + args.resolveArgs +  '  rejectArgs ' + args.rejectArgs   +   ' result ' + args.result);
		};
	}]);
});
