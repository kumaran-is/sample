/**
*@ngdoc service
*@name app.util.defaultCache
*@description
* <p>
* On application startup cacheFactory creates one or more caches for short term 
* storage of data.This service allows application to temporarily cache the results
* that take time to fetch/compute.Cache service implemented using thirdparty 
* Angular-cache plugin.Angular-cache is a feature-packed drop-in replacement for 
* Angular's $cacheFactory.
* Read More : http://jmdobry.github.io/angular-cache/
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['./module'], function (utilModule) {
	'use strict';
	utilModule.run(['$angularCacheFactory',function($angularCacheFactory){
		$angularCacheFactory('defaultCache', {

			// This cache can hold 1000 items
            capacity: 1000,
			// Items added to this cache expire after 15 minutes.
			maxAge: 900000, 
			// This cache will clear itself every hour.
			cacheFlushInterval: 6000000, 
			// Items will be deleted from this cache right when they expire.
			deleteOnExpire: 'aggressive', 
			/* Cache can be  'localStorage' (or 'sessionStorage') that will sync itself 
			with browser `localStorage` or 'sessionStorage' */
			storageMode: 'localStorage' 
	
		});

		/*if needed set a default or global cache to  $http. Can override gobal cache using Local cache 
		for each service using  Restangular's  withHttpConfig   property*/
		//$http.defaults.cache = $angularCacheFactory.get('defaultCache');
	}]);
});
