/**
*@ngdoc service
*@name app.util.popupCtrl
*@description
* <p>
* To handle user action after showing success or failure message using modal window.
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['./module'], function (utilModule) {
	'use strict';
	utilModule.controller('popupCtrl',['$scope', '$modalInstance', 'message','title', function ($scope, $modalInstance, message,title) {
		$scope.title = title;
		$scope.message = message;
		/**
          * @ngdoc method
          * @name app.util.popupCtrl#ok
          * @methodOf app.util.popupCtrl
          * @description OK button in pop-up
          */
		$scope.ok = function () {
			$modalInstance.close();
		};
		/**
          * @ngdoc method
          * @name app.util.popupCtrl#cancel
          * @methodOf app.util.popupCtrl
          * @description CANCEL button in pop-up
          */
		$scope.cancel = function () {
			$modalInstance.dismiss('cancel');
		};
	}]);
});

