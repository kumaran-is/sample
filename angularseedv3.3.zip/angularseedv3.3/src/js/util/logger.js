/**
* @fileoverview
* <p>
* Module defines logging mechanism as a factory service  implemented using 
* JavaScript logging framework log4javascript.js 
* Read More:http://log4javascript.org/
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['./module','log4javascript'], function (utilModule,log4javascript) {
	'use strict';
	utilModule.factory('logger',['appConfig', function(appConfig){
		var loglevels = {
			ALL:log4javascript.Level.ALL,
			TRACE:log4javascript.Level.TRACE,
			DEBUG:log4javascript.Level.DEBUG,
			INFO:log4javascript.Level.INFO,
			WARN:log4javascript.Level.WARN,
			ERROR:log4javascript.Level.ERROR,
			FATAL:log4javascript.Level.FATAL,
			OFF:log4javascript.Level.OFF
		};
		return{
			
			getLogger:function(name){
				//enable(true) or disable(false) the log statement.Default is set to false. 
				log4javascript.setEnabled(appConfig.IS_LOG_ENABLED);
				if(name === undefined){
					name = 'defaultLogger';
				}
                
                // Create the logger
				var log = log4javascript.getLogger(name);
              
                
                //enable either AJAX appender or browser default console
				if(appConfig.IS_AJAXLOG_ENABLED)
				{

				/* Create Ajax Appender sends log messages asynchronously to a server via HTTP REST end point URL */
					var ajaxAppender = new log4javascript.AjaxAppender(appConfig.LOGGING_URL);
					//Formats the logging event as JSON.
					var jsonLayout = new log4javascript.JsonLayout(true,true);
					jsonLayout.setCustomField('sessionID','SOME ID ');
					// set configuration for  Ajax Appender
					ajaxAppender.addHeader('Content-Type','application/json');
					// set the layout to format the log messages
					ajaxAppender.setLayout(jsonLayout);
					// set log level. Default is set to 'ERROR'
					ajaxAppender.setThreshold(loglevels[appConfig.LOG_LEVEL]);
					/*Whether to send all remaining unsent log messages to the server when the page unloads. */
					ajaxAppender.setSendAllOnUnload(true);
					// Add the Ajax appender to the logger
					log.addAppender(ajaxAppender);
				}
				else
				{
					/* Create browser Appender to write log messages to the browser's built-in console 
					At present this works only in Safari, Opera and Firefox */
					var consoleAppender = new log4javascript.BrowserConsoleAppender();
					var simpleLayout = new log4javascript.SimpleLayout();
					consoleAppender.setLayout(simpleLayout);
					// set log level. Default is set to 'ERROR'
					consoleAppender.setThreshold(loglevels[appConfig.LOG_LEVEL]);
					log.addAppender(consoleAppender);
				}	

               
				return log;
			}
		};
	}]);
});
