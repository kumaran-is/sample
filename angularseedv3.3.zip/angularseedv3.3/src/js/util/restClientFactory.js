/**
*@ngdoc service
*@name app.util.RestangularProvider
*@description
* <p>
* Define different Restangular Service object with different REST end point configurations - 
* Base URL, Request & Response Interceptors ,default path variables and query params.
* Read More : https://github.com/mgonto/restangular#configuring-restangular
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['./module'], function (utilModule) {
	'use strict';

	//global Restangular object configuration (application wide)
	utilModule.config(['RestangularProvider',function(RestangularProvider) {
		
		// setting the global Base URL for REST API.
		RestangularProvider.setBaseUrl('http://www.abc.com');
		/*Execute some logic before sending request element to the server.Ex: appending
		the auth token  to every api request or request to external API can be used for
		analytics. Can add one or many interceptors and  they'll be called FIFO.*/
		RestangularProvider.setRequestInterceptor(function(element) {
			return element;
		});
		/*Executed some logic immediately after receiving the response from the server
		Can add one or many interceptors and  they'll be called FIFO.*/
		RestangularProvider.setResponseInterceptor(function(data) {
			return data;
		});
		/*Executed whenever there's an error. Place to handle in a single place within Restangular, increasing debugging capabilities. */
		/*
		RestangularProvider.setErrorInterceptor(
        function(response) {
       console.log('Inside setErrorInterceptor');
        //Handler error here
           if (response.status == 401) {
                console.log("Un Authorized,login required... ");
            }
            else if (response.status == 404) {
                console.log("Resource not available...");
            }
            else {
                console.log("Response received with HTTP error code: " + response.status );
            }
          return false; // stop the promise chain
      });*/
	}]);

   
    //Create and configure custom Restangular object that inherits global Restangular object
	utilModule.factory('restClientFactory',
	['appConfig',
	'Restangular',
	function(appConfig,Restangular){
		return {
           //connecting to mongoDb for capabilities services/ feature 1 services
				getFeature1Restangular:function(){
					return Restangular.withConfig(function(RestangularConfigurer) {
						//set custom Base URL for REST API.
						RestangularConfigurer.setBaseUrl(appConfig.CAPABILITIES_REST_ENDPOINT_BASEURL);
						//set default Query parameters to be sent with every request and every method.
						RestangularConfigurer.setDefaultRequestParams({ apiKey: 'GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X' });
						//overrides global configuration.			
						RestangularConfigurer.setRequestInterceptor(function(element) {
							return element;
						});

						/*configure the response extractor to filter/translate the orignal response data */  
						RestangularConfigurer.setResponseExtractor(function(response) {
							return response;
						});
					});
				},

				////connecting to nodejsSeed project for authentication services
				getAuthRestangular:function(){
					return Restangular.withConfig(function(RestangularConfigurer) {
						// set custom Base URL for REST API.
						RestangularConfigurer.setBaseUrl(appConfig.AUTH_REST_ENDPOINT_BASEURL);
						//overrides global configuration.			
						RestangularConfigurer.setRequestInterceptor(function(element) {
								return element;
						});

						/*configure the response extractor to filter/translate the orignal response data */  
						RestangularConfigurer.setResponseExtractor(function(response) {
							return response;
						});
					});
				}
				
			};
	}]);
});
