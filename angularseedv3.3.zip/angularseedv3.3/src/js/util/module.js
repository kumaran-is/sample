/**
*@ngdoc object
*@name app.util
*@requires app.util.cacheFactory
*@requires app.util.exceptionSrvc
*@requires app.util.popupSrvc
*@requires app.util.customInterceptors
*@requires app.util.toastrSrvc
*@requires app.util.restClientFactory
*@requires app.util.notificationSrvc
*@requires app.util.popupCtrl
*@requires app.util.aopLoggerAdvice
*@requires app.util.logger
*@description
*<p>
*  Defines a core module "app.util" at global namespace.Modules are the logical entities that divides your app into smaller self 
* contained unit of functionality.It implements javascript module design pattern.
* that makes the code clear, consistent, understandable, and maintainable.
* This module is the entry point for 'util' module, organize and  inject dependencies
* required for 'util' module. Loads all the dependent module components.
* Also loads sub modules(if required) and wire them up into the 'util' module.
* Act as container for all application wide reusable utility services & functions.
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['angular'], function (angular) {
	'use strict';
	return angular.module('app.util', ['restangular']);
});
