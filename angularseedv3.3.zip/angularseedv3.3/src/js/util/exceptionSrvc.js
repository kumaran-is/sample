/**
*@ngdoc service
*@name app.util.exceptionHandler
*@description
* <p>
* Any uncaught exception  is delegated to this Custom $exceptionHandler service.
* The default implementation simply delegates to $log.error which logs it into the browser
* console.This service is to simplify debugging and troubleshooting and notify the errors.
* This will override default behaviour of $exceptionHandler.
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['./module'], function (utilModule) {
	'use strict';

   /* Service decorator for $exceptionHandler provides you with a reference to the original 
     implementation if you want to use it as part of your custom implementation */
    utilModule.config(['$provide',function($provide) {
     
      $provide.decorator('$exceptionHandler',['$delegate','ToastrSrvc','logger',
        function($delegate,ToastrSrvc,logger) {
          var log = logger.getLogger('exceptionSrvc.js');
          return function(exception, cause) {
             // delegate on the original `$exceptionHandler` i.e. $log.error()
            $delegate(exception, cause);
            // Provide logic to handle error, display error or log error to server 
            var errorData = { 
              exception: exception, 
              cause: cause 
            };

            log.error('An error occurred', errorData);
            ToastrSrvc.notifyError(exception.message,errorData);
          };
        }
      ]);
    }]);

    /* To override default implementation of $exceptionHandler create service with same name. 
      Any uncaught exception in angular expressions is delegated to $exceptionHandlerservice.
      The default implementation simply delegates to $log.error which logs it into the
      browser console.*/
/*
	utilModule.factory('$exceptionHandler',['ToastrSrvc','logger',function(ToastrSrvc,logger){
		var log = logger.getLogger('exceptionSrvc.js');

		return function(exception){
			log.error('An error occurred', exception);
			ToastrSrvc.notifyError(exception.message);
		};
	}]);
	*/
});
