/**
*@ngdoc service
*@name app.util.PopupSrvc
*@description
* <p>
* To show the success or failure message using modal window.
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.1
* @author Advanced Javascript Solutions COE
*/
define(['./module'], function (utilModule) {
	'use strict';
	utilModule.factory('PopupSrvc',['$modal','appConfig', function($modal,appConfig){
		return {
			/**
             * @ngdoc method
             * @name app.util.PopupSrvc#notifyError
             * @methodOf app.util.PopupSrvc
             * @description To notify error messages
             * @param {object} msg Message to notify error        
             * @returns {object} message
             */
			notifyError:function(message){
				$modal.open({
					templateUrl: './partials/popup/popup.html',
					controller: 'popupCtrl',
					resolve: {
						title:function(){ 
							return appConfig.ERROR_MSG_TITLE;
						},
						message:function(){ 
							return message; 
						}
					}
				});
			},
			/**
             * @ngdoc method
             * @name app.util.PopupSrvc#notifyError
             * @methodOf app.util.PopupSrvc
             * @description To notify error messages
             * @param {object} msg Message to notify error        
             * @returns {object} message
             */
			notifySuccess:function(message){
				$modal.open({
					templateUrl: './partials/popup/popup.html',
					controller: 'popupCtrl',
					resolve: {
						title:function(){ 
							return appConfig.SUCCESS_MSG_TITLE;
						},
						message:function(){
						return message; 
						}
					}
				});
			}
		};
	}]);
});
