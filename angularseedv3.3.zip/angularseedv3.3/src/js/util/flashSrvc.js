/**
*@ngdoc service
*@name app.util.flashSrvc
*@description
* <p>
* Service to display a flash confirmation message (Sucess or Failure) after a user submitted a form .
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.4
* @author Advanced Javascript Solutions COE
*/
define(['./module'], function (utilModule) {
	'use strict';
	utilModule.factory('flashSrvc',
		['$rootScope',
		function($rootScope){
		return {
			/**
             * @ngdoc method
             * @name app.util.flashSrvc#show
             * @methodOf app.util.flashSrvc
             * @description To flash confirmation message to User
             * @param {object} msg Message to notify sucess or error        
             */
			show:function(msg){
				$rootScope.flash = msg;
			},
			/**
             * @ngdoc method
             * @name app.util.flashSrvc#clear
             * @methodOf app.util.flashSrvc
             * @description To clear cnfirmation message
             */
			clear:function(){
				$rootScope.flash = '';
			}
		};
	}]);
});
