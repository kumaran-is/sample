/**
*@ngdoc overview
*@name router
*@requires $stateProvider
*@requires $urlRouterProvider
*@description
*<p>
* To define application states,listens and routes application state change to
* appropriate controller and partials using ui-router. ui-router is a third Party AngularJS
* module developed by AngularJS team to support Nested/Parallel views .
* Read More : https://github.com/angular-ui/ui-router/wiki
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['./app'], function (app) {
	'use strict';
	return app.config(['$stateProvider','$urlRouterProvider',  
		function ($stateProvider, $urlRouterProvider) {
		// Redirect to default landing page/home page 
		$urlRouterProvider .when('','/seed/home');

          //application base layout or baseLayoutState(parent of all state)
		$stateProvider .state('baseLayoutState', {
             /* set abstract=true to parent state to  avoid rendering of parent view and it should be only inherited by child view  */
			'abstract':true,
			url:'',
			templateUrl:'partials/layouts/baseLayout.html'
		});

		//application baseLayoutState(parent of all state)
		$stateProvider.state('defaultPageState', {
             /* set abstract=true to parent state to  avoid rendering of parent view and it should be only inherited by child view  */
			'abstract':true,
			url:'/seed',
			parent:'baseLayoutState',
			views:{
				'north':{templateUrl:'partials/common/header.html',controller:'headerCtrl'},
				'south':{templateUrl:'partials/common/footer.html',controller:'footerCtrl'}
			}
		});
         
		/* define nested view for home page. A page can have only one state but can made of 
         one or more views to create a page. */ 
		$stateProvider .state('homePageState', {
			url:'/home',
			parent:'defaultPageState',
			views:{
				'center@baseLayoutState':{templateUrl:'partials/common/home.html'}
			},
			
			/*This callback function called when a state is entered.This functions have
			access to  the resolved data */	  	  
			onEnter: function(){
				console.log('entering onEnter callbackfunction homePageState ');
			},
			onExit: function(){
				console.log('entering onExit callbackfunction in homePageState');
			}
		});

         // Layout to display error page
		$stateProvider .state('errorLayoutState', {
             /* set abstract=true to parent state to  avoid rendering of parent view and it should be only inherited by child view  */
			'abstract':true,
			url:'/error',
			templateUrl:'partials/layouts/errorLayout.html'
		});

		// Page view  to display under maintenance page
		$stateProvider.state('underMaintenancePageState', {
			url:'/underMaintenance',
			parent:'errorLayoutState',
			views:{
				'center':{templateUrl:'partials/error/underMaintenance.html'}
			}
		});

		// Page view  to display technical issue page
		$stateProvider.state('technicalIssuePageState', {
			url:'/technicalIssue',
			parent:'errorLayoutState',
			views:{
				'center':{templateUrl:'partials/error/technicalIssue.html'}
			}
		});

		// when no match found redirect to default landing page or home page. 
		$urlRouterProvider .otherwise('/seed/home');
	}]);
});
