/**
* @fileoverview
* <p>
* Unit test suite for authRouter.js
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#auth -> authRouter', function () {
        var $rootScope, $state;

        beforeEach(function(){
	        module('app');   
            //Load all the templates for the router
            module('templates');  
	        inject(function(_$rootScope_, _$state_) {
	          	$rootScope = _$rootScope_;
	          	$state = _$state_;
	      	});
        });

	    /* Check the routing for homePageState */
	    describe('test the routing for listPageState', function() {
	        var initialState = "/login";	
	      	var state = 'loginPageState';

		    it('state should be /home initially', function() {
		        expect($state.href(state)).toEqual('#' + initialState);

		        var config = $state.get(state);
		    	expect(config.url).toEqual(initialState);
	      		expect(config.parent).toBe('baseLayoutState');
		    });

	      	it("state should change to the " + state, function(){
		        //Transition to the new state
		        $state.go(state);

		        $rootScope.$apply();
		        expect($state.current.name).toEqual(state);
	      	});
	    });
	});
});
