/**
* @fileoverview
* <P>
* Unit test suite for 'loginCtrl.js'
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Auth#Controllers -> authCtrl', function () {
        var angularSeedLoginCtrl, 
            loginCtrlScope,
            welcomeMessage;

        var $q, deferred, $state;

        //Mock loginSrvc and the data
        var loginService = {
            isAuthorized : function(authorizedRoles){
                return true;
            },
            isAuthenticated : function(){
                return true;
            },
            login: function(newFeature){                    
                deferred = $q.defer();
                return deferred.promise;
            }
        };
        //Load the app and mock dependencies
        beforeEach(function(){
            module('app');
            module('templates');
            
            //Mock loginService from $provide
            module(function($provide) {
                $provide.value('loginService', loginService);
            });
        });

        //Create controller for the test cases
        beforeEach(inject(
            function ($rootScope, $controller, _$q_, _appConfig_, $httpBackend, _$state_){
                $q = _$q_;
                $state = _$state_;

                //Store the baseUrl
                baseUrl = _appConfig_.CAPABILITIES_REST_ENDPOINT_BASEURL 
                            + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';
                $httpBackend.whenGET(baseUrl).respond(200, {});

                //Create controller
                loginCtrlScope = $rootScope.$new();
                angularSeedLoginCtrl = $controller('loginCtrl', { 
                        $scope: loginCtrlScope,
                });
        }));

        /* Test if loginCtrl is instantiated */
        it('should create angularSeedLoginCtrl', function() {
            expect(angularSeedLoginCtrl).toBeDefined();
        });

        /* Test $scope.createFeature method */
        it('loginFeature should match login credentials', function() {  
            //Creating spies for functions
            spyOn(loginCtrlScope, 'loginFeature').andCallThrough();
            spyOn(loginService, 'login').andCallThrough();

            //Update credentials object
            loginCtrlScope.credentials = {
                username: 'admin',
                password: 'admin'
            };
            loginCtrlScope.loginFeature();

            //Test if the methods have been called
            expect(loginCtrlScope.loginFeature).toHaveBeenCalled();
            expect(loginService.login).toHaveBeenCalled();

            //Resolve the promise and update scope
            deferred.resolve();
            loginCtrlScope.$root.$apply(); 

            //TODO - fix it - state not resolved correctly
            //Check the state
            // expect($state.current.name).toBe("listPageState");
        });
     
    });
});
