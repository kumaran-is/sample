/**
* @fileoverview
* <P>
* Unit test suite for 'regCtrl.js'
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Auth#Controllers -> registrationCtrl', function () {
        var angularSeedRegCtrl, 
            regCtrlScope,
            welcomeMessage;
        var $q, registrationSrvc, notificationSrvc;

        //Mock dependent services
        var registrationSrvc = {
            regUser: function(newUser){
                deferred = $q.defer();
                return deferred.promise;
            }
        };
        notificationSrvc = jasmine.createSpyObj('notificationSrvc', ['notifySuccess', 'notifyError']);

        //Load the app and mock dependencies
        beforeEach(function(){
            module('app');
            module('templates');
            
            //Mock registrationSrvc from $provide
            module(function($provide) {
                $provide.value('regSrvc', registrationSrvc);
                $provide.value('notificationSrvc', notificationSrvc);
            });
        });

        //Create controller for the test cases
        beforeEach(inject(
            function ($rootScope, $controller, _$q_, _appConfig_, $httpBackend){
                $q = _$q_;    
                
                //Store the baseUrl
                baseUrl = _appConfig_.CAPABILITIES_REST_ENDPOINT_BASEURL 
                            + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';
                $httpBackend.whenGET(baseUrl).respond(200, {});

                //Create controller
                regCtrlScope = $rootScope.$new();
                angularSeedRegCtrl = $controller('regCtrl', { 
                        $scope: regCtrlScope,
                });
        }));

        /* Test if regCtrl is instantiated */
        it('should create angularSeedRegCtrl', function() {
            expect(angularSeedRegCtrl).toBeDefined();
        });

        /* Test resetForm method */
        it('should reset form', function() {
            spyOn(regCtrlScope, 'resetForm');
            regCtrlScope.resetForm();

            //Check if the register object is empty
            expect(regCtrlScope.resetForm).toHaveBeenCalled();
            expect(Object.keys(regCtrlScope.register).length).toBeDefined(0);
        });

        /* Test regUser - success*/
        it('should register a new user - success', function() {  
            //Creating spies for functions
            spyOn(regCtrlScope, 'regUser').andCallThrough();    
            spyOn(registrationSrvc, 'regUser').andCallThrough();

            //Call the method
            regCtrlScope.credentials = {
                username : 'newUser',
                password : 'password'
            };
            regCtrlScope.regUser();

            //Test if the controller and service methods have been called
            expect(regCtrlScope.regUser).toHaveBeenCalled();
            expect(registrationSrvc.regUser).toHaveBeenCalled();

            //Resolve the promise
            deferred.resolve(regCtrlScope.credentials);
            regCtrlScope.$root.$digest(); //Required to resolve promise in 'controller'

            //Check the response
            expect(regCtrlScope.credentials).toBe('');
            expect(regCtrlScope.successMsg1).toBeDefined();
            expect(regCtrlScope.successMsg1).toBe('User registered successfully');
            expect(regCtrlScope.errMsg1).toBeUndefined();
        });

        /* Test regUser - failure */
        it('should register a new user - failure', function() {  
            //Creating spies for functions
            spyOn(regCtrlScope, 'regUser').andCallThrough();    
            spyOn(registrationSrvc, 'regUser').andCallThrough();

            //Call the method
            var newUser = {
                username : 'newUser',
                password : 'badpassword'
            }
            regCtrlScope.credentials = newUser;
            regCtrlScope.regUser();

            //Test if the controller and service methods have been called
            expect(regCtrlScope.regUser).toHaveBeenCalled();
            expect(registrationSrvc.regUser).toHaveBeenCalled();

            //Resolve the promise
            deferred.reject(regCtrlScope.credentials);
            regCtrlScope.$root.$digest(); //Required to resolve promise in 'controller'

            //Check the response
            expect(regCtrlScope.successMsg1).toBeUndefined();
            expect(regCtrlScope.errMsg1).toBeDefined();
            expect(regCtrlScope.errMsg1).toBe('User registration failed for user "' + 
                newUser.username + '"');
        });

        /* Test scope messages */
        it('test for the regCtrl scope messages', inject(function($translate) {  
            expect(regCtrlScope.textcharonly).toBe($translate('TEXTCHARONLY'));
            expect(regCtrlScope.firstnameerror).toBe($translate('FIRSTNAME'));
            expect(regCtrlScope.firstnamelimit).toBe($translate('FIRSTNAMELIMIT'));
            expect(regCtrlScope.lastnamelimit).toBe($translate('LASTNAMELIMIT'));
            expect(regCtrlScope.usernameerror).toBe($translate('USERNAME'));
            expect(regCtrlScope.usernamelimit).toBe($translate('USERNAMELIMIT'));
            expect(regCtrlScope.invalidemail).toBe($translate('INVALIDEMAIL'));
            expect(regCtrlScope.emailerror).toBe($translate('EMAIL'));
            expect(regCtrlScope.passworderror).toBe($translate('PASSWORD'));
            expect(regCtrlScope.cpassworderror).toBe($translate('CONFIRMPASSWORD'));
            expect(regCtrlScope.samepassworderror).toBe($translate('PASSWORDSAME'));
        }));
    });
});
