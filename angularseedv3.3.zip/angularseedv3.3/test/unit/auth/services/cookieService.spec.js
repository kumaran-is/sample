/**
* @fileoverview
* <p>
* Unit test suite for seedCapabilitySrvc.js
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#auth#Services -> cookieService', function () {
        var _cookieService;

        //Load the app and instantiate service before each test case
        beforeEach(function(){
                module('app');
                inject(function(cookieService){
                _cookieService = cookieService;
            });
        });

        /* Test if menuService is instantiated */
        it('should create angularSeedHeaderCtrl', function() {
            expect(_cookieService).toBeDefined();
        });

         

        /* Test getSeedFeatures method */
        it('add should get called', function() {
            //Creating spies for functions
            spyOn(_cookieService, 'add').andCallThrough();  

            //Invoke the method
            var getPromise = _cookieService.add();

            //Test if the controller and service methods have been called
            expect(_cookieService.add).toHaveBeenCalled();
        });

        it('clear should get called', function() {
            //Creating spies for functions
            spyOn(_cookieService, 'clear').andCallThrough();  

            //Invoke the method
            var getPromise = _cookieService.clear();

            //Test if the controller and service methods have been called
            expect(_cookieService.clear).toHaveBeenCalled();
        });

        it('isLogged should get called', function() {
            //Creating spies for functions
            spyOn(_cookieService, 'isLogged').andCallThrough();  

            //Invoke the method
            var getPromise = _cookieService.isLogged();

            //Test if the controller and service methods have been called
            expect(_cookieService.isLogged).toHaveBeenCalled();
        });

         it('updateUserInfo should get called', function() {
            //Creating spies for functions
            spyOn(_cookieService, 'updateUserInfo').andCallThrough();  

            //Invoke the method
            var getPromise = _cookieService.updateUserInfo();

            //Test if the controller and service methods have been called
            expect(_cookieService.updateUserInfo).toHaveBeenCalled();
            // expect(currentUser).toBeDefined();
            // expect(currentUserRoles).toBeDefined();
        });

        it('currentUserInfo should get called', function() {
            //Creating spies for functions
            spyOn(_cookieService, 'currentUserInfo').andCallThrough();  

            //Invoke the method
            var getPromise = _cookieService.currentUserInfo();

            //Test if the controller and service methods have been called
            expect(_cookieService.currentUserInfo).toHaveBeenCalled();
        });
    });
});
