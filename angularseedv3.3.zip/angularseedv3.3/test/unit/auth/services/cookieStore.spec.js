define(['angular', 'angular-mock'], function() {
    describe('#auth#Services -> cookieStore', function () {
        var _cookieStore;
        
        //Load the app and instantiate service before each test case
        beforeEach(function(){
                module('app');
                inject(function(cookieStore){
                _cookieStore = cookieStore
            });

        });

        /* Test if menuService is instantiated */
        it('should create cookieStore', function() {
            expect(_cookieStore).toBeDefined();
        });

       
        /* Test getSeedFeatures method */
        it('get should get called', function() {
            //Creating spies for functions
            spyOn(_cookieStore, 'get').andCallThrough();  

            //Invoke the method
            var getPromise = _cookieStore.get();

            //Test if the controller and service methods have been called
            expect(_cookieStore.get).toHaveBeenCalled();
        });
        //
        it('put should get called', function() {
            //Creating spies for functions
            spyOn(_cookieStore, 'put').andCallThrough();  

            //Invoke the method
            var getPromise = _cookieStore.put();

            //Test if the controller and service methods have been called
            expect(_cookieStore.put).toHaveBeenCalled();
        });
        //
        it('remove should get called', function() {
            //Creating spies for functions
            spyOn(_cookieStore, 'remove').andCallThrough();  

            //Invoke the method
            var getPromise = _cookieStore.remove();

            //Test if the controller and service methods have been called
            expect(_cookieStore.remove).toHaveBeenCalled();
        }); 
    });
});
