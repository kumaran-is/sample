/**
* @fileoverview
* <p>
* Unit test suite for registrationSrvc.js
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#auth#services -> registrationSrvc', function () {
        var registrationSrvc, restClientFactory;
        var $httpBackend, $translate, baseUrl, regUrl;
        var newUser = {
            username : 'newUser',
            password : 'password'
        };
        var errMsg = 'Application error';
        var notificationSrvc = jasmine.createSpyObj('notificationSrvc', ['notifySuccess', 'notifyError']);

        //Load the app and instantiate service before each test case
        beforeEach(function(){
            module('app');
            //Load all the templates for the router
            module('templates');
            
            //Mock registrationSrvc from $provide
            module(function($provide) {
                $provide.value('notificationSrvc', notificationSrvc);
            });
        });
        beforeEach(inject(
            function(_regSrvc_, _restClientFactory_, 
                    _$httpBackend_, _appConfig_, _$translate_){

                registrationSrvc = _regSrvc_;
                restClientFactory = _restClientFactory_;
                $httpBackend = _$httpBackend_;
                $translate = _$translate_;

                //Mock the http
                regUrl = _appConfig_.AUTH_REST_ENDPOINT_BASEURL 
                            + 'regUser' ;
                $httpBackend.expectPOST(regUrl).respond(200, newUser);
                baseUrl = _appConfig_.CAPABILITIES_REST_ENDPOINT_BASEURL 
                            + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';
                $httpBackend.whenGET(baseUrl).respond(200, {});
            }));

        /* Test if registrationSrvc is instantiated */
        it('registrationSrvc should have been defined', function() {
            expect(registrationSrvc).toBeDefined();
        });

        /* Test regUser method - promise resolve on success */
        it('regUser should register the user on success', function() {
            //Creating spies for functions
            spyOn(registrationSrvc, 'regUser').andCallThrough();  

            //Invoke the method
            var getPromise = registrationSrvc.regUser(newUser);
            getPromise.then(function(response){
                expect(response.username).toBeDefined();
                expect(response.username).toEqual(newUser.username);
                expect(response.password).toBeDefined();
                expect(response.password).toEqual(newUser.password);
                expect(notificationSrvc.notifySuccess)
                    .toHaveBeenCalledWith($translate('SUCCESS_CREATE'));
            });

            //Promise created -> should have invoked REST api, flush now
            $httpBackend.flush();

            //Test if the controller and service methods have been called
            expect(registrationSrvc.regUser).toHaveBeenCalled();

        });

        /* Test regUser method - promise reject on failure - if case */
        it('regUser should not register the user on failure - scenario 1', function() {
            //Creating spies for functions
            spyOn(registrationSrvc, 'regUser').andCallThrough(); 

            // Mock the http response
            $httpBackend.expectPOST(regUrl).respond(function(method, url, data){
                return [0, errMsg, {}];
            }); 

            //Invoke the method
            var getPromise = registrationSrvc.regUser(newUser);
            getPromise.then(function(response){
                    //Http response is an error, so this block is unused
                },
                function(msg, response){
                    expect(msg).toEqual('Something went wrong'); 
                    expect(response.status).toEqual(0);  
                    expect(notificationSrvc.notifyError)
                        .toHaveBeenCalledWith($translate('ERROR_SC_0'));                 
            });

            //Test if the controller and service methods have been called
            expect(registrationSrvc.regUser).toHaveBeenCalled();
        });

        /* Test regUser method - promise reject on failure - else case */
        it('regUser should not register the user on failure - scenario 2', function() {
            //Creating spies for functions
            spyOn(registrationSrvc, 'regUser').andCallThrough(); 

            // Mock the http response
            $httpBackend.expectPOST(regUrl).respond(function(method, url, data){
                return [404, errMsg, {}];
            }); 

            try {
                //Invoke the method
                var getPromise = registrationSrvc.regUser(newUser);
                getPromise.then(function(response){
                        //Http response is an error, so this block is unused
                    },
                    function(msg, response){                        
                        expect(msg).toEqual('Something went wrong'); 
                        expect(response.status).toEqual(0);  
                        expect(notificationSrvc.notifyError)
                            .toHaveBeenCalledWith($translate('ERROR_SC_0'));                 
                });
            } catch (err) {
                expect(err.message).toEqual(errMsg);
            }

            //Test if the controller and service methods have been called
            expect(registrationSrvc.regUser).toHaveBeenCalled();
        });
    });
});