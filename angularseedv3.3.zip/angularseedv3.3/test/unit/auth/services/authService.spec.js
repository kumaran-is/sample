/**
* @fileoverview
* <p>
* Unit test suite for seedCapabilitySrvc.js
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#auth#services -> authService', function () {
        var loginService, $httpBackend;
        var authorizedRoles = [1, 2]
        var credentials = {
            username : 'newUser',
            password : 'password'
        };
        var registrationResponse = {
            username : credentials.username,
            role : 1,
            token: 'newToken'
        };

        //Mock cookieService and the data
        var cookieService = {
            currentUser : 'admin', 
            currentUserRole : 1,
            isLogged : function (token){
                return true;
            }, 
            currentUserInfo : function (token){
                return {};
            },
            add : function(data){
                // console.log(data);
            },
            updateUserInfo : function (){},
            clear : function (){}
        };

        //Load the app and instantiate service before each test case
        beforeEach(function(){
            module('app');
            module('templates');
            
            //Registed mocked services
            module(function($provide) {
                $provide.value('cookieService', cookieService);
            });

            inject(function(_loginService_, _$httpBackend_, _appConfig_){
                loginService = _loginService_;
                $httpBackend = _$httpBackend_;

                //Mock http requests
                regUrl = _appConfig_.AUTH_REST_ENDPOINT_BASEURL 
                            + 'authenticate' ;
                $httpBackend.expectPOST(regUrl).respond(200, registrationResponse);

                baseUrl = _appConfig_.CAPABILITIES_REST_ENDPOINT_BASEURL 
                            + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';
                $httpBackend.whenGET(baseUrl).respond(200, {});
            });
        });

        /* Test if menuService is instantiated */
        it('authService should be defined', function() {
            expect(loginService).toBeDefined();
        });

        /* Test isAuthenticated method */
        it('isAuthenticated should work correctly', function() {
            //Creating spies for functions
            spyOn(loginService, 'isAuthenticated').andCallThrough();  

            //Invoke the method
            var isAuthenticated = loginService.isAuthenticated();

            //Test if the controller and service methods have been called
            expect(loginService.isAuthenticated).toHaveBeenCalled();
            expect(isAuthenticated).toBeTruthy();  
        });
        
        it('isAuthorized should work correctly', function() {
            //Creating spies for functions
            spyOn(loginService, 'isAuthorized').andCallThrough();  

            //Invoke the method
            var isAuthorized = loginService.isAuthorized(authorizedRoles);

            //Test if the controller and service methods have been called
            expect(loginService.isAuthorized).toHaveBeenCalled();
            expect(isAuthorized).toBeTruthy();
        });
       
        /* Test login success */
        it('login method test for success', function() {
            //Creating spies for functions
            spyOn(loginService, 'login').andCallThrough();  
            spyOn(cookieService, 'add').andCallThrough();  
            spyOn(cookieService, 'updateUserInfo').andCallThrough();  

            //Invoke the method
            var getPromise = loginService.login(credentials);
            getPromise.then(function(response){
                expect(cookieService.add).toHaveBeenCalledWith({ 
                    username: response.username, token: response.token, role: response.role 
                });
                expect(cookieService.updateUserInfo).toHaveBeenCalled();
            });

            //Promise created -> should have invoked REST api, flush now
            $httpBackend.flush();

            //Test if the controller and service methods have been called
            expect(loginService.login).toHaveBeenCalledWith(credentials);
        });
       
        /* Test login failure */
        it('login method test for failure', function() {
            //Creating spies for functions
            spyOn(loginService, 'login').andCallThrough();  
            spyOn(cookieService, 'clear').andCallThrough();  

            //Invoke the method
            $httpBackend.expectPOST(regUrl).respond(function(method, url, data){
                return [0, errMsg, {}];
            }); 
            var getPromise = loginService.login(credentials);
            getPromise.then(function(response){
                    //Http response is an error, so this block is unused
                }, function(msg, response){
                    expect(msg).toEqual('Something went wrong'); 
                    expect(response.status).toEqual(0);     
                    expect(cookieService.clear).toHaveBeenCalled();
            });

            //Test if the controller and service methods have been called
            expect(loginService.login).toHaveBeenCalledWith(credentials);
        });

        it('logout should work correctly', function() {
            //Creating spies for functions
            spyOn(loginService, 'logout').andCallThrough();  
            spyOn(cookieService, 'clear').andCallThrough();  
            spyOn(cookieService, 'updateUserInfo').andCallThrough();  

            //Invoke the method
            loginService.logout();

            //Test if the controller and service methods have been called
            expect(loginService.logout).toHaveBeenCalled();
            expect(cookieService.clear).toHaveBeenCalled();
            expect(cookieService.updateUserInfo).toHaveBeenCalled();
        });
       

        
    });
});
