/**
* @fileoverview
* <p>
* Unit test suite for router.js
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Config-> appStartUp', function () {
        var $rootScope, $state, $injector, $q, $httpBackend;

        //Mock loginSrvc and the data
        var loginService = {
        	isAuthorized : function() {
        		return false;
        	},
            isAuthenticated : function(){
                return true;
            }
        };

        beforeEach(function(){
	        module('app');   
            //Load all the templates for the router
            module('templates');   	 

		    //Register mocked services using $provide
            module(function($provide) {
                $provide.value('loginService', loginService);
            });	      
	             
	        inject(function(_$rootScope_, _loginService_) {
	          	$rootScope = _$rootScope_;
	          	loginService = _loginService_;
	      	});
        });

        describe('Events for appConfig.IS_OVERRIDE_HTTPHEADERS_ENABLED', function() {
        	beforeEach(inject(function(appConfig){
	          	//Enable state change events config
	          	appConfig.IS_OVERRIDE_HTTPHEADERS_ENABLED = true;        		
        	}));

        	it('check headers common for all requests', function(){
        		//console.log($http);
        		expect(true).toBeTruthy();
        	});
        });

        describe('Events for appConfig.IS_STATECHANG_EVENTS_ENABLED', function() {
        	beforeEach(inject(function(appConfig){
	          	//Enable state change events config
	          	appConfig.IS_STATECHANG_EVENTS_ENABLED = false;        		
        	}));

	        /* Test if the $stateChangeStart broadcast is proprogated properly */
			it("should test if the $stateChangeStart event is listened",function() {
				//Return true for the authorization check
				spyOn(loginService, 'isAuthorized').andReturn(false);
				 
				var next = {
					data : {
						authorizedRoles : [1, 2]
					}
				};
				$rootScope.$emit('$stateChangeStart', next);
				expect(loginService.isAuthorized).toHaveBeenCalled();
			});

	        /* Test if the $stateChangeSuccess broadcast is proprogated properly */
			it("should test if the $stateChangeSuccess event is listened",function() {
				$rootScope.$emit('$stateChangeSuccess');
				//Nothing to test, because method is empty
			});

	        /* Test if the $stateChangeError broadcast is proprogated properly */
			it("should test if the $stateChangeError event is listened",function() {
				$rootScope.$emit('$stateChangeError', event);

				//Nothing to test, because method is empty
			});

	        /* Test if the $stateNotFound broadcast is proprogated properly */
			it("should test if the $stateNotFound event is listened",function() {
				$rootScope.$emit('$stateNotFound', event);
				//Nothing to test, because method is empty
			});
		});
        describe('Events for appConfig.IS_VIEWCONTENT_EVENTS_ENABLED', function() {
        	beforeEach(inject(function(appConfig){
	          	//Enable state change events config
	          	appConfig.IS_VIEWCONTENT_EVENTS_ENABLED = true;        		
        	}));

        	it("should test if the $viewContentLoading event is listened", function(){
        		$rootScope.$emit('$viewContentLoading');


        	});
        	it("should test if the $viewContentLoaded event is listened", function(){
        		$rootScope.$emit('$viewContentLoaded');

        	});
        });

	});
});
