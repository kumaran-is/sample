/**
* @fileoverview
* <P>
* Unit test suite for 'footerCtrl.js'.
* </p> 
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Feature1#Controllers -> footerCtrl', function () {
        var angularSeedFooterCtrl, 
            footerCtrlScope,
            footerTitle;

        //Load the app and instantiate logger before all test cases
        beforeEach(module('app'));
        beforeEach(inject(
            function($rootScope, $controller, $translate){
                footerTitle = $translate('FOOTER_TITLE');
                footerCtrlScope = $rootScope.$new();
                angularSeedFooterCtrl = $controller('footerCtrl', { 
                        $scope: footerCtrlScope
                }
            );
        }));

        //Test if footerCtrl is instantiated
        it('should create angularSeedFooterCtrl', function() {
            expect(angularSeedFooterCtrl).toBeDefined();
        });
    });
});