/**
* @fileoverview
* <P>
* Unit test suite for 'headerCtrl.js'.
* </p> 
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Feature1#Controllers -> headerCtrl', function () {
        var angularSeedHeaderCtrl, 
            headerCtrlScope,
            headerTitle;

        //Mock loginSrvc and the data
        var loginService = {
            isAuthenticated : function(){
                return true;
            },
            logout : function(){
                return true;
            }
        };

        var cookieService = {
            currentUser : 'admin', 
            currentUserInfo : function (token){
                return {};
            }
        };

        //Load the app and instantiate logger before all test cases
        beforeEach(function(){
            module('app');
             //Register mocked services using $provide
            module(function($provide) {
                $provide.value('loginService', loginService);
                $provide.value('cookieService', cookieService);
            });

        });

        //Create an instance of the controller
        beforeEach(inject(
            function($rootScope, $controller, $translate){
                headerTitle = $translate('HEADER_TITLE');
                headerCtrlScope = $rootScope.$new();
                angularSeedHeaderCtrl = $controller('headerCtrl', { 
                        $scope: headerCtrlScope
                }
            );
        }));

        //Test if headerCtrl is instantiated
        it('should create angularSeedHeaderCtrl', function() {
            expect(angularSeedHeaderCtrl).toBeDefined();
        });

        it('should check for active scope', inject(function($location) {  
            //Spy on the isActive method
            spyOn(headerCtrlScope, 'isActive').andCallThrough();              
            
            //Test if the method has been called
            expect(headerCtrlScope.isActive).toBeDefined();   

            var isActive = headerCtrlScope.isActive('');
            expect(headerCtrlScope.isActive).toBeDefined(); 
            expect(isActive).toBeTruthy;
        }));

        it('should go to homepage after logout', function() {  
            //Spy on the logout method
            spyOn(headerCtrlScope, 'logout').andCallThrough();
            spyOn(loginService, 'logout').andCallThrough();

            headerCtrlScope.logout();
            expect(headerCtrlScope.logout).toHaveBeenCalled();
            expect(loginService.logout).toHaveBeenCalled();
        });
         it('should change the language', function() {  
            //Spy on the changelanguage method
            spyOn(headerCtrlScope, 'changeLanguage').andCallThrough();
            headerCtrlScope.changeLanguage();
            //Test if the method has been called
            expect(headerCtrlScope.changeLanguage).toHaveBeenCalled();
            
        });
    });
});