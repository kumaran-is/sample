/**
* @fileoverview
* <p>
* Unit test suite for toolDrv.js
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Directives -> toolbarDrv', function() {
        var $compile, $rootScope; 
        var baseUrl;

        //Mock loginSrvc and the data
        var loginService = {
            isAuthenticated : function(){
                return true;
            }
        };

        //Mock cookieService and the data
        var cookieService = {
            currentUser : 'admin', 
            currentUserInfo : function (token){
                return {};
            }
        }

        //Load the app and mock dependencies
        beforeEach(function(){
            module('app');  
            //Load all the templates for the router
            module('templates');     
            
            //Register mocked services using $provide
            module(function($provide) {
                $provide.value('loginService', loginService);
                $provide.value('cookieService', cookieService);
            });
        });

        //Store reference to the injected providers
        beforeEach(inject(function(_$compile_, _$rootScope_, appConfig, $httpBackend){
            $compile = _$compile_;
            $rootScope = _$rootScope_;
                
            //Store the baseUrl
            baseUrl = appConfig.CAPABILITIES_REST_ENDPOINT_BASEURL 
                        + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';
            //Since we load the bootstrap.js, it invokes router.js and the 
            //router loads the featurelist initially
            $httpBackend.whenGET(baseUrl).respond(200, {});
        }));

        /* Create the directive, check the scope values and placeholder values in the template */
        it('Replaces the element with the appropriate content', inject(function($translate) {
            //Create the directive element
            var element = angular.element("<tool-drv></tool-drv>");
            $compile(element)($rootScope);
            $rootScope.$digest();

            //Check authenticated value
            expect($rootScope.authenticated).toBeTruthy();

            // Check that the compiled element contains the toolbar items
            expect(element.html()).toContain($translate('WELCOME_LBL') + ', admin!');

            //Change the currentUser
            cookieService.currentUser = 'john';
            $rootScope.$digest();       

            // Check if the username changes in the toolbar
            expect(element.html()).toContain($translate('WELCOME_LBL') + ', john!');

            //Reset the currentUser
            cookieService.currentUser = 'admin';
        }));
    });
});
