/**
* @fileoverview
* <p>
* Unit test suite for menubarDrv.js
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Directives -> menubarDrv', function() {
        var $compile, $rootScope, $q, baseUrl; 

        //Mock cookieService and the data
        var cookieService = {
            currentUser : 'admin', 
            currentUserInfo : function (token){
                return {};
            }
        };

        //Mock menuService and the data       
        var mockMenuList = [{
                "item" : "list",
                "label" : "List",
                "url" : { "route" : "#/list" },
                "role" : ["1", "2"]
            },{
                "item" : "add",
                "label" : "Add",
                "url" : { "route" : "#/add" },
                "role" : "1"
            },{
                "item" : "modify",
                "label" : "Modify",
                "url" : { "route" : "#/modify" },
                "role" : "1"
            },{
                "item" : "remove",
                "label" : "Remove",
                "url" : { "route" : "#/remove" },
                "role" : "1"
        }];
        var menuService = { 
            getMenu: function(successCb, errorCb){
               successCb(mockMenuList);
            }
        };

        //Load the app and mock dependencies
        beforeEach(function(){
            module('app');

            //Load all the templates for the router
            module('templates'); 
            
            //Mock LoginService from $provide
            module(function($provide) {
                $provide.value('cookieService', cookieService);
                $provide.value('menuService', menuService);
            });
        });

        //Create an instance of the directive
        beforeEach(inject(
            function(_$compile_, _$rootScope_, _$q_, appConfig, $httpBackend){
            $compile = _$compile_;
            $rootScope = _$rootScope_;
            $q = _$q_;
                
            //Store the baseUrl
            baseUrl = appConfig.CAPABILITIES_REST_ENDPOINT_BASEURL 
                        + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';
            //Since we load the bootstrap.js, it invokes router.js and the 
            //router loads the featurelist initially
            $httpBackend.whenGET(baseUrl).respond(200, {});
        }));

        /* Create the directive, check the scope values and placeholder values in the template */
        it('Creates the menubar-drv element with the correct scope values', inject(function() {
            var element = angular.element("<menubar-drv></menubar-drv>");
            $compile(element)($rootScope);
            $rootScope.$digest();

            //Check the menus in scope
            expect($rootScope.menus).toBeDefined();
            expect($rootScope.menus.length).toBe(mockMenuList.length);

            // Check that the compiled element contains the menu
            for(menuIndex = 0; menuIndex < mockMenuList.length; menuIndex++) {
                expect(element.html()).toContain('<a href="' + mockMenuList[menuIndex].url.route 
                    +'" class="ng-binding">' + mockMenuList[menuIndex].label + '</a>');
            }
        }));
    });
});
