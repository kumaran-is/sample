/**
* @fileoverview
* <p>
* Unit test suite for menuService.js
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Directives#Menubars -> menuService', function () {
        var _menuService,  menuUrl, capUrl, $httpBackend;
        var errMsg = 'Page Not Found Error';
        var mockMenuList = [{
            "item" : "list",
            "label" : "List",
            "url" : { "route" : "#/list" },
            "role" : ["1", "2"]
        },{
            "item" : "add",
            "label" : "Add",
            "url" : { "route" : "#/add" },
            "role" : "1"
        },{
            "item" : "modify",
            "label" : "Modify",
            "url" : { "route" : "#/modify" },
            "role" : "1"
        },{
            "item" : "remove",
            "label" : "Remove",
            "url" : { "route" : "#/remove" },
            "role" : "1"
        }];

        //Load the app and mock dependencies
        beforeEach(function(){
            module('app');
            //Load all the templates for the router
            module('templates');    
        });

        //Load the app and instantiate service before each test case
        beforeEach(inject(function(menuService, appConfig, _$httpBackend_){
            _menuService = menuService;
            $httpBackend = _$httpBackend_;

            menuUrl = appConfig.AUTH_REST_ENDPOINT_BASEURL + "menu";
            capUrl = appConfig.CAPABILITIES_REST_ENDPOINT_BASEURL 
                        + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';
        }));

        /* Test if menuService is instantiated */
        it('should create menuService', function() {
            expect(_menuService).toBeDefined();
        });

        it("'getMenu' should return the menus", inject(function($httpBackend, appConfig){
            var url = appConfig.AUTH_REST_ENDPOINT_BASEURL + "menu";

            //Creating spies for functions
            spyOn(_menuService, 'getMenu').andCallThrough(); 

         // Create expectation
            $httpBackend.expectGET(menuUrl).respond(200, mockMenuList);
            $httpBackend.expectGET(capUrl).respond(200, {});

             //Invoke the method
            var successCb = function (menus) {
                expect(menus.length).toEqual(4);
                expect(JSON.stringify(menus) == JSON.stringify(mockMenuList)).toBeTruthy();
            };
            _menuService.getMenu(successCb, function(){});
            
            // flush response
            $httpBackend.flush();            
            expect(_menuService.getMenu).toHaveBeenCalled();        

        }));

        it("'getMenu' should handle http error", inject(function($httpBackend){
             //Creating spies for functions
            spyOn(_menuService, 'getMenu').andCallThrough(); 

            // Create expectation
            $httpBackend.expectGET(menuUrl).respond(function(method, url, data){
                return [404, errMsg, {}];
            });
            $httpBackend.expectGET(capUrl).respond(200, {});

            //Invoke the method
            var failureCb = function (response) {
                expect(response.data).toEqual(errMsg);
            };
            _menuService.getMenu(function(){}, failureCb);
            
            // flush response
            $httpBackend.flush();            
            expect(_menuService.getMenu).toHaveBeenCalled();        

        }));
    });
});
