/**
* @fileoverview
* <p>
* Unit test suite for pwCheck.js
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Directives -> pwCheck', function() {
        var baseUrl, element, registerForm;
        var $compile, $rootScope;
        var html ='<form name="registerForm" role="form">' 
                    + '<input name="password1" id="password1" ng-model="credentials.password1" />' 
                    + '<input name="password2" id="password2" ng-model="credentials.password2" pw-check="password1" />'
                    + '<div ng-show="registerForm.$error"><span class="valn" ng-show="registerForm.$error.pwmatch">'
                    + 'Passwords don\'t match.</span></div></form>';
        
        beforeEach(function(){
            module('app');
            module('templates');
        });

        beforeEach(inject(function (_$rootScope_, _$compile_, appConfig, $httpBackend) {
            $rootScope = _$rootScope_;
            $compile = _$compile_;

            //Store the baseUrl
            baseUrl = appConfig.CAPABILITIES_REST_ENDPOINT_BASEURL 
                        + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';
            $httpBackend.expectGET(baseUrl).respond(200, {});

            element = angular.element(html);
            $rootScope.credentials = {};
            $compile(element)($rootScope);
            $rootScope.$digest();
            registerForm = $rootScope.registerForm;
        }));

        it('both the passwords should match', function () {
            expect(registerForm.password1.$valid).toBe(true);
            registerForm.password1.$setViewValue('password1Val');
            expect($rootScope.credentials.password1).toBe('password1Val');

            registerForm.password2.$setViewValue('password2Val');
            expect($rootScope.credentials.password2).toBe('password2Val');

            //TODO check for form validation failure
            // expect(registerForm.$error.pwmatch).toBe(false);
        });
    });
});
