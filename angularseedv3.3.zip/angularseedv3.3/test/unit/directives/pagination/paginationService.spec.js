define(['angular', 'angular-mock'], function() {
	describe('#Directives -> paginationService', function() {
		var paginationService, paginator;
		var config = {
			limit : 10,
			includeRowIndex : true,
			displayHeaders : true,
			objectKeys : {},
			dataLoader : function(currIndex, offset){
				return ['item1', 'item2'];
			}
		};

		//Load the app and mock dependencies
		beforeEach (function () {
			module('app');
			module('templates');
		});

		//Load the app and instantiate service before each test case
		beforeEach (inject (function (_paginationService_, appConfig) {
			paginationService = _paginationService_;
			paginator = paginationService(config);
		}));

		/*Test if paginationService is instantiated*/
		it('should initiate paginationService', function() {
            expect(paginationService).toBeDefined();
        });

		/* Test pagination methods*/
		it('should return the next page', function () {
			spyOn(paginator, 'next').andCallThrough();  
			paginator.next();
            //Test if the controller and service methods have been called
            expect(paginator.next).toHaveBeenCalled();
		});

		it('should return the previous page', function() {
			spyOn(paginator, 'previous').andCallThrough();
			paginator.previous();
			//Test if the controller and service methods have been called
            expect(paginator.previous).toHaveBeenCalled();
		});

		it("'hasPrevious' should be called", function() {
			spyOn(paginator, 'hasPrevious').andCallThrough();
			paginator.hasPrevious();
			expect(paginator.hasPrevious).toHaveBeenCalled();
		});

		it("'hasNext' should be called", function() {
			spyOn(paginator, 'hasNext').andCallThrough();
			paginator.hasNext();
			expect(paginator.hasNext).toHaveBeenCalled();
		});

		it("'pagInfo' should be called", function() {
			spyOn(paginator, 'pagInfo').andCallThrough();
			paginator.pagInfo();
			expect(paginator.pagInfo).toHaveBeenCalled();
		});

		it("'hasRecords' should be called", function() {
			spyOn(paginator, 'hasRecords').andCallThrough();
			paginator.hasRecords();
			expect(paginator.hasRecords).toHaveBeenCalled();
		});

		it("'getRowIndex' should be called", function() {
			spyOn(paginator, 'getRowIndex').andCallThrough();
			paginator.getRowIndex();
			expect(paginator.getRowIndex).toHaveBeenCalled();
		});
	});
});