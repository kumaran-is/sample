define(['angular','angular-mock'],function(){
	xdescribe('#Utility ->Popup Controller',function(){
		
		//Create a local controller,scope and modalInstance
        var popupCtrlLocal, popupCtrlScope, modalInstance;

		// window.alert=function(text){
		// 	return true;
		// };

         //Load the app depedencies
        beforeEach(module('app'));

        //Inject the controller and modalInstance to use the variables within
        beforeEach(inject(function($rootScope, $controller, _$modal_) {
            
            popupCtrlScope = $rootScope.$new();

            modalInstance = _$modal_.open({
                templateUrl: '/src/partials/popup/popup.html'
            });

            popupCtrlLocal = $controller('popupCtrl', { 
                        $scope: popupCtrlScope, 
                        $modalInstance : modalInstance,
                        message : 'message',
                        title : 'title'          
            });
        }));

        /*Test if popupCtrl is created */
        it('should create popupCtrl', function() {
            expect(popupCtrlLocal).toBeDefined();
        });

        /*Test if ok method of popupCtrl is instantiated*/
        it('ok method should be called', function() {
            spyOn(popupCtrlScope, 'ok');
            spyOn(modalInstance, 'close');
            popupCtrlScope.ok();
            // expect(modalInstance.close).toHaveBeenCalled();
            expect(popupCtrlScope.ok).toHaveBeenCalled();
        });

        /*Test if cancel method of popupCtrl is instantiated*/
        it('cancel method should be called', function() {
            spyOn(popupCtrlScope, 'cancel');
            spyOn(modalInstance, 'dismiss');
            popupCtrlScope.cancel();
            expect(popupCtrlScope.cancel).toHaveBeenCalled();
            // expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
        });
    });

    describe('#Utility ->Popup Controller', function () {

      beforeEach(module('app'));

      var Ctrl;
      var scope;
      var modalInstance;

      // Initialize the controller and a mock scope
      beforeEach(inject(
        function ($controller, $rootScope) {     // Don't bother injecting a 'real' modal
          scope = $rootScope.$new();
          modalInstance = {                    // Create a mock object using spies
            close: jasmine.createSpy('modalInstance.close'),
            dismiss: jasmine.createSpy('modalInstance.dismiss'),
            result: {
              then: jasmine.createSpy('modalInstance.result.then')
            }
          };
          Ctrl = $controller('popupCtrl', {
            $scope: scope,
            $modalInstance: modalInstance,
            message : 'message',
            title : 'title'  
            // itemArray: function () { return ['a', 'b', 'c']; }
          });
        })
      );

      describe('Initial state', function () {
        it('should instantiate the controller properly', function () {
          expect(Ctrl).not.toBeUndefined();
        });

        it('should close the modal', function () {
          scope.ok();
        });

        it('should dismiss the modal when cancel', function () {
          scope.cancel();
        });
      });
    });
});

		

        