define(['angular', 'angular-mock'], function() {
    describe('#Utility -> customInterceptors', function () {
        var _customInterceptors;

        //Load the app and instantiate service before each test case
        beforeEach(function(){
                module('app');
                inject(function(customInterceptors){
                _customInterceptors = customInterceptors;
            });
        });

        /* Test if menuService is instantiated */
        it('should create utilModule', function() {
            expect(_customInterceptors).toBeDefined();
        });

        /* Test getSeedFeatures method */
        it('request should get called', function() {
            //Creating spies for functions
            spyOn(_customInterceptors, 'request').andCallThrough();  

            //Invoke the method
            var getPromise = _customInterceptors.request();

            //Test if the controller and service methods have been called
            expect(_customInterceptors.request).toHaveBeenCalled();

            
        });

        it('requestError should get called', function() {
            //Creating spies for functions
            spyOn(_customInterceptors, 'requestError').andCallThrough();  

            //Invoke the method
            var getPromise = _customInterceptors.requestError();

            //Test if the controller and service methods have been called
            expect(_customInterceptors.requestError).toHaveBeenCalled();

            
        });
        
        it('response should get called', function() {
            //Creating spies for functions
            spyOn(_customInterceptors, 'response').andCallThrough();  

            //Invoke the method
            var getPromise = _customInterceptors.response();

            //Test if the controller and service methods have been called
            expect(_customInterceptors.response).toHaveBeenCalled();

            
        });

        it('responseError should get called', function() {
            //Creating spies for functions
            spyOn(_customInterceptors, 'responseError').andCallThrough();

            var errorResponse = {
                'statusText': 'Unauthorized'
            }

            //Invoke the method
            _customInterceptors.responseError(errorResponse);


            //Test if the controller and service methods have been called
            expect(_customInterceptors.responseError).toHaveBeenCalled();

            
        });
    });
});
