/**
* @fileoverview
* <P>
* Unit test suite for 'createCtrl.js'
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Capabilities#Controllers -> createCtrl', function () {
        var angularSeedCreateCtrl, 
            createCtrlScope,
            welcomeMessage;

        var _q, deferred, baseUrl;

        //Mock seedCapabilitySrvc and the data
        var _seedCapabilitySrvc = {
                seedCapabilityStore: [{
                    _id : {
                        $oid : 1
                    },
                    name: "Jasmine - Unit tests",
                    Description: "Test cases covering the application using Jasmine",
                    Status: "In Progress"
                }],
                addSeedFeature: function(newFeature){
                    //Do not push, since the action is duplicated
                    //this.seedCapabilityStore.push(newFeature);
                    deferred = _q.defer();
                    return deferred.promise;
                }
        };

        //Mock getSeedCapabilityList
        var _getSeedCapabilityList = _seedCapabilitySrvc.seedCapabilityStore;

        //Load the app and mock dependencies
        beforeEach(function(){
            module('app');
            module('app.config');   
            //Load all the templates for the router
            module('templates');    
            
            //Mock getSeedCapabilityList from $provide
            module(function($provide) {
                $provide.value('getSeedCapabilityList', _getSeedCapabilityList);
            });
        });

        //Create controller for the test cases
        beforeEach(inject(
            function ($rootScope, $controller, $q, $httpBackend, _appConfig_){
                _q = $q;          
                
                //Store the baseUrl
                baseUrl = _appConfig_.CAPABILITIES_REST_ENDPOINT_BASEURL 
                            + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';
                //Since we load the bootstrap.js, it invokes router.js and the 
                //router loads the featurelist initially
                $httpBackend.whenGET(baseUrl).respond(200, {});

                //Create a new instance of the createCtrl
                createCtrlScope = $rootScope.$new();
                createCtrlScope.create = {
                    $valid: true,
                    $setPristine: function() {}
                };
                angularSeedCreateCtrl = $controller('createCtrl', { 
                        $scope: createCtrlScope,
                        getSeedCapabilityList : _getSeedCapabilityList,
                        seedCapabilitySrvc : _seedCapabilitySrvc
                });
        }));

        /* Test if createCtrl is instantiated */
        it('should create angularSeedCreateCtrl', function() {
            expect(angularSeedCreateCtrl).toBeDefined();
        });

        /* Test if welcome message is correct */
        it('should have the correct messages', inject(
            function ($translate) {
                expect(createCtrlScope.displayWelcomeMessage)
                    .toBe($translate('WELCOME_MESSAGE'));
                expect(createCtrlScope.subheading1)
                    .toBe($translate('MAIN_SUBHEADING1'));
                /*expect(mainCtrlScope.subheading2)
                    .toBe($translate('MAIN_SUBHEADING2'));*/
            })
        );

        /* Test $scope.createFeature method */
        it('createFeature should create the feature', function() {  
            //Creating spies for functions
            spyOn(createCtrlScope, 'createFeature').andCallThrough();    
            spyOn(_seedCapabilitySrvc, 'addSeedFeature').andCallThrough();      

            //Invoke the method
            var newFeature = {
                _id : {
                    $oid : 2
                },
                name: "New Feature",
                Description: "New Feature - Description",
                Status: "Added"
            };
            createCtrlScope.createFeature(newFeature);

            //Test if the controller and service methods have been called
            expect(createCtrlScope.createFeature).toHaveBeenCalled();
            expect(_seedCapabilitySrvc.addSeedFeature).toHaveBeenCalled();

            //Resolve the promise
            deferred.resolve(newFeature);
            createCtrlScope.$root.$digest(); //Required to resolve promise in 'controller'

            //Check the response
            expect(createCtrlScope.features.length).toBe(2);
        });
    });
});
