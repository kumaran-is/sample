/**
* @fileoverview
* <P>
* Unit test suite for 'deleteCtrl.js'
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Capabilities#Controllers -> deleteCtrl', function () {
        var angularSeedDeleteCtrl, 
            deleteCtrlScope,
            welcomeMessage;

        var _q, deferred, baseUrl;

        //Mock seedCapabilitySrvc and the data
        var _seedCapabilitySrvc = {
                removeSeedFeature: function(id){
                    deferred = _q.defer();
                    return deferred.promise;
                },
                getSeedFeatures: function(){
                    deferred = _q.defer();
                    return deferred.promise;
                }
        };

        //Mock getSeedCapabilityList
        var _getSeedCapabilityList = [{
            _id : {
                    $oid : 1
                },
                name: "Jasmine - Unit tests",
                Description: "Test cases covering the application using Jasmine",
                Status: "In Progress"
            }, {
                _id : {
                    $oid : 2
                },
                name: "Protractor - E2E tests",
                Description: "End to end test cases for the application using Protractor",
                Status: "Open"
            }, {
                _id : {
                    $oid : 3
                },
                name: "Feature to be deleted",
                Description: "Experimental feature",
                Status: "Open"
        }];

        //Load the app and mock dependencies
        beforeEach(function(){
            module('app');
            //Load all the templates for the router
            module('templates');       
            
            //Mock getSeedCapabilityList from $provide
            module(function($provide) {
                $provide.value('getSeedCapabilityList', _getSeedCapabilityList);
            });
        });

        //Create controller for the test cases
        beforeEach(inject(
            function ($rootScope, $controller, $q, $httpBackend, _appConfig_){
                _q = $q;      
                
                //Store the baseUrl
                baseUrl = _appConfig_.CAPABILITIES_REST_ENDPOINT_BASEURL 
                            + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';
                //Since we load the bootstrap.js, it invokes router.js and the 
                //router loads the featurelist initially
                $httpBackend.whenGET(baseUrl).respond(200, _getSeedCapabilityList);

                //Create a new instance of the deleteCtrl
                deleteCtrlScope = $rootScope.$new();
                angularSeedDeleteCtrl = $controller('deleteCtrl', { 
                        $scope: deleteCtrlScope,
                        getSeedCapabilityList : _getSeedCapabilityList,
                        seedCapabilitySrvc : _seedCapabilitySrvc
                });
        }));

        /* Test if deleteCtrl is instantiated */
        it('should create angularSeedDeleteCtrl', function() {
            expect(angularSeedDeleteCtrl).toBeDefined();
        });

        /* Test if welcome message is correct */
        it('should have the correct messages', inject(
            function ($translate) {
                expect(deleteCtrlScope.displayWelcomeMessage)
                    .toBe($translate('WELCOME_MESSAGE'));
                /*expect(createCtrlScope.subheading1)
                    .toBe($translate('MAIN_SUBHEADING1'));*/
                expect(deleteCtrlScope.subheading2)
                    .toBe($translate('MAIN_SUBHEADING2'));
            })
        );
          /* Test $scope.delete method */
        it('should get the feature', function() {    
            //Creating spies for functions
            spyOn(deleteCtrlScope, 'getfeaturelist').andCallThrough();                    
            spyOn(_seedCapabilitySrvc, 'getSeedFeatures').andCallThrough();

            //Invoke the method            
            deleteCtrlScope.getfeaturelist();

            //Test if the controller and service methods have been called
            expect(deleteCtrlScope.getfeaturelist).toHaveBeenCalled();
            expect(_seedCapabilitySrvc.getSeedFeatures).toHaveBeenCalled();

            //Resolve the promise
            deferred.resolve(_getSeedCapabilityList);
            deleteCtrlScope.$root.$digest(); //Required to resolve promise in 'controller'

            //Check the response - TODO update the logic
             expect(deleteCtrlScope.features.length).toBe(3);
        });

        /* Test $scope.delete method */
        it('delete should delete the feature', function() {    
            //Creating spies for functions
            spyOn(deleteCtrlScope, 'delete').andCallThrough();                    
            spyOn(_seedCapabilitySrvc, 'removeSeedFeature').andCallThrough();

            //Invoke the method
            var featureToDelete = {
                _id : {
                    $oid : 3
                }
            };
            deleteCtrlScope.delete(featureToDelete);

            //Test if the controller and service methods have been called
            expect(deleteCtrlScope.delete).toHaveBeenCalled();
            expect(_seedCapabilitySrvc.removeSeedFeature).toHaveBeenCalled();

            //Resolve the promise
            deferred.resolve(featureToDelete);
            deleteCtrlScope.$root.$digest(); //Required to resolve promise in 'controller'

            //Check the response - TODO update the logic
            expect(deleteCtrlScope.features.length).toBe(2);
        });
    });
});
