/**
* @fileoverview
* <P>
* Unit test suite for 'modifyCtrl.js'
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Capabilities#Controllers -> modifyCtrl', function () {
        var angularSeedModifyCtrl, 
            modifyCtrlScope,
            welcomeMessage;

        var _q, deferred, baseUrl;

         //Mock getSeedCapabilityList
        var _getSeedCapabilityList = [{
            _id : {
                    $oid : 1
                },
                name: "Jasmine - Unit tests",
                Description: "Test cases covering the application using Jasmine",
                Status: "In Progress"
            }, {
                _id : {
                    $oid : 2
                },
                name: "Protractor - E2E tests",
                Description: "End to end test cases for the application using Protractor",
                Status: "Open"
            }, {
                _id : {
                    $oid : 3
                },
                name: "Feature to be updated",
                Description: "Experimental feature",
                Status: "Open"
        }];

        //Mock seedCapabilitySrvc and the data
        var _seedCapabilitySrvc = {
            modifySeedFeature: function(modifiedData, id){
                deferred = _q.defer();                 
                for(var _id_= 0; _id_ < _getSeedCapabilityList.length ;_id_++){                 
                    if(id === _getSeedCapabilityList[_id_]._id.$oid) {
                        _getSeedCapabilityList[_id_].name=modifiedData.name;
                        _getSeedCapabilityList[_id_].Description=modifiedData.Description;
                        _getSeedCapabilityList[_id_].Status=modifiedData.Status;
                    }
                }
                return deferred.promise;
            },
            getSeedFeatures: function(){
                deferred = _q.defer();
                return deferred.promise;
            }
        };

        //Load the app and mock dependencies
        beforeEach(function(){
            module('app');
            //Load all the templates for the router
            module('templates');       
            
            //Mock getSeedCapabilityList from $provide
            module(function($provide) {
                $provide.value('getSeedCapabilityList', _getSeedCapabilityList);
            });
        });

        //Create controller for the test cases
        beforeEach(inject(
            function ($rootScope, $controller, $q, $httpBackend, _appConfig_){
                _q = $q;     
                
                //Store the baseUrl
                baseUrl = _appConfig_.CAPABILITIES_REST_ENDPOINT_BASEURL 
                            + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';
                //Since we load the bootstrap.js, it invokes router.js and the 
                //router loads the featurelist initially
                $httpBackend.whenGET(baseUrl).respond(200, {});

                //Create a new instance of the modifyCtrl
                modifyCtrlScope = $rootScope.$new();
                angularSeedModifyCtrl = $controller('modifyCtrl', { 
                        $scope: modifyCtrlScope,
                        getSeedCapabilityList : _getSeedCapabilityList,
                        seedCapabilitySrvc : _seedCapabilitySrvc
               });
        }));

        /* Test if modifyCtrl is instantiated */
        it('should create angularSeedModifyCtrl', function() {
            expect(angularSeedModifyCtrl).toBeDefined();
        });

        /* Test if welcome message is correct */
        it('should have the correct messages', inject(
            function ($translate) {
                expect(modifyCtrlScope.displayWelcomeMessage)
                    .toBe($translate('WELCOME_MESSAGE'));
                /*expect(createCtrlScope.subheading1)
                    .toBe($translate('MAIN_SUBHEADING1'));*/
                expect(modifyCtrlScope.subheading2)
                    .toBe($translate('MAIN_SUBHEADING2'));
            })
        );

         /* Test $scope.getfeaturelist method */
        it('should get the feature', function() {    
            //Creating spies for functions
            spyOn(modifyCtrlScope, 'getfeaturelist').andCallThrough();                    
            spyOn(_seedCapabilitySrvc, 'getSeedFeatures').andCallThrough();

            //Invoke the method            
           modifyCtrlScope.getfeaturelist();

            //Test if the controller and service methods have been called
            expect(modifyCtrlScope.getfeaturelist).toHaveBeenCalled();
            expect(_seedCapabilitySrvc.getSeedFeatures).toHaveBeenCalled();

            //Resolve the promise
            deferred.resolve(_getSeedCapabilityList);
            modifyCtrlScope.$root.$digest(); //Required to resolve promise in 'controller'

            //Check the response - TODO update the logic
             expect(modifyCtrlScope.features.length).toBe(3);
        });


        /* Test $scope.editFeature method */
        it('editFeature should set the edit feature mode', function() {    
            //Creating spies for functions
            spyOn(modifyCtrlScope, 'editFeature').andCallThrough();

            //Invoke the method
            var feature = {};
            modifyCtrlScope.editFeature(feature);

            //Test if the controller and service methods have been called
            expect(modifyCtrlScope.editFeature).toHaveBeenCalled();

            //Check the feature mode
            expect(feature.mode).toBe('editmode');
        });

        /* Test $scope.cancel method */
        it('cancel should cancel the edit mode', function() {   
            //Creating spies for functions
            spyOn(modifyCtrlScope, 'cancel').andCallThrough();

            //Invoke the method
            var feature = {};
            modifyCtrlScope.cancel(feature);

            //Test if the controller and service methods have been called
            expect(modifyCtrlScope.cancel).toHaveBeenCalled();

            //Check the feature mode
            expect(feature.mode).toBe('');
        });

        /* Test $scope.update method */
        it('update should update the feature', function() {    
            //Creating spies for functions
            spyOn(modifyCtrlScope, 'update').andCallThrough();            
            spyOn(_seedCapabilitySrvc, 'modifySeedFeature').andCallThrough(); 

           //Invoke the method
            modifyCtrlScope.features[2] = {
                _id : {
                    $oid : 3
                },
                name: "Updated name for feature",
                Description: "Updated description",
                Status: "Closed"
            };
            // modifyCtrlScope.update(updatedFeature);
            modifyCtrlScope.update(modifyCtrlScope.features[2]);

            //Test if the controller and service methods have been called
            expect(modifyCtrlScope.update).toHaveBeenCalled();
            expect(_seedCapabilitySrvc.modifySeedFeature).toHaveBeenCalled();

            //Resolve the promise
            deferred.resolve(modifyCtrlScope.features[2]);
            modifyCtrlScope.$root.$digest(); //Required to resolve promise in 'controller'
            
            //Check the response - TODO update the logic
            expect(_getSeedCapabilityList.length).toBe(3);
            expect(_getSeedCapabilityList[2].name).toBe(modifyCtrlScope.features[2].name);            
            expect(_getSeedCapabilityList[2].Description).toBe(modifyCtrlScope.features[2].Description);            
            expect(_getSeedCapabilityList[2].Status).toBe(modifyCtrlScope.features[2].Status);            
        });
    });
});
