/**
* @fileoverview
* <P>
* Unit test suite for 'listCtrl.js'
* </p>
* @project AngularJS Seed 
* @Date
* @version 3.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Capabilities#Controllers -> listCtrl', function () {
        var angularSeedListCtrl, 
            listCtrlScope,
            welcomeMessage;

        var _q, deferred, baseUrl;

        //Mock seedCapabilitySrvc and the data
        var _seedCapabilitySrvc = {
                getSeedFeatures: function(){
                    deferred = _q.defer();
                    return deferred.promise;
                }
        };
         //Mock getSeedCapabilityList
        var _getSeedCapabilityList = [{
            _id : {
                    $oid : 1
                },
                name: "Jasmine - Unit tests",
                Description: "Test cases covering the application using Jasmine",
                Status: "In Progress"
            }, {
                _id : {
                    $oid : 2
                },
                name: "Protractor - E2E tests",
                Description: "End to end test cases for the application using Protractor",
                Status: "Open"
            }, {
                _id : {
                    $oid : 3
                },
                name: "Feature to be listed",
                Description: "Experimental feature",
                Status: "Open"
        }];

        //Load the app and mock dependencies
        beforeEach(function(){
            module('app');
            module('templates');       
            
            //Mock getSeedCapabilityList from $provide
            module(function($provide) {
                $provide.value('getSeedCapabilityList', _getSeedCapabilityList);
            });
        });

        //Create controller for the test cases
        beforeEach(inject(
            function ($rootScope, $controller, $q, $httpBackend, _appConfig_){
                _q = $q;
                 //Store the baseUrl
                baseUrl = _appConfig_.CAPABILITIES_REST_ENDPOINT_BASEURL 
                            + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';
                //Since we load the bootstrap.js, it invokes router.js and the 
                //router loads the featurelist initially
                $httpBackend.whenGET(baseUrl).respond(200, _getSeedCapabilityList);

                //Create a new instance of the listCtrl
                listCtrlScope = $rootScope.$new();
                //creating controller
                angularSeedListCtrl = $controller('listCtrl', { 
                        $scope: listCtrlScope,
                        getSeedCapabilityList : _getSeedCapabilityList,
                        seedCapabilitySrvc : _seedCapabilitySrvc
                });
        }));

        /* Test if listCtrl is instantiated */
        it('should create angularSeedListCtrl', function() {
            expect(angularSeedListCtrl).toBeDefined();
        });

        /* Test if welcome message is correct */
        it('should have the correct messages', inject(
            function ($translate) {
                expect(listCtrlScope.displayWelcomeMessage)
                    .toBe($translate('WELCOME_MESSAGE'));
                expect(listCtrlScope.subheading1)
                    .toBe($translate('MAIN_SUBHEADING1'));
                expect(listCtrlScope.subheading2)
                    .toBe($translate('MAIN_SUBHEADING2'));
            })
        );
        /* Test $scope.getfeaturelist method */
        it('should get the feature', function() {    
            //Creating spies for functions
            spyOn(listCtrlScope, 'getfeaturelist').andCallThrough();                    
            spyOn(_seedCapabilitySrvc, 'getSeedFeatures').andCallThrough();

            //Invoke the method            
            listCtrlScope.getfeaturelist();

            //Test if the controller and service methods have been called
            expect(listCtrlScope.getfeaturelist).toHaveBeenCalled();
            expect(_seedCapabilitySrvc.getSeedFeatures).toHaveBeenCalled();

            //Resolve the promise
            deferred.resolve(_getSeedCapabilityList);
            listCtrlScope.$root.$digest(); //Required to resolve promise in 'controller'

            //Check the response - TODO update the logic
             expect(listCtrlScope.features.length).toBe(3);
        });
     });
});