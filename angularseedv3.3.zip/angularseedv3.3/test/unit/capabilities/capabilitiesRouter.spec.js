/**
* @fileoverview
* <p>
* Unit test suite for capabilitiesRouter.js
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#capabilities -> capabilitiesRouter', function () {
        var $rootScope, $state, $httpBackend;
        var baseUrl, runBlock;

        //Mock loginSrvc and the data
        var loginService = {
        	isAuthorized : function() {
        		return true;
        	},
            isAuthenticated : function(){
                return true;
            }
        };

        //Mock seedCapabilitySrvc and the data
        var seedCapabilitySrvc = {
                seedCapabilityStore: [{
                    _id : {
                        $oid : 1
                    },
                    name: "Jasmine - Unit tests",
                    Description: "Test cases covering the application using Jasmine",
                    Status: "In Progress"
                }],
                getSeedFeatures: function(){
                    return this.seedCapabilityStore;
                }
        };

        beforeEach(function(){
	        module('app');   
            //Load all the templates for the router
            module('templates');   

		    //Register mocked services using $provide
            module(function($provide) {
                $provide.value('loginService', loginService);
                $provide.value('seedCapabilitySrvc', seedCapabilitySrvc);
            });	      
        
	        inject(function(_$rootScope_, _$state_, _$httpBackend_, appConfig) {
	          	$rootScope = _$rootScope_;
	          	$state = _$state_;
	          	$httpBackend = _$httpBackend_;

	          	// Store the baseUrl
	          	baseUrl = appConfig.CAPABILITIES_REST_ENDPOINT_BASEURL 
	                      + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X'; 
		        // Mock the http response
		        $httpBackend.whenGET(baseUrl).respond(200, {});
	      	});
        });

	    /* Check the routing for listPageState */
	    describe('test the routing for listPageState', function() {
	        var stateUrl = "/list";	
	      	var state = 'listPageState', config;

	      	beforeEach(function(){
	      		config = $state.get(state);

	      		//Spy on the mock method
	      		spyOn(seedCapabilitySrvc, 'getSeedFeatures');
	      	});

		    it('state should be '+ stateUrl +' initially', function() {
		        expect($state.href(state)).toEqual('#' + stateUrl);
		    	expect(config.url).toEqual(stateUrl);
	      		expect(config.parent).toBe('baseLayoutState');
		    });

	      	it("state should change to the " + state, function(){

		        //Transition to the new state
		        $state.go(state);
		        $rootScope.$apply();
		        expect($state.current.name).toEqual(state);
	      	});

	      	it("Test onEnter (calls resolve internally) function of " + state + ' state', 
	      		inject(function($injector){
	    			//The resolve function should be defined
	    			expect(config.resolve.getSeedCapabilityList).toBeDefined();

	    			// Call invoke to inject dependencies and run function
	    			$injector.invoke(config.resolve.getSeedCapabilityList);
	    			expect(seedCapabilitySrvc.getSeedFeatures).toHaveBeenCalled();
	      	}));

	      	it("Test onExit (calls resolve internally) function of " + state + ' state', 
	      		inject(function($injector){
	      			$state.go("homePageState");
    				//TODO - figure out how to test onExit()
	      	}));
	    });

	    /* Check the routing for createPageState */
	    describe('test the routing for createPageState', function() {
	        var stateUrl = "/add";	
	      	var state = 'createPageState', config;

	      	beforeEach(function(){
	      		config = $state.get(state);
	      	});

		    it('state should be '+ stateUrl +' initially', function() {
		        expect($state.href(state)).toEqual('#' + stateUrl);
		    	expect(config.url).toEqual(stateUrl);
	      		expect(config.parent).toBe('baseLayoutState');
		    });

	      	it("state should change to the " + state, function(){
		        //Transition to the new state
		        $state.go(state);
		        $rootScope.$apply();
		        expect($state.current.name).toEqual(state);
	      	});

	      	it("Test onEnter (calls resolve internally) function of " + state + ' state', inject(function($injector){
	      		//Spy on the mock method
	      		spyOn(seedCapabilitySrvc, 'getSeedFeatures');

    			//The resolve function should be defined
    			expect(config.resolve.getSeedCapabilityList).toBeDefined();

    			//The resolve function should be called properly
    			config.resolve.getSeedCapabilityList(seedCapabilitySrvc);
    			expect(seedCapabilitySrvc.getSeedFeatures).toHaveBeenCalled();
	      	}));
	    });

	    /* Check the routing for modifyPageState */
	    describe('test the routing for modifyPageState', function() {
	        var stateUrl = "/modify";	
	      	var state = 'modifyPageState', config;

	      	beforeEach(function(){
	      		config = $state.get(state);
	      	});

		    it('state should be '+ stateUrl +' initially', function() {
		        expect($state.href(state)).toEqual('#' + stateUrl);
		    	expect(config.url).toEqual(stateUrl);
	      		expect(config.parent).toBe('baseLayoutState');
		    });

	      	it("state should change to the " + state, function(){
		        //Transition to the new state
		        $state.go(state);
		        $rootScope.$apply();
		        expect($state.current.name).toEqual(state);
	      	});

	      	it("Test onEnter (calls resolve internally) function of " + state + ' state', inject(function($injector){
	      		//Spy on the mock method
	      		spyOn(seedCapabilitySrvc, 'getSeedFeatures');

    			//The resolve function should be defined
    			expect(config.resolve.getSeedCapabilityList).toBeDefined();

    			//The resolve function should be called properly
    			config.resolve.getSeedCapabilityList(seedCapabilitySrvc);
    			expect(seedCapabilitySrvc.getSeedFeatures).toHaveBeenCalled();
	      	}));
	    });

	    /* Check the routing for deletePageState */
	    describe('test the routing for deletePageState', function() {
	        var stateUrl = "/remove";	
	      	var state = 'deletePageState', config;

	      	beforeEach(function(){
	      		config = $state.get(state);
	      	});

		    it('state should be '+ stateUrl +' initially', function() {
		        expect($state.href(state)).toEqual('#' + stateUrl);
		    	expect(config.url).toEqual(stateUrl);
	      		expect(config.parent).toBe('baseLayoutState');
		    });

	      	it("state should change to the " + state, function(){
		        //Transition to the new state
		        $state.go(state);
		        $rootScope.$apply();
		        expect($state.current.name).toEqual(state);
	      	});

	      	it("Test onEnter (calls resolve internally) function of " + state + ' state', inject(function($injector){
	      		//Spy on the mock method
	      		spyOn(seedCapabilitySrvc, 'getSeedFeatures');

    			//The resolve function should be defined
    			expect(config.resolve.getSeedCapabilityList).toBeDefined();

    			//The resolve function should be called properly
    			config.resolve.getSeedCapabilityList(seedCapabilitySrvc);
    			expect(seedCapabilitySrvc.getSeedFeatures).toHaveBeenCalled();
	      	}));
	    });
	});
});
