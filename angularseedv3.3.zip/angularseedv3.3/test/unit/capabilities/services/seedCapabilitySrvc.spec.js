/**
* @fileoverview
* <p>
* Unit test suite for seedCapabilitySrvc.js
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('#Feature1#Controllers -> seedCapabilitySrvc', function () {
        var seedCapabilitySrvc, restClientFactory;
        var $httpBackend;
        var baseUrl;
        var errMsg = 'Application error';

        //Mock the response for the list of features
        var mockFeaturesList = [{
                _id : {
                    $oid : 1
                },
                name: "Jasmine - Unit tests",
                Description: "Test cases covering the application using Jasmine",
                Status: "Completed"
            }, {
                 _id : {
                    $oid : 2
                },
                name: "Karma - Unit tests Automation",
                Description: "Jasmine unit test cases are automated using Karma",
                Status: "Testing"
            }
        ];

        //Load the app and instantiate service before each test case
        beforeEach(function(){
            module('app');
            //Load all the templates for the router
            module('templates');
        });
        beforeEach(inject(
            function(_seedCapabilitySrvc_, 
                    _restClientFactory_, 
                    _$httpBackend_, _appConfig_){
                seedCapabilitySrvc = _seedCapabilitySrvc_;
                restClientFactory = _restClientFactory_;
                $httpBackend = _$httpBackend_;

                //Store the baseUrl
                baseUrl = _appConfig_.CAPABILITIES_REST_ENDPOINT_BASEURL 
                            + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X';

                //Since we load the bootstrap.js, it invokes router.js and the 
                //router loads the featurelist initially
                $httpBackend.whenGET(baseUrl).respond(200, mockFeaturesList);
            }));

        /* Test if seedCapabilitySrvc is instantiated */
        it('should create angularSeedHeaderCtrl', function() {
            expect(seedCapabilitySrvc).toBeDefined();
        });

        /* Test getSeedFeatures method - promise resolve on success */
        it('getSeedFeatures should retrieve the seedFeatures list', function() {
            //Creating spies for functions
            spyOn(seedCapabilitySrvc, 'getSeedFeatures').andCallThrough();  

            //Invoke the method
            var getPromise = seedCapabilitySrvc.getSeedFeatures();
            getPromise.then(function(response){
                //console.log(response);
                expect(response.length).toBeDefined();
                expect(response.length).toEqual(2);
            });

            //Promise created -> should have invoked REST api, flush now
            $httpBackend.flush();

            //Test if the controller and service methods have been called
            expect(seedCapabilitySrvc.getSeedFeatures).toHaveBeenCalled();

        });

        /* Test getSeedFeatures method - promise reject on failure response - if loop */
        it('getSeedFeatures should handle http error - scenario 1', function() {
            //Creating spies for functions
            spyOn(seedCapabilitySrvc, 'getSeedFeatures').andCallThrough();  

            /* Test the 'if' branch of failure */
            // Mock the http response
            $httpBackend.whenGET(baseUrl).respond(function(method, url, data){
                return [0, errMsg, {}];
            });

            //Invoke the method
            var getPromise = seedCapabilitySrvc.getSeedFeatures();
            getPromise.then(function(response){
                    //Http response is an error, so this block is unused
                },
                function(response){
                    expect(response.status).toEqual(0);                   
            });

            //Promise created -> should have invoked REST api, flush now
            $httpBackend.flush();

            //Test if the controller and service methods have been called
            expect(seedCapabilitySrvc.getSeedFeatures).toHaveBeenCalled();
        });
        
        /* Test getSeedFeatures method - promise reject on failure response - else loop */
        it('getSeedFeatures should handle http error - scenario 2', function() {
            //Creating spies for functions
            spyOn(seedCapabilitySrvc, 'getSeedFeatures').andCallThrough(); 

            /* Test the 'else' branch of failure */
            // Mock the http response
            $httpBackend.whenGET(baseUrl).respond(function(method, url, data){
                return [404, errMsg, {}];
            });

            //Invoke the method
            try {
                var getPromise = seedCapabilitySrvc.getSeedFeatures();
                getPromise.then(function(response){
                        //Http response is an error, so this block is unused
                    },
                    function(response){
                        expect(response.status).toEqual(0);                   
                });
                //Promise created -> should have invoked REST api, flush now
                $httpBackend.flush();
            } catch(err){
                expect(err.message).toEqual(errMsg);
            }

            //Test if the controller and service methods have been called
            expect(seedCapabilitySrvc.getSeedFeatures).toHaveBeenCalled();
        });

        /* Test addSeedFeature method -- success */
        it('addSeedFeature  should retrieve the seedFeatures list', function() {
            //Creating spies for functions
            spyOn(seedCapabilitySrvc, 'addSeedFeature').andCallThrough();  

            // Mock the http response
            var successMsg = 'New feature added';
            $httpBackend.whenPOST(baseUrl).respond(function(method, url, data){
                return [200, successMsg, {}];
            });

            //Invoke the add method
            var newFeature = {              
                name: "New feature",
                Description: "New feature from add test case",
                Status: "Started"
            };
            var addPromise = seedCapabilitySrvc.addSeedFeature(newFeature);
            addPromise.then(function(response){
                expect(response).toBeDefined();
                expect(response).toEqual(successMsg);
            });

            //Promise created -> should have invoked REST api, flush now
            $httpBackend.flush();

            //Test if the controller and service methods have been called
            expect(seedCapabilitySrvc.addSeedFeature).toHaveBeenCalled();

        });

        /* Test addSeedFeature method -- failure */
        it('addSeedFeature  should handle http error - scenario 1', function() {
            //Creating spies for functions
            spyOn(seedCapabilitySrvc, 'addSeedFeature').andCallThrough();  

            // Mock the http response
            $httpBackend.whenPOST(baseUrl).respond(function(method, url, data){
                return [0, errMsg, {}];
            });

            //Invoke the add method
            var newFeature = {              
                name: "New feature",
                Description: "New feature from add test case",
                Status: "Started"
            };
            var addPromise = seedCapabilitySrvc.addSeedFeature(newFeature);
            addPromise.then(function(response){
                    //Http response is an error, so this block is unused
                },
                function(msg, response){
                    expect(msg).toEqual('Something went wrong');                   
            });

            //Promise created -> should have invoked REST api, flush now
            $httpBackend.flush();

            //Test if the controller and service methods have been called
            expect(seedCapabilitySrvc.addSeedFeature).toHaveBeenCalled();

        });

        /* Test addSeedFeature method -- failure - else loop*/
        it('addSeedFeature  should handle http error - scenario 2', function() {
            //Creating spies for functions
            spyOn(seedCapabilitySrvc, 'addSeedFeature').andCallThrough();  

            // Mock the http response
            $httpBackend.whenPOST(baseUrl).respond(function(method, url, data){
                return [404, errMsg, {}];
            });

            //Invoke the add method
            var newFeature = {              
                name: "New feature",
                Description: "New feature from add test case",
                Status: "Started"
            };

            try{
                var addPromise = seedCapabilitySrvc.addSeedFeature(newFeature);
                addPromise.then(function(response){
                        //Http response is an error, so this block is unused
                    },
                    function(msg, response){
                        expect(msg).toEqual('Something went wrong');                   
                });

                //Promise created -> should have invoked REST api, flush now
                $httpBackend.flush();
            } catch(err){
                expect(err.message).toEqual(errMsg);
            }

            //Test if the controller and service methods have been called
            expect(seedCapabilitySrvc.addSeedFeature).toHaveBeenCalled();

        });

        /* Test modifySeedFeature method -- success */
        it('modifySeedFeature  should retrieve the seedFeatures list', function() {
            //Creating spies for functions
            spyOn(seedCapabilitySrvc, 'modifySeedFeature').andCallThrough();  

            // Mock the http response
            var successMsg = 'Feature modified';
            $httpBackend.whenPUT(baseUrl).respond(200, function(method, url, data){
                return [200, successMsg, {}];
            });

            //Invoke the modify method
            var modifyPromise = seedCapabilitySrvc.modifySeedFeature();
            modifyPromise.then(function(response){
                expect(response).toBeDefined();
                expect(response).toEqual('Record Successfully Updated');
            });

            //Promise created -> should have invoked REST api, flush now
            $httpBackend.flush();

            //Test if the controller and service methods have been called
            expect(seedCapabilitySrvc.modifySeedFeature).toHaveBeenCalled();

        });

        /* Test modifySeedFeature method -- failure - if loop */
        it('modifySeedFeature should handle http error - if loop', function() {
            //Creating spies for functions
            spyOn(seedCapabilitySrvc, 'modifySeedFeature').andCallThrough();  

            // Mock the http response
            $httpBackend.whenPUT(baseUrl).respond(200, function(method, url, data){
                return [200, errMsg, {}];
            });

            //Invoke the modify method
            var modifyPromise = seedCapabilitySrvc.modifySeedFeature();
            modifyPromise.then(function(response){
                    //Http response is an error, so this block is unused
                },
                function(msg, response){
                    expect(msg).toEqual('Something went wrong');                   
            });

            //Promise created -> should have invoked REST api, flush now
            $httpBackend.flush();

            //Test if the controller and service methods have been called
            expect(seedCapabilitySrvc.modifySeedFeature).toHaveBeenCalled();

        });

         /* Test modifySeedFeature method -- failure - else loop */
        it('modifySeedFeature should handle http error - else loop', function() {
            //Creating spies for functions
            spyOn(seedCapabilitySrvc, 'modifySeedFeature').andCallThrough();  

            // Mock the http response
            $httpBackend.whenPUT(baseUrl).respond(200, function(method, url, data){
                return [404, errMsg, {}];
            });

            //Invoke the modify method
            try {
                var modifyPromise = seedCapabilitySrvc.modifySeedFeature();
                modifyPromise.then(function(response){
                        //Http response is an error, so this block is unused
                    },
                    function(msg, response){
                        expect(msg).toEqual('Something went wrong');                   
                });

                //Promise created -> should have invoked REST api, flush now
                $httpBackend.flush();
            } catch(err){
                expect(err.message).toEqual(errMsg);
            }

            //Test if the controller and service methods have been called
            expect(seedCapabilitySrvc.modifySeedFeature).toHaveBeenCalled();

        });

        /* Test removeSeedFeature method -- success */
        it('removeSeedFeature should retrieve the seedFeatures list', function() {
            //Creating spies for functions
            spyOn(seedCapabilitySrvc, 'removeSeedFeature').andCallThrough();  

            // Mock the http response
            var successMsg = 'Feature deleted';
            $httpBackend.whenDELETE(baseUrl).respond(function(method, url, data){
                return [200, successMsg, {}];
            });

            //Invoke the remove method
            var removePromise = seedCapabilitySrvc.removeSeedFeature();
            removePromise.then(function(response){
                expect(response).toBeDefined();
                expect(response).toEqual('Record Successfully Removed');
            });

            //Promise created -> should have invoked REST api, flush now
            $httpBackend.flush();

            //Test if the controller and service methods have been called
            expect(seedCapabilitySrvc.removeSeedFeature).toHaveBeenCalled();

        });

        /* Test removeSeedFeature method -- failure - if loop */
       it('removeSeedFeature should handle http error - if loop', function() {
            //Creating spies for functions
            spyOn(seedCapabilitySrvc, 'removeSeedFeature').andCallThrough();  

            // Mock the http response
            $httpBackend.whenDELETE(baseUrl).respond(function(method, url, data){
                return [0, errMsg, {}];
            });

            //Invoke the remove method
            var removePromise = seedCapabilitySrvc.removeSeedFeature();
            removePromise.then(function(response){
                    //Http response is an error, so this block is unused
                },
                function(msg, response){
                    expect(msg).toEqual('Something went wrong');                   
            });

            //Promise created -> should have invoked REST api, flush now
            $httpBackend.flush();

            //Test if the controller and service methods have been called
            expect(seedCapabilitySrvc.removeSeedFeature).toHaveBeenCalled();

        });
        
         /* Test removeSeedFeature method -- failure - else loop */
        it('removeSeedFeature should handle http error - else loop', function() {
            //Creating spies for functions
            spyOn(seedCapabilitySrvc, 'removeSeedFeature').andCallThrough();  

            // Mock the http response
            $httpBackend.whenDELETE(baseUrl).respond(function(method, url, data){
                return [404, errMsg, {}];
            });

            //Invoke the remove method
            try {
                var removePromise = seedCapabilitySrvc.removeSeedFeature();
                removePromise.then(function(response){
                        //Http response is an error, so this block is unused
                    },
                    function(msg, response){
                        expect(msg).toEqual('Something went wrong');                   
                });

                //Promise created -> should have invoked REST api, flush now
                $httpBackend.flush();
            } catch(err){
                expect(err.message).toEqual(errMsg);
            }

            //Test if the controller and service methods have been called
            expect(seedCapabilitySrvc.removeSeedFeature).toHaveBeenCalled();

        });
    });
});