/**
* @fileoverview
* <p>
* Unit test suite for router.js
* </p>
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
define(['angular', 'angular-mock'], function() {
    describe('ui-router', function () {
        var $rootScope, $state, $httpBackend;
        var baseUrl;

        beforeEach(function(){
	        module('app');   
            //Load all the templates for the router
            module('templates');   

	        //code to access run block
	     	//var authModule = module('app.auth');
		    // runBlock = authModule._runBlocks[0];	 
        
	        inject(function(_$rootScope_, _$state_, _$httpBackend_, 
	        				appConfig, _loginService_) {
	          	$rootScope = _$rootScope_;
	          	$state = _$state_;
	          	$httpBackend = _$httpBackend_;
	          	loginService = _loginService_;

	          	//Store the baseUrl
	          	baseUrl = appConfig.CAPABILITIES_REST_ENDPOINT_BASEURL 
	                      + 'angularseed?apiKey=GRq-WCLQv5ZQndgQp5L13tK9LaU6sQ_X'; 
		        // Mock the http response
		        $httpBackend.whenGET(baseUrl).respond(200, {});
	      	});
        });

	    /* Check the routing for homePageState */
	    describe('app/baseLayoutState', function() {
	        var initialState = '';	
	      	var state = 'baseLayoutState';
	      	var templateUrl = 'partials/layouts/baseLayout.html';

		    it('state should be ' + initialState + ' initially', function() {
		        expect($state.href(state)).toEqual(initialState);

		        var config = $state.get(state);
		    	expect(config.url).toEqual(initialState);
	      		expect(config.templateUrl).toBe(templateUrl);
		    });

	      	/* baseLayoutState - is an abstract state, 
	      		so transition test case is nor applicable */
	    });

	    /* Check the routing for homePageState */
	    describe('app/homePageState', function() {
	        var initialState = "/home";	
	      	var state = 'homePageState';

		    it('state should be /home initially', function() {
		        expect($state.href(state)).toEqual('#' + initialState);

		        var config = $state.get(state);
		    	expect(config.url).toEqual(initialState);
	      		expect(config.parent).toBe('baseLayoutState');
		    });

	      	it("state should change to the " + state, function(){
		        //Transition to the new state
		        $state.transitionTo(state);
		        $httpBackend.flush();

		        $rootScope.$apply();
		        expect($state.current.name).toEqual(state);
	      	});
	    });
	});
});
