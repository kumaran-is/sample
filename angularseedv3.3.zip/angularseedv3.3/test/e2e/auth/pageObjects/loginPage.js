/**
 * Created by 110159 on 7/28/2014.
 */

var loginPage = (function () {
    function loginPage() {
        //getting the login button element
        this.loginButton = element(by.css('[ng-click="loginFeature()"]'));

        //getting the login reference element
        this.loginReferenceTab = element(by.model('loginRef'));
    }

    loginPage.prototype.clickLoginButton = function () {
        this.loginButton.click();
    };

    loginPage.prototype.clickLogin = function () {
        this.loginReferenceTab.click();
    };

    return loginPage;
})();

module.exports = loginPage;
