/**
 * Created by 110159 on 7/28/2014.
 */

var signupPage = (function () {
    function signupPage() {
        //getting the login button element
        this.signupSubmitButton = element(by.css('[ng-click="login(credentials)"]'));

        //getting the signup reference element
        this.signupReferenceTab = element(by.model('signupRef'));
    }

    signupPage.prototype.clickSignUpButton = function () {
        this.signupSubmitButton.click();
    };

    signupPage.prototype.clickSignup = function () {
        this.signupReferenceTab.click();
    };

    return signupPage;
})();

module.exports = signupPage;
