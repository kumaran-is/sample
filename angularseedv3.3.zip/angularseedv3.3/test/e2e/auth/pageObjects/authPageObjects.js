/**
 * Created by 110159 on 7/28/2014.
 */

var authPage = (function () {
    function authPage() {
        //the home reference element
        this.homeReference = element(by.binding("'HEADER_TITLE' | translate"));

        //getting the login button element
        this.loginButton = element(by.css('[ng-click="loginFeature()"]'));

        //getting the login button element
        this.signupSubmitButton = element(by.css('[ng-click="regUser()"]'));
        //getting the login reference element
        this.loginReferenceTab = element(by.model('loginRef'));

        //getting the signup reference element
        this.signupReferenceTab = element(by.model('signupRef'));
    }

    authPage.prototype.clickHome = function () {
        this.homeReference.click();
    };
    
    authPage.prototype.clickLoginButton = function () {
        this.loginButton.click();
    };

    authPage.prototype.clickSignUpButton = function () {
        this.signupSubmitButton.click();
    };

    authPage.prototype.clickLogin = function () {
        this.loginReferenceTab.click();
    };

    authPage.prototype.clickSignup = function () {
        this.signupReferenceTab.click();
    };

    return authPage;
})();

module.exports = authPage;
