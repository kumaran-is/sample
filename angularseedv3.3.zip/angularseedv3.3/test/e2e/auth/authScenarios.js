/**
* @fileoverview
* <P>
* 
* </p> 
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
'use strict';

var authPage = require("./pageObjects/authPageObjects");
// var commonPage = require("../pageObjects/commonPage");

describe('Positive Auth AppTest', function() {
  // var featureCount;
  var testUserName = "admin";
  var testPassword = "admin";
  var page = new authPage();
  // var cpage = new commonPage();

  //this will fetch the browser home page
  browser.get('index.html');

  //functionality for Sign up Form
  describe('registration', function() {
    //performing the assertations to what will happen over click of submit
    it('should submit the login form', function() {
      page.clickSignup();
      expect(browser.getLocationAbsUrl()).toMatch("#/register");
    });

    //testing if the form has a input field of firstname 
    it('should have a firstname text box', function() {
      expect(element(by.model('credentials.firstName')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of lastname 
    it('should have a lastname text box', function() {
      expect(element(by.model('credentials.lastName')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of username 
    it('should have a username text box', function() {
      expect(element(by.model('credentials.userName')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of email 
    it('should have a email text box', function() {
      expect(element(by.model('credentials.email')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of password1 
    it('should have a password1 text box', function() {
      expect(element(by.model('credentials.password1')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of password2 
    it('should have a password2 text box', function() {
      expect(element(by.model('credentials.password2')).isPresent()).toBe(true);
    });

    //testing if the form has a radio field of gender 
    it('should have a password2 text box', function() {
      expect(element(by.model('credentials.gender')).isPresent()).toBe(true);
    });

    //inserting data into the fields 
    it('should fill the signup form details', function() {
      element(by.model('credentials.firstName')).sendKeys('Admin');
      element(by.model('credentials.lastName')).sendKeys('User');
      element(by.model('credentials.userName')).sendKeys(testUserName);
      element(by.model('credentials.email')).sendKeys('admin@gmail.com');
      element(by.model('credentials.password1')).sendKeys(testPassword);
      element(by.model('credentials.password2')).sendKeys(testPassword);
      element(by.model('credentials.gender')).click();
    });

    // it should check that the same password is written in both fields
    it('should check that the same password is written in both fields', function(){
      var checkPassword1 = element(by.model('credentials.password1'));
      var checkPassword2 = element(by.model('credentials.password2'));
      expect(checkPassword1.getText()).toEqual(checkPassword2.getText());
    });

    //performing the assertations to what will happen over click of submit
    it('should submit the signup form and the address changes to #/Home', function() {
      page.clickSignUpButton();
      expect(browser.getLocationAbsUrl()).toMatch("#/home");
    });
  });

  //functionality for login
  describe('authentication', function() {
    // should click on the login Reference tab
    it('should click on the login Reference tab and the address changes to #/login', function(){
      page.clickHome();
      browser.get('index.html#/login');
      // page.clickLogin();
      expect(browser.getLocationAbsUrl()).toMatch("#/login");
    });

    //testing if the form has a input field of username 
    it('should have a user name text box', function() {
      expect(element(by.model('credentials.username')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of password 
    it('should have a password text box', function() {
      expect(element(by.model('credentials.password')).isPresent()).toBe(true);
    });

    //inserting data into the fields 
    it('should fill the login credentials', function() {
      element(by.model('credentials.username')).sendKeys(testUserName);
      element(by.model('credentials.password')).sendKeys(testPassword);
    });

    //performing the assertations to what will happen over click of submit
    it('should submit the login form and the address changes to #/list', function() {
      page.clickLoginButton();
      expect(browser.getLocationAbsUrl()).toMatch("#/list");
    });
  });
});