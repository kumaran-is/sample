/**
* @fileoverview
* <P>
* 
* </p> 
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
'use strict';

var authPage = require("./pageObjects/authPageObjects");
// var commonPage = require("../pageObjects/commonPage");

describe('Negative Auth AppTest', function() {
  var featureCount;
  var testUserName = "admin123";
  var testUserName1 = "adminadminadminadminadminadminadmin";
  var testPassword = "admin123";
  var page = new authPage();

  // var cpage = new commonPage();

  //this will fetch the browser home page
  browser.get('index.html');

  //checking if the page is redirected to /home
  it('should continue from the previous test suite and thus the usl is #/Home ', function() {
    expect(browser.getLocationAbsUrl()).toMatch("#/home");
  });

/*
  // this module was used to detect the language 
  var testLang = element(by.binding('displayHeaderMessage')).getText();
  var lang = 'en';
  testLang.then(function (txt){
    if(txt=='Projet de semences'){
      lang='fr';
    }
    console.log('testLang = '+ txt);
    console.log('lang first = '+lang);
  });*/

  //functionality for Sign up Form
  describe('registration', function() {
    //performing the assertations to what will happen over click of submit
    it('should submit the login form', function() {
      page.clickSignup();
      expect(browser.getLocationAbsUrl()).toMatch("#/register");
    });

    //testing if the form has a input field of firstname 
    it('should have a firstname text box', function() {
      expect(element(by.model('credentials.firstName')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of lastname 
    it('should have a lastname text box', function() {
      expect(element(by.model('credentials.lastName')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of username 
    it('should have a username text box', function() {
      expect(element(by.model('credentials.userName')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of email 
    it('should have a email text box', function() {
      expect(element(by.model('credentials.email')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of password1 
    it('should have a password1 text box', function() {
      expect(element(by.model('credentials.password1')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of password2 
    it('should have a password2 text box', function() {
      expect(element(by.model('credentials.password2')).isPresent()).toBe(true);
    });

    //inserting data into the fields 
    it('should fill the signup form details with two different password', function() {
      element(by.model('credentials.firstName')).sendKeys('Admin');
      element(by.model('credentials.lastName')).sendKeys('User');
      element(by.model('credentials.userName')).sendKeys(testUserName);
      element(by.model('credentials.email')).sendKeys('admin@gmail.com');
      element(by.model('credentials.password1')).sendKeys(testPassword);
      element(by.model('credentials.password2')).sendKeys(testPassword+'1');
      element(by.model('credentials.gender')).click();
    });

    // it should check that the same password is written in both fields
    it('should check for wrong password the fields', function(){
      expect(element(by.binding("'PASSWORDSAME' | translate")).getText()).toEqual('Password are not same!');
    });

    /*//performing the assertations to what will happen over click of submit
    it('should not submit the signup form and the address changes to #/Home', function() {
      page.clickHome();
      expect(browser.getLocationAbsUrl()).toMatch("#/home");
    });*/
  });

  //functionality for login
  describe('authentication', function() {
    // should click on the login Reference tab
    it('should click on the login Reference tab and the address changes to #/login', function(){
      page.clickLogin();
      expect(browser.getLocationAbsUrl()).toMatch("#/login");
    });

    //testing if the form has a input field of username 
    it('should have a user name text box', function() {
      expect(element(by.model('credentials.username')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of password 
    it('should have a password text box', function() {
      expect(element(by.model('credentials.password')).isPresent()).toBe(true);
    });

    //inserting data into the fields 
    it('should fill some login credentials', function() {
      element(by.model('credentials.username')).sendKeys(testUserName);
      element(by.model('credentials.password')).sendKeys(testPassword);
      expect(element(by.css('[ng-show="login.username.$dirty && login.username.$error.pattern"]')).getText()).toBe('Textual characters only');
    });

    //clear the data into the fields 
    it('should clear the login credentials', function() {
      element(by.model('credentials.username')).clear();
      element(by.model('credentials.password')).clear();
    });

    //refill the data into the fields 
    it('should clear and refill someother login credentials', function() {
      element(by.model('credentials.username')).sendKeys(testUserName1);
      element(by.model('credentials.password')).sendKeys(testPassword);
      expect(element(by.css('[ng-show="login.username.$dirty && login.username.$error.maxlength"]')).getText()).toBe('User name cannot be longer than 30 characters');
    });

    //clear the data into the fields 
    it('should clear login credentials', function() {
      element(by.model('credentials.username')).clear();
      element(by.model('credentials.password')).clear();
      expect(element(by.css('[ng-show="login.username.$dirty && login.username.$error.required"]')).getText()).toBe('Enter User name');
    });

    //performing the assertations to what will happen over click of submit
    it('should not submit the login form and the address doesnot changes to #/Home instead it remains same', function() {
      expect(browser.getLocationAbsUrl()).toMatch("#/login");
    });
  });
});