/**
* @fileoverview
* <P>
* 
* </p> 
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
'use strict';

var CapabilitiesPage = require("../pageObjects/capabilities_page");

describe('Positive Capabilities AppTest', function() {
  var featureCount;
  var testUserName = "admin";
  var testPassword = "admin";
  var page = new CapabilitiesPage();

  //this will fetch the browser home page
  browser.get('index.html');

  //checking if the page is redirected to /home
  it('should redirect to /Home when location hash/fragment is empty/not', function() {
    page.clickHome();
    expect(browser.getLocationAbsUrl()).toMatch("#/home");
  });

  describe('List', function(){
    // should click on the List Reference tab
    it('should click on the List Reference tab and the address changes to #/List', function(){
      page.clickList();;
      expect(browser.getLocationAbsUrl()).toMatch("#/list");
    });

    it('should count the features in the list menu', function(){
      //getting the features count in the list menu
      featureCount = element.all(by.repeater('feature in features')).count();
      expect(featureCount).toBe(0);
      // displaying the count of features at first
      featureCount.then(function (txt){
            console.log('featureCount = ' + txt);
      });
    });
  });

  //functionality for adding feature
  describe('Add', function() {
    // should click on the Add Reference tab
    it('should click on the add Reference tab and the address changes to #/Add', function(){
      page.clickAdd();
      expect(browser.getLocationAbsUrl()).toMatch("#/add");
    });

    //testing if the form has a input field of name 
    it('should have a name text box', function() {
      expect(element(by.model('newfeatures.name')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of description 
    it('should have a description text box', function() {
      expect(element(by.model('newfeatures.Description')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of status 
    it('should have a status text box', function() {
      expect(element(by.model('newfeatures.Status')).isPresent()).toBe(true);
    });

    //inserting data into the fields 
    it('should fill the Add newfeatures', function() {
      element(by.model('newfeatures.name')).sendKeys('admin');
      element(by.model('newfeatures.Description')).sendKeys('User');
      element(by.model('newfeatures.Status')).sendKeys('Complete');
    });

    //performing the assertations to what will happen over click of submit
    it('should submit the login form and the address remains same', function() {
      page.clickAddSubmitButton();
      expect(browser.getLocationAbsUrl()).toMatch("#/add");
    });

    // counting the features after adding a feature
    it('should count the features in the list menu after adding a feature', function(){
      page.clickList();;
      //getting the features count in the list menu
      var addfeatureCount = element.all(by.repeater('feature in features')).count();
      expect(addfeatureCount).toBeGreaterThan(featureCount);
      // displaying the count of features at first
      addfeatureCount.then(function (txt){
            console.log('addfeatureCount = ' + txt);
      });
    });
  });

  //functionality for modify feature
  describe('modify', function() {
    // should click on the modify Reference tab
    it('should click on the modify Reference tab and the address changes to #/Modify', function(){
      page.clickModify();
      expect(browser.getLocationAbsUrl()).toMatch("#/modify");
    });

    //testing if the modify page has a input field of name after the click of edit button
    it('should click the edit button and should have a edit name text box', function() {
      page.clickEditButton();
      expect(element(by.model('feature.name')).isPresent()).toBe(true);
    });

    //testing if the edit form has a input field of description 
    it('should have a edit description text box', function() {
      expect(element(by.model('feature.Description')).isPresent()).toBe(true);
    });

    //testing if the edit form has a input field of status 
    it('should have a edit status text box', function() {
      expect(element(by.model('feature.Status')).isPresent()).toBe(true);
    });

    // the element in the edit form are being updated
    it('should update the values in the edit form',function() {
      var firstRow = element(by.repeater('feature in features').row(0));
      firstRow.element(by.model('feature.name')).clear().sendKeys('updatedName');
      firstRow.element(by.model('feature.Description')).clear().sendKeys('updatedDescription');
      firstRow.element(by.model('feature.Status')).clear().sendKeys('updatedStatus');
    });

    //performing the assertations to what will happen over click of update
    it('should update the edit form and checking the values in the row after updating', function() {
      page.clickModifyButton();
      //getting all the features by the help of repeater
      var featureRows = element.all(by.repeater('feature in features'));
      //promise function and inside promise getting the first row
      featureRows.then(function (rows) {
          var featureFirstRow = featureRows.get(0);
          // checking whether the element is present or not by tagName and then again promise as it is very helpful and easy
          featureFirstRow.isElementPresent(by.tagName('td')).then(function (isTdPresent){
            // logical condition if TRUE
            if (isTdPresent) {
              // getting the first row details
              var firstRowColName = featureFirstRow.element(by.binding('feature.name'));
              var firstRowColDescription = featureFirstRow.element(by.binding('feature.Description'));
              var firstRowColStatus = featureFirstRow.element(by.binding('feature.Status'));
              // then apply the promise to assert the text in Name Input
              firstRowColName.then(function (el) {
                  el.getText().then(function (txt) {
                    expect(txt).toContain('updatedName');
                    console.log("Item name  " + txt);
                  });
              });
              // then apply the promise to assert the text in description Input
              firstRowColDescription.then(function (el) {
                  el.getText().then(function (txt) {
                    expect(txt).toContain('updatedDescription');
                    console.log("Item name  " + txt);
                  });
              });
              // then apply the promise to assert the text in status Input
              firstRowColStatus.then(function (el) {
                  el.getText().then(function (txt) {
                    expect(txt).toContain('updatedStatus');
                    console.log("Item name  " + txt);
                  });
              });
            }
          });
      });
     /* var newUpdateFeatureCount = element.all(by.css('[ng-click="editFeature(feature)"]')).count();
      // expect(newUpdateFeatureCount).toBeGreaterThan(featureCount);
      // displaying the count of features after updating
      newUpdateFeatureCount.then(function (txt){
        console.log('newUpdateFeatureCount = ' + txt);
      });*/
    });
    
    //performing the assertations to what will happen over click of submit
    it('should check that the address remains same after Modify is clicked', function() {
      expect(browser.getLocationAbsUrl()).toMatch("#/modify");
    });

    // counting the features after modifying a feature
    it('should count the features in the list menu after modifying a feature', function(){
      page.clickList();;
      //getting the features count in the list menu
      var modifyfeatureCount = element.all(by.repeater('feature in features')).count();
      expect(modifyfeatureCount).toBeGreaterThan(featureCount);
      // displaying the count of features 
      modifyfeatureCount.then(function (txt){
            console.log('modifyfeatureCount = ' + txt);
      });
    });
  });

  describe('cancel', function(){
    //performing the assertations to what will happen over click of cancel
    it('should cancel in the edit form after updating', function() {
      page.clickModify();
      // clickin the edit button
      page.clickEditButton();

      //fetching the row in which the changes are to be done
      var firstRow = element(by.repeater('feature in features').row(0));

      // making changes in the fields
      firstRow.element(by.model('feature.name')).clear().sendKeys('updatednameedit');
      firstRow.element(by.model('feature.Description')).clear().sendKeys('updateddescriptionedit');
      firstRow.element(by.model('feature.Status')).clear().sendKeys('updatedstatusedit');

      // clickin the cancel button
      page.clickCancelButton();
    });

    //performing the assertations to what will happen over click of cancel
    it('should go to the list tab for refreshing and verify the changes', function() {
      page.clickList();;
      page.clickModify();

      //getting all the features by the help of repeater
      var featureRows = element.all(by.repeater('feature in features'));
      //promise function and inside promise getting the first row
      featureRows.then(function (rows) {
          var featureFirstRow = featureRows.get(0);
          // checking whether the element is present or not by tagName and then again promise as it is very helpful and easy
          featureFirstRow.isElementPresent(by.tagName('td')).then(function (isTdPresent){
            // logical condition if TRUE
            if (isTdPresent) {
              // getting the first row details
              var firstRowColName = featureFirstRow.element(by.binding('feature.name'));
              var firstRowColDescription = featureFirstRow.element(by.binding('feature.Description'));
              var firstRowColStatus = featureFirstRow.element(by.binding('feature.Status'));
              // then apply the promise to assert the text in Name Input
              firstRowColName.then(function (el) {
                  el.getText().then(function (txt) {
                    expect(txt).not.toContain('edit');
                    console.log("Item name  " + txt);
                  });
              });
              // then apply the promise to assert the text in description Input
              firstRowColDescription.then(function (el) {
                  el.getText().then(function (txt) {
                    expect(txt).not.toContain('edit');
                    console.log("Item name  " + txt);
                  });
              });
              // then apply the promise to assert the text in status Input
              firstRowColStatus.then(function (el) {
                  el.getText().then(function (txt) {
                    expect(txt).not.toContain('edit');
                    console.log("Item name  " + txt);
                  });
              });
            }
          });
      });
    });

    //performing the assertations to what will happen over click of cancel
    it('should check that the address remains same after cancel button is clicked', function() {
      expect(browser.getLocationAbsUrl()).toMatch("#/modify");
    });

    // counting the features after cancelling a feature
    it('should count the features in the list menu after cancelling a feature', function(){
      page.clickList();;
      //getting the features count in the list menu
      var cancelfeatureCount = element.all(by.repeater('feature in features')).count();
      expect(cancelfeatureCount).toBeGreaterThan(featureCount);
      // displaying the count of features
      cancelfeatureCount.then(function (txt){
            console.log('cancelfeatureCount = ' + txt);
      });
    });
  });

  //functionality for deleting the features
  describe('Remove', function() {

    // should click on the remove Reference tab
    it('should click on the remove Reference tab and the address changes to #/Remove', function(){
      page.clickRemove();
      expect(browser.getLocationAbsUrl()).toMatch("#/remove");
    });

    //performing the assertations to what will happen over click of delete
    it('should delete the feature created', function() {
      page.clickRemoveButton();
    });

    // counting the features after deleting a feature
    it('should count the features in the list menu after deleting a feature', function(){
      page.clickList();;
      //getting the features count in the list menu
      var deletefeatureCount = element.all(by.repeater('feature in features')).count();
      expect(deletefeatureCount).toBe(featureCount);
      // displaying the count of features
      deletefeatureCount.then(function (txt){
            console.log('deletefeatureCount = ' + txt);
      });
    });
  });
});