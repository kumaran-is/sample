/**
* @fileoverview
* <P>
* 
* </p> 
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
'use strict';

var modifyPage = require("./pageObjects/modifyPage");
var commonPage = require("../pageObjects/commonPage");

describe('Positive Modify Capabilities AppTest', function() {
  var mpage = new modifyPage();
  var cpage = new commonPage();
  var featureCount = cpage.getFirstFeatureCount();

  //functionality for modify feature
  describe('modify', function() {
    // should click on the modify Reference tab
    it('should click on the modify Reference tab and the address changes to #/Modify', function(){
      mpage.clickModify();
      expect(browser.getLocationAbsUrl()).toMatch("#/modify");
    });

    //testing if the modify page has a input field of name after the click of edit button
    it('should click the edit button and should have a edit name text box', function() {
      mpage.clickEditButton();
      expect(element(by.model('feature.name')).isPresent()).toBe(true);
    });

    //testing if the edit form has a input field of description 
    it('should have a edit description text box', function() {
      expect(element(by.model('feature.Description')).isPresent()).toBe(true);
    });

    //testing if the edit form has a input field of status 
    it('should have a edit status text box', function() {
      expect(element(by.model('feature.Status')).isPresent()).toBe(true);
    });

    // the element in the edit form are being updated
    it('should update the values in the edit form',function() {
      var firstRow = element(by.repeater('feature in features').row(0));
      firstRow.element(by.model('feature.name')).clear().sendKeys('updatedName');
      firstRow.element(by.model('feature.Description')).clear().sendKeys('updatedDescription');
    });

    //performing the assertations to what will happen over click of update
    it('should update the edit form and checking the values in the row after updating', function() {
      mpage.clickModifyButton();
      //getting all the features by the help of repeater
      var featureRows = element.all(by.repeater('feature in features'));
      //promise function and inside promise getting the first row
      featureRows.then(function (rows) {
          var featureFirstRow = featureRows.get(0);
          // checking whether the element is present or not by tagName and then again promise as it is very helpful and easy
          featureFirstRow.isElementPresent(by.tagName('td')).then(function (isTdPresent){
            // logical condition if TRUE
            if (isTdPresent) {
              // getting the first row details
              var firstRowColName = featureFirstRow.element(by.binding('feature.name'));
              var firstRowColDescription = featureFirstRow.element(by.binding('feature.Description'));
              var firstRowColStatus = featureFirstRow.element(by.binding('feature.Status'));
              // then apply the promise to assert the text in Name Input
              firstRowColName.then(function (el) {
                  el.getText().then(function (txt) {
                    expect(txt).toContain('updatedName');
                    console.log("Item name  " + txt);
                  });
              });
              // then apply the promise to assert the text in description Input
              firstRowColDescription.then(function (el) {
                  el.getText().then(function (txt) {
                    expect(txt).toContain('updatedDescription');
                    console.log("Item name  " + txt);
                  });
              });
              // then apply the promise to assert the text in status Input
              // firstRowColStatus.then(function (el) {
              //     el.getText().then(function (txt) {
              //       expect(txt).toContain('updatedStatus');
              //       console.log("Item name  " + txt);
              //     });
              // });
            }
          });
      });
     /* var newUpdateFeatureCount = element.all(by.css('[ng-click="editFeature(feature)"]')).count();
      // expect(newUpdateFeatureCount).toBeGreaterThan(featureCount);
      // displaying the count of features after updating
      newUpdateFeatureCount.then(function (txt){
        console.log('newUpdateFeatureCount = ' + txt);
      });*/
    });
    
    //performing the assertations to what will happen over click of submit
    it('should check that the address remains same after Modify is clicked', function() {
      expect(browser.getLocationAbsUrl()).toMatch("#/modify");
    });

    // counting the features after modifying a feature
    it('should count the features in the list menu after modifying a feature', function(){
      cpage.clickList();;
      //getting the features count in the list menu
      var modifyfeatureCount = cpage.getFeatureCount();
      expect(modifyfeatureCount).toBeGreaterThan(featureCount);
      // displaying the count of features 
      modifyfeatureCount.then(function (txt){
            console.log('modifyfeatureCount = ' + txt);
      });
    });
  });
});