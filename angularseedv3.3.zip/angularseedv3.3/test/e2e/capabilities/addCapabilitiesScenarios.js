/**
* @fileoverview
* <P>
* 
* </p> 
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
'use strict';

var addPage = require("./pageObjects/addPage");
var commonPage = require("../pageObjects/commonPage");

describe('Positive Add Capabilities AppTest', function() {
  var apage = new addPage();
  var cpage = new commonPage();
  var intialFeatureCount = cpage.getFirstFeatureCount();

  //this will fetch the browser home page
  browser.get('index.html');

  //functionality for adding feature
  describe('Add', function() {
    // should click on the Add Reference tab
    it('should click on the add Reference tab and the address changes to #/Add', function(){
      apage.clickAdd();
      expect(browser.getLocationAbsUrl()).toMatch("#/add");
    });

    //testing if the form has a input field of name 
    it('should have a name text box', function() {
      expect(element(by.model('newfeatures.name')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of description 
    it('should have a description text box', function() {
      expect(element(by.model('newfeatures.Description')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of status 
    it('should have a status text box', function() {
      expect(element(by.model('newfeatures.Status')).isPresent()).toBe(true);
    });

    //inserting data into the fields 
    it('should fill the Add newfeatures', function() {
      element(by.model('newfeatures.name')).sendKeys('admin');
      element(by.model('newfeatures.Description')).sendKeys('User');
      element(by.model('newfeatures.Status')).sendKeys('In-Progress');
    });

    //performing the assertations to what will happen over click of submit
    it('should submit the login form and the address remains same', function() {
      apage.clickAddSubmitButton();
      expect(browser.getLocationAbsUrl()).toMatch("#/add");
    });

    // counting the features after adding a feature
    it('should count the features in the list menu after adding a feature', function(){
      cpage.clickList();;
      //getting the features count in the list menu
      var addfeatureCount = cpage.getFeatureCount();
      expect(addfeatureCount).toBeGreaterThan(intialFeatureCount);
      // displaying the count of features at first
      addfeatureCount.then(function (txt){
            console.log('addfeatureCount = ' + txt);
      });
    });
  });
});