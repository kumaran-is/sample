/**
* @fileoverview
* <P>
* 
* </p> 
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
'use strict';

var modifyPage = require("./pageObjects/modifyPage");
var commonPage = require("../pageObjects/commonPage");

describe('Positive Cancel Capabilities AppTest', function() {
  var featureCount;
  var mpage = new modifyPage();
  var cpage = new commonPage();
  var featureCount = cpage.getFirstFeatureCount();

  describe('cancel', function(){
    //performing the assertations to what will happen over click of cancel
    it('should cancel in the edit form after updating', function() {
      mpage.clickModify();
      // clickin the edit button
      mpage.clickEditButton();

      //fetching the row in which the changes are to be done
      var firstRow = element(by.repeater('feature in features').row(0));

      // making changes in the fields
      firstRow.element(by.model('feature.name')).clear().sendKeys('updatednameedit');
      firstRow.element(by.model('feature.Description')).clear().sendKeys('updateddescriptionedit');

      // clickin the cancel button
      mpage.clickCancelButton();
    });

    //performing the assertations to what will happen over click of cancel
    it('should go to the list tab for refreshing and verify the changes', function() {
      cpage.clickList();;
      mpage.clickModify();

      //getting all the features by the help of repeater
      var featureRows = element.all(by.repeater('feature in features'));
      //promise function and inside promise getting the first row
      featureRows.then(function (rows) {
          var featureFirstRow = featureRows.get(0);
          // checking whether the element is present or not by tagName and then again promise as it is very helpful and easy
          featureFirstRow.isElementPresent(by.tagName('td')).then(function (isTdPresent){
            // logical condition if TRUE
            if (isTdPresent) {
              // getting the first row details
              var firstRowColName = featureFirstRow.element(by.binding('feature.name'));
              var firstRowColDescription = featureFirstRow.element(by.binding('feature.Description'));
              var firstRowColStatus = featureFirstRow.element(by.binding('feature.Status'));
              // then apply the promise to assert the text in Name Input
              firstRowColName.then(function (el) {
                  el.getText().then(function (txt) {
                    expect(txt).not.toContain('edit');
                    console.log("Item name  " + txt);
                  });
              });
              // then apply the promise to assert the text in description Input
              firstRowColDescription.then(function (el) {
                  el.getText().then(function (txt) {
                    expect(txt).not.toContain('edit');
                    console.log("Item name  " + txt);
                  });
              });
              // then apply the promise to assert the text in status Input
              firstRowColStatus.then(function (el) {
                  el.getText().then(function (txt) {
                    expect(txt).not.toContain('edit');
                    console.log("Item name  " + txt);
                  });
              });
            }
          });
      });
    });

    //performing the assertations to what will happen over click of cancel
    it('should check that the address remains same after cancel button is clicked', function() {
      expect(browser.getLocationAbsUrl()).toMatch("#/modify");
    });

    // counting the features after cancelling a feature
    it('should count the features in the list menu after cancelling a feature', function(){
      cpage.clickList();;
      //getting the features count in the list menu
      var cancelfeatureCount = cpage.getFeatureCount();
      expect(cancelfeatureCount).toBeGreaterThan(featureCount);
      // displaying the count of features
      cancelfeatureCount.then(function (txt){
            console.log('cancelfeatureCount = ' + txt);
      });
    });
  });
});