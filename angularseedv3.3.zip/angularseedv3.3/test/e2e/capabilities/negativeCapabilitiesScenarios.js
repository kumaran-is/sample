/**
* @fileoverview
* <P>
* 
* </p> 
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
'use strict';

var addPage = require("./pageObjects/addPage");
var listPage = require("./pageObjects/listPage");
var modifyPage = require("./pageObjects/modifyPage");
var removePage = require("./pageObjects/removePage");
var commonPage = require("../pageObjects/commonPage");

describe('Negative Capabilities AppTest', function() {
  var apage = new addPage();
  var lpage = new listPage();
  var mpage = new modifyPage();
  var rpage = new removePage();
  var cpage = new commonPage();

  var testname = "1 Dan Brown";
  var testname1 = "Dan Brown the author of the Book Inferno his fourth book in Robert Langdon series";
  var testname2 = "Dan Brown";
  var testdescription = "Inferno is a 2013 mystery thriller";
  var testdescription1 = "Inferno is a 2013 mystery thriller novel by American author Dan Brown and the fourth book in his Robert Langdon series, following Angels & Demons, The Da Vinci Code and The Lost Symbol.[1] The book was released on May 14, 2013 by Doubleday.[2] It was number one on the New York Times Best Seller list for hardcover fiction and Combined Print & E-book fiction for the first eleven weeks of its release, and also remained on the list of E-book fiction for the first seventeen weeks of its release.";

  //checking if the page is redirected to /home
  it('should go to the list page ', function() {
    lpage.clickList();
    expect(browser.getLocationAbsUrl()).toMatch("#/list");
  });

/*  var testLang = element(by.binding('displayHeaderMessage')).getText();
  var lang = 'en';
  testLang.then(function (txt){
    if(txt=='Projet de semences'){
      lang='fr';
    }
    console.log('testLang = '+ txt);
    console.log('lang first = '+lang);
  });*/

  //negative functionality for adding feature
  describe('Add', function() {
    // should click on the Add Reference tab
    it('should click on the add Reference tab and the address changes to #/Add', function(){
      apage.clickAdd();
      expect(browser.getLocationAbsUrl()).toMatch("#/add");
    });

    //testing if the form has a input field of name 
    it('should have a name text box', function() {
      expect(element(by.model('newfeatures.name')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of description 
    it('should have a description text box', function() {
      expect(element(by.model('newfeatures.Description')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of status 
    it('should have a status text box', function() {
      expect(element(by.model('newfeatures.Status')).isPresent()).toBe(true);
    });

    //inserting data into the fields 
    it('should fill the Add newfeatures with data which disagree the pattern', function() {
      element(by.model('newfeatures.name')).sendKeys(testname);
      element(by.model('newfeatures.Description')).sendKeys(testdescription);
    });

    // counting the features after adding a feature
    it('should verify the errors provided', function(){
      expect(element(by.css('[ng-show="create.name.$dirty && create.name.$error.pattern"]')).getText()).toBe('Textual characters only');
    });

    //clearing data from the fields 
    it('should clear the data', function() {
      element(by.model('newfeatures.name')).clear();
      element(by.model('newfeatures.Description')).clear();
    });

    //inserting data into the fields 
    it('should fill the Add newfeatures with data which disagree the maxlength', function() {
      element(by.model('newfeatures.name')).sendKeys(testname1);
      element(by.model('newfeatures.Description')).sendKeys(testdescription1);
    });

    // counting the features after adding a feature
    it('should verify the errors provided', function(){
      expect(element(by.css('[ng-show="create.name.$dirty && create.name.$error.maxlength"]')).getText()).toBe('Name cannot be longer than 30 characters');
      expect(element(by.css('[ng-show="create.description.$dirty && create.description.$error.maxlength"]')).getText()).toBe('Description cannot be longer than 100 characters');
    });

    //inserting data into the fields 
    it('should fill the Add newfeatures with data which disagree the required', function() {
      element(by.model('newfeatures.name')).clear();
      element(by.model('newfeatures.Description')).clear();
    });

    // counting the features after adding a feature
    it('should verify the errors provided', function(){
      expect(element(by.css('[ng-show="create.name.$dirty && create.name.$error.required"]')).getText()).toBe('Enter name');
      expect(element(by.css('[ng-show="create.description.$dirty && create.description.$error.required"]')).getText()).toBe('Enter description');
    });

    //clearing data from the fields 
    it('should clear the data', function() {
      element(by.model('newfeatures.name')).clear();
      element(by.model('newfeatures.Description')).clear();
    });

    //inserting data into the fields for the modify
    it('should fill the Add newfeatures with data which agrees all the validation and add the features', function() {
      element(by.model('newfeatures.name')).sendKeys(testname2);
      element(by.model('newfeatures.Description')).sendKeys(testdescription);
      apage.clickAddSubmitButton();
    });
  });

  //negative functionality for adding feature
  describe('Modify', function() {
    // should click on the Add Reference tab
    it('should click on the add Reference tab and the address changes to #/modify', function(){
      mpage.clickModify();
      expect(browser.getLocationAbsUrl()).toMatch("#/modify");
      mpage.clickEditButton();
    });

    //testing if the form has a input field of name 
    it('should have a name text box', function() {
      expect(element(by.model('feature.name')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of description 
    it('should have a description text box', function() {
      expect(element(by.model('feature.Description')).isPresent()).toBe(true);
    });

    //testing if the form has a input field of status 
    it('should have a status text box', function() {
      expect(element(by.model('feature.Status')).isPresent()).toBe(true);
    });

    //inserting data into the fields 
    it('should fill the Add feature with data which disagree the required', function() {
      element(by.model('feature.name')).clear();
      element(by.model('feature.Description')).clear();
    });

    // counting the features after adding a feature
    it('should verify the errors provided', function(){
      expect(element(by.css('[ng-show="updatefeature.name.$dirty && updatefeature.name.$error.required"]')).getText()).toBe('Enter name');
      expect(element(by.css('[ng-show="updatefeature.description.$dirty && updatefeature.description.$error.required"]')).getText()).toBe('Enter description');
    });

    //inserting data into the fields 
    it('should fill the Modify feature with data which disagree the pattern', function() {
      element(by.model('feature.name')).sendKeys(testname);
      element(by.model('feature.Description')).sendKeys(testdescription);
    });

    // counting the features after adding a feature
    it('should verify the errors provided', function(){
      expect(element(by.css('[ng-show="updatefeature.name.$dirty && updatefeature.name.$error.pattern"]')).getText()).toBe('Textual characters only');
    });

    //clearing data from the fields 
    it('should clear the data', function() {
      element(by.model('feature.name')).clear();
      element(by.model('feature.Description')).clear();
    });

    //inserting data into the fields 
    it('should fill the Add feature with data which disagree the maxlength', function() {
      element(by.model('feature.name')).sendKeys(testname1);
      element(by.model('feature.Description')).sendKeys(testdescription1);
    });

    // counting the features after adding a feature
    it('should verify the errors provided', function(){
      expect(element(by.css('[ng-show="updatefeature.name.$dirty && updatefeature.name.$error.maxlength"]')).getText()).toBe('Name cannot be longer than 30 characters');
      expect(element(by.css('[ng-show="updatefeature.description.$dirty && updatefeature.description.$error.maxlength"]')).getText()).toBe('Description cannot be longer than 100 characters');
    });
  });

  //functionality for deleting the features
  describe('Remove', function() {

    // should click on the remove Reference tab
    it('should click on the remove Reference tab and the address changes to #/Remove', function(){
      rpage.clickRemove();
      expect(browser.getLocationAbsUrl()).toMatch("#/remove");
    });

    //performing the assertations to what will happen over click of delete
    it('should delete the feature created for the validations', function() {
      rpage.clickRemoveButton();
      lpage.clickList();
    });
  });
});