/**
 * Created by 110159 on 7/28/2014.
 */

var removePage = (function () {
    function removePage() {
        // getting the delete button element
        this.deleteButton = element(by.css('[ng-click="delete(feature)"]'));

        //getting the remove reference element
        this.removeReferenceTab = element(by.css('[href="#/remove"]'));
    }

    removePage.prototype.clickRemoveButton = function () {
        this.deleteButton.click();
    };

    removePage.prototype.clickRemove = function () {
        this.removeReferenceTab.click();
    };

    return removePage;
})();

module.exports = removePage;
