/**
 * Created by 110159 on 7/28/2014.
 */

var addPage = (function () {
    function addPage() {
        //getting the login button element
        this.addSubmitButton = element(by.css('[ng-click="createFeature()"]'));

        //getting the add reference element
        this.addReferenceTab = element(by.css('[href="#/add"]'));
    }

    addPage.prototype.clickAddSubmitButton = function () {
        this.addSubmitButton.click();
    };
    addPage.prototype.clickAdd = function () {
        this.addReferenceTab.click();
    };

    return addPage;
})();

module.exports = addPage;
