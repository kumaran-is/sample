/**
 * Created by 110159 on 7/28/2014.
 */

var modifyPage = (function () {
    function modifyPage() {
        // getting the edit button element
        this.editButton = element(by.css('[ng-click="editFeature(feature)"]'));

        //getting the update button element
        this.modifyButton = element(by.css('[ng-click="update(feature)"]'));

        //getting the cancel button element
        this.cancelButton = element(by.css('[ng-click="cancel(feature)"]'));

        //getting the modify reference element
        this.modifyReferenceTab = element(by.css('[href="#/modify"]'));
    }

    modifyPage.prototype.clickEditButton = function () {
        this.editButton.click();
    };

    modifyPage.prototype.clickModifyButton = function () {
        this.modifyButton.click();
    };

    modifyPage.prototype.clickCancelButton = function () {
        this.cancelButton.click();
    };

    modifyPage.prototype.clickModify = function () {
        this.modifyReferenceTab.click();
    };

    return modifyPage;
})();

module.exports = modifyPage;
