/**
 * Created by 110159 on 7/28/2014.
 */

var listPage = (function () {
    function listPage() {
        //the list reference element
        this.listReferenceTab = element(by.css('[href="#/list"]'));

        // getting the delete button element
        this.deleteButton = element(by.css('[ng-click="delete(feature)"]'));

        //getting the remove reference element
        this.removeReferenceTab = element(by.css('[href="#/remove"]'));
    }

    listPage.prototype.clickList = function () {
        this.listReferenceTab.click();
    };
    
    listPage.prototype.clickRemoveButton = function () {
        this.deleteButton.click();
    };

    listPage.prototype.clickRemove = function () {
        this.removeReferenceTab.click();
    };

    listPage.prototype.getFeatureCount = function () {
        //getting the features count in the list menu
        var featureCount = element.all(by.css('[ng-click="editFeature(feature)"]')).count();
        return featureCount;
    };

    return listPage;
})();

module.exports = listPage;
