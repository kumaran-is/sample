/**
* @fileoverview
* <P>
* 
* </p> 
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
'use strict';

var removePage = require("./pageObjects/removePage");
var commonPage = require("../pageObjects/commonPage");

describe('Positive Remove Capabilities AppTest', function() {
  var rpage = new removePage();
  var cpage = new commonPage();
  var featureCount = cpage.getFirstFeatureCount();

  //functionality for deleting the features
  describe('Remove', function() {

    // should click on the remove Reference tab
    it('should click on the remove Reference tab and the address changes to #/Remove', function(){
      rpage.clickRemove();
      expect(browser.getLocationAbsUrl()).toMatch("#/remove");
    });

    //performing the assertations to what will happen over click of delete
    it('should delete the feature created', function() {
      rpage.clickRemoveButton();
    });

    // counting the features after deleting a feature
    it('should count the features in the list menu after deleting a feature', function(){
      cpage.clickList();;
      //getting the features count in the list menu
      var deletefeatureCount = cpage.getFeatureCount();
      expect(deletefeatureCount).toBe(featureCount);
      // displaying the count of features
      deletefeatureCount.then(function (txt){
            console.log('deletefeatureCount = ' + txt);
      });
    });
  });
});