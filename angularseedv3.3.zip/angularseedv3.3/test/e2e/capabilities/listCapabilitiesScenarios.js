/**
* @fileoverview
* <P>
* 
* </p> 
* @project AngularJS Seed 
* @Date
* @version 1.0
* @author Advanced Javascript Solutions COE
*/
'use strict';

var listPage = require("./pageObjects/listPage");
var commonPage = require("../pageObjects/commonPage");

describe('Positive list Capabilities AppTest', function() {
  var lpage = new listPage();
  var cpage = new commonPage();
  var featureCount = cpage.getFirstFeatureCount();
  var ptor;

  describe('List', function(){
    // should click on the List Reference tab
    it('should click on the List Reference tab and the address changes to #/List', function(){
      lpage.clickList();;
      expect(browser.getLocationAbsUrl()).toMatch("#/list");
    });

    it('should count the features in the list menu', function(){
      lpage.clickList();;
      
      //getting the features count in the list menu
      featureCount = cpage.getFeatureCount();
      expect(featureCount).toBe(0);
      
      // displaying the count of features at first
      featureCount.then(function (txt){
        console.log('featureCount = ' + txt);
      });
    });

    xit('should delete all the features at the start of e2e test cases', function(){
      //getting the features count in the list menu
      featureCount = cpage.getFeatureCount();
      expect(featureCount).toBeGreaterThan(0);

      //should go to remove page to remove all the features as there should be zero features at the start of e2e test cases
      lpage.clickRemove();

      // displaying the count of features at first
      featureCount.then(function (txt){
        console.log('for loop featureCount = ' + txt);
        for (var i = 0; i < txt; i++) {
          console.log(i);
          lpage.clickRemoveButton();
        };
      });
    });
  });
});