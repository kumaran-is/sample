/**
 * Created by 110159 on 7/28/2014.
 */

var commonPage = (function () {
    function commonPage() {
        //the home reference element
        this.homeReference = element(by.binding("'HEADER_TITLE' | translate"));

        //the list reference element
        this.listReferenceTab = element(by.css('[href="#/list"]'));

        //the first feature count 
        // this.firstFeatureCount = element.all(by.repeater('feature in features')).count();
    }
    commonPage.prototype.visitPage = function () {
        browser.get("index.html");
    };

    commonPage.prototype.clickHome = function () {
        this.homeReference.click();
    };

    commonPage.prototype.clickList = function () {
        this.listReferenceTab.click();
    };

    var intialFeatureCount = element.all(by.repeater('feature in features')).count();
    commonPage.prototype.getFirstFeatureCount = function () {
        //getting the features count in the list menu
        //var firstFeatureCount = FeatureCount;
        return intialFeatureCount;
    };

    commonPage.prototype.getFeatureCount = function () {
        //getting the features count in the list menu
        var featureCount = element.all(by.repeater('feature in features')).count();
        return featureCount;
    };

    return commonPage;
})();

module.exports = commonPage;
