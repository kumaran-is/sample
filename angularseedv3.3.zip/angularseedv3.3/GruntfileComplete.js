 "use strict";

module.exports = function(grunt) {



    // load all grunt tasks matching the `grunt-*` pattern
    require('load-grunt-tasks')(grunt);




  //Displays the elapsed execution time of grunt tasks when done
  // Time how long each tasks take. Can help when optimizing build times
  require('time-grunt')(grunt);

  // Reference to properties of gruntConfig
  var gruntConfig = grunt.file.readJSON('build/gruntConfig.json');

  // Configuration of grunt tasks goes here
  grunt.initConfig({

    cfg:gruntConfig,

    // You can also set the value of a key as parsed JSON.
    // Allows us to reference properties we declared in package.json.
    pkg: grunt.file.readJSON('package.json'),


    // clean task to delete files from dist folder
    clean: {      // Task
      build :{     // Target
        src: ['<%= cfg.path.dist %>']   // Target options
      },
      stylesheets: {
        src: [ '<%= cfg.path.distStyles %>/**/*', '!<%= cfg.path.distStyles %>/**/*.min.css' ]
      },
      scripts: {
        src: [ '<%= cfg.path.distJS %>/**/*', '!<%= cfg.path.distJS %>/**/*.min.js' ]
      },
      gzstylesheets: {
        src: [ '<%= cfg.path.distStyles %>/**/*.min.css', '!<%= cfg.path.distStyles %>/**/*.gz.css' ]
      },
      gzscripts: {
        src: [ '<%= cfg.path.distJS %>/**/*.min.js', '!<%= cfg.path.distJS %>/**/*.gz.js' ]
      },
      gzhtml: {
        src: [ '<%= cfg.path.distSrc %>/**/*.html', '!<%= cfg.path.distSrc %>/**/*.gz.html' ]
      },
      gzvendor: {
        src: [ '<%= cfg.path.distVendor %>/**/*.js','<%= cfg.path.distVendor %>/**/*.css','<%= cfg.path.distVendor %>/**/*.js.map',
               '<%= cfg.path.distVendor %>/**/*.eot','<%= cfg.path.distVendor %>/**/*.svg','<%= cfg.path.distVendor %>/**/*.ttf',
               '<%= cfg.path.distVendor %>/**/*.woff','!<%= cfg.path.distVendor %>/**/*.gz' ]
      },
      reports: {
        src: [ '<%= cfg.path.distReports %>/**/*']
      },
      e2etestreports: {
        src: [ '<%= cfg.path.distE2EReports %>']
      },
      e2ecoveragereports: {
        src: [ '<%= cfg.path.distE2ECoverageReports %>']
      },
      unittestreports: {
        src: [ '<%= cfg.path.distUnitReports %>']
      },
      partials: {
        src: ['<%= cfg.path.distPartial %>']
      },
      instrumented: {
        src: [ '<%= cfg.path.distInstrumented %>']
      }

    },

    // create directorirs for e2e test xml reports
    mkdir: {
      e2etestxmlreports: {
        options: {
          create: ['<%= cfg.path.distE2EReports %>/xml/chrome',
                   '<%= cfg.path.distE2EReports %>/xml/safari',
                   '<%= cfg.path.distE2EReports %>/xml/firefox']
          }
      },
      e2ecoveragexmlreports: {
        options: {
          create: ['<%= cfg.path.distE2ECoverageReports %>/xml/chrome']
          }
      }
    },

    //copy task to copy files to dist from src
    copy :{
      vendor:{
        files: [{
          expand: true,
          src: ['<%= cfg.path.vendor %>/**/*'],
          dest: '<%= cfg.path.dist %>'
        }]
      },
      scripts:{
        files: [{
          expand: true,
          src: ['<%= cfg.path.srcJS %>/**/*.js'],
          dest: '<%= cfg.path.dist %>'
        }]
      },
      stylesheets:{
        files: [{
          expand: true,
          src: ['<%= cfg.path.srcStyles %>/**/*.css'],
          dest: '<%= cfg.path.dist %>'
        }]
      },
       images:{
	     files: [{
	       expand: true,
	       src: ['<%= cfg.path.srcImages %>/**/*'],
	       dest: '<%= cfg.path.dist %>'
	     }]
      },
      html:{
        files: [{
          expand: true,
          src: ['<%= cfg.path.src %>/index.html'],
          dest: '<%= cfg.path.dist %>'
        }]
      },
      partials:{
        files: [{
          expand: true,
          src: ['<%= cfg.path.srcPartial %>/**/*.html'],
          dest: '<%= cfg.path.dist %>'
        }]
      },
       coverageE2E: {
        files: [{
          expand: true,
          dot: true,
          cwd: '<%= cfg.path.dist %>',
          dest: '<%= cfg.path.distInstrumented %>/dist',
          src: [
            '<%= cfg.path.srcPartial %>/**/*',
            '<%= cfg.path.srcStyles %>/**/*',
            '<%= cfg.path.srcImages %>/**/*',
            '<%= cfg.path.src %>/index.html',
            '<%= cfg.path.vendor %>/**/*'
          ]
        }]
      }
    },

    // Concatenate all the CSS files into a single file.
    concat: {
      css: {
        src: ['<%= cfg.path.srcStyles %>/**/*.css'],
        // angle-bracket allows to reference other properties.
        dest: '<%= cfg.path.distStyles %>/<%= pkg.name %>.css'
      }
    },

    //Remove unused styles from CSS and concatenate all the CSS files into a single file.
    uncss: {
      dist: {
        options: {
          stylesheets  : ['../<%= cfg.path.vendorStyles%>/Bootstrap.min.css',
                           'styles/responsive.css',
                           'styles/style.css'],
          ignoreSheets : ['../<%= cfg.path.vendorStyles%>/toastr.css'],
          // report minification and gzip result
          report:'gzip'
        },  
        files: {
          '<%= cfg.path.distStyles %>/<%= pkg.name %>.css': ['<%= cfg.path.src %>/index.html','<%= cfg.path.srcPartial %>/**/*.html']
        }
      }
    },


    //Apply vendor prefixes to CSS to ensure the best browser support
    autoprefixer: {
      options: {
         browsers: ['> 1%', 'last 4 versions', 'Firefox ESR', 'Opera 12.1']
      },
      files: {
        src: '<%= cfg.path.distStyles %>/<%= pkg.name %>.css'
      }
    },

    // CSS minification
    cssmin: {
      options:{
      //remove all the comments by setting zero
        keepSpecialComments:0,
        //Prefix the compressed source with the given banner
        banner: '/*! <%= pkg.name %>_v<%= pkg.version %> - <%= grunt.template.today("mm-dd-yyyy") %> */\n' ,
        // report minification and gzip result
        report:'gzip'
      },
      files: {
        expand: true,
        cwd: '<%= cfg.path.distStyles %>',
        src: ['**/*.css', '!**/*.min.css'],
        dest: '<%= cfg.path.distStyles %>',
        ext: '.min.css'
      }
    },

   // concatenate/merge all the js files into a single file using requirejs/r.js.
    requirejs: {
      compile: {
        options: {
          baseUrl: "<%= cfg.path.distJS %>",
          mainConfigFile: "<%= cfg.path.distJS %>/<%= cfg.path.requireJSConfigfile %>.js",
          include: "<%= cfg.path.requireJSConfigfile %>",
          out: "<%= cfg.path.distJS %>/<%= pkg.name %>.js",
          findNestedDependencies: true,
          preserveLicenseComments: false,
          optimize: "none"
        }
      }
    },

    // JavaScript minification
    uglify: {
      options: {
        mangle: false,
        compress: {
          drop_console: true,
          global_defs: {
            "DEBUG": false
          },
          dead_code: true
        },

         // report minification and gzip result
       // report:'gzip',
        //Prefix the compressed source with the given banner
        banner: '/*! <%= pkg.name %>_v<%= pkg.version %> - <%= grunt.template.today("mm-dd-yyyy") %> */\n'

      },
      files: {
        expand: true,
        cwd: '<%= cfg.path.distJS %>',
        src: ['<%= pkg.name %>.js'],
        dest: '<%= cfg.path.distJS %>',
        ext: '.min.js'
      }
    },

    // HTML minification
    htmlmin: {
      options: {
        collapseBooleanAttributes:      true,
        collapseWhitespace:             true,
        removeAttributeQuotes:          true,
        removeComments:                 true, // Only if you don't use comment directives!
        removeEmptyAttributes:          true,
        removeRedundantAttributes:      true,
        removeScriptTypeAttributes:     true,
        removeStyleLinkTypeAttributes:  true
      },
      partials: {
        expand: true,
        cwd: '<%= cfg.path.src %>',
        src: ['partials/**/*.html'],
        dest: '<%= cfg.path.distSrc %>',
        ext: '.html'
      },
      index: {
        expand: true,
        cwd: '<%= cfg.path.distSrc %>',
        src: ['index.html'],
        dest: '<%= cfg.path.distSrc %>',
        ext: '.html'
      }
    },

  // Image optimization for GIF,JPEG,SVG,BMP and PNG type image files
    imagemin: {
      options: {
        optimizationLevel: 3,
        progressive:true,
        interlaced:true
      },
      files: {
        expand: true,
        cwd: '<%= cfg.path.srcImages %>',
        src: ['**/*.{png,jpg,gif,jpeg,svg,bmp}'],
        dest: '<%= cfg.path.distImages %>'
      }
    },

    //CSS image sprite generator - putting collection of images  into a single image.
    sprite:{
      all: {
        src: '<%= cfg.path.distImages %>/*.png',
        destImg: '<%= cfg.path.distImages %>/spritesheet.png',
        destCSS: '<%= cfg.path.distImages %>/sprites.css',
        engine:'phantomjs'
      }
    },

    /* Pre load most used html partials into angular $templateCache during application startup
       to reduce the number http   connections  and initial page load */
    ngtemplates:  {
      templates: {
        cwd:'<%= cfg.path.src %>',
        src: ['<%= cfg.path.partials %>/**/*.html'],
        dest:'<%= cfg.path.srcJS %>/templates.js',
        options:  {
          htmlmin :{
            collapseBooleanAttributes:      true,
            collapseWhitespace:             true,
            removeAttributeQuotes:          true,
            removeComments:                 true, // Only if you don't use comment directives!
            removeEmptyAttributes:          true,
            removeRedundantAttributes:      true,
            removeScriptTypeAttributes:     true,
            removeStyleLinkTypeAttributes:  true
          },
          module:'templates',
          bootstrap:  function(module, script) {
            return "define('"+module+"', ['./app'], function(app) { return app.run(['$templateCache',function ($templateCache) { " + script + " }]) });"
          }
        }
      }
    },

    // Convert minified JS,CSS and HTML files to compressed gz file type
    compress: {
      options: {
        mode: 'gzip',
        pretty:true
      },
      scripts: {
        expand: true,
        cwd: '<%= cfg.path.distJS %>',
        src: ['**/*.min.js'],
        dest: '<%= cfg.path.distJS %>'
      },
      stylesheets: {
        expand: true,
        cwd: '<%= cfg.path.distStyles %>',
        src: ['**/*.min.css'],
        dest: '<%= cfg.path.distStyles %>'
      },
      html: {
        expand: true,
        cwd: '<%= cfg.path.distSrc %>/',
        src: ['index.html','partials/**/*.html'],
        dest: '<%= cfg.path.distSrc %>/'
      },
      vendor: {
        expand: true,
        cwd: '<%= cfg.path.distVendor %>',
        src: ['**/*'],
        dest: '<%= cfg.path.distVendor %>'
      },
    },

    //Task that replaces references to non-optimized scripts or stylesheets with optimized one
    // into a set of HTML files
    useminPrepare: {
      html: '<%= cfg.path.src %>/index.html',
      options: {
          dest: '<%= cfg.path.distSrc %>'
      }
    },
    usemin: {
      html: ['<%= cfg.path.distSrc %>/index.html']
    },

   //enable cache buster to force browser to get latest files from server.
    replace: {
      defaultCacheBustVer: {
        options: {
          patterns: [{
            match: 'revision',
            replacement: '<%= grunt.template.today() %>'
          }]
        },
        files: [{
          expand: true,
          cwd: '<%= cfg.path.distSrc %>',
          src: ['index.html','js/<%= cfg.path.requireJSConfigfile %>.js'],
          dest: '<%= cfg.path.distSrc %>'
        }]
      },
      devCacheBustVer: {
        options: {
          patterns: [{
            match: 'revision',
            replacement: '<%= grunt.template.today() %>'
          }]
        },
        files: [{
          expand: true,
          cwd: '<%= cfg.path.distSrc %>',
          src: ['index.html','js/<%= pkg.name %>.min.js'],
          dest: '<%= cfg.path.distSrc %>'
        }]
      },
      releaseCacheBustVer: {
        options: {
          patterns: [{
            match: 'revision',
            replacement: '<%= pkg.version %>'
          }]
        },
        files: [{
          expand: true,
          cwd: '<%= cfg.path.distSrc %>',
          src: ['index.html','js/<%= pkg.name %>.min.js'],
          dest: '<%= cfg.path.distSrc %>'
        }]
      }
    },

    //Read and manipulate HTML documents using CSS selectors.
    dom_munger: {
      release: {
        options: {
          //Updates the value of 'data-min' attribute in <script> to concat/minified JS name .
          update: {selector:'script[data-main]',attribute:'data-main', value:'js/<%= pkg.name %>.min'}
        },
        src: '<%= cfg.path.distSrc %>/index.html'
      },
    },

    // This task will watch your source code for changes and live reload the changes to browser
    watch: {
      options: {
      // Start a live reload server on the default port 35729
          livereload: true,
          livereloadOnError:false
      },
      src: {
        files: ['<%= cfg.path.src %>/**/*','test/**/*'],
        tasks: ['unit-test'],
      }
    },

   // start a static web server to host the dist directory on port 4001
    connect: {
      server: {
        options: {
          port: '<%= cfg.server.connectPort %>',
          base: '<%= cfg.path.dist %>',
          hostname: '*',
          //set it to true to inject a live reload script tag into your page
          livereload: true,
          open:{
            target:'<%= cfg.server.connectHost %>' // target url to open
          }
        }
      }
    },

    // CSS static code analyzer and validator.
    csslint: {
      options: {
        absoluteFilePathsForFormatters: true,
        formatters: [{ id: 'checkstyle-xml', dest: '<%= cfg.path.distReports %>/csslint/csslint.xml'}
        ]
      },
      src: ['<%= cfg.path.srcStyles %>/**/*.css']
    },

   // JavaScript static code analyzer and validator.
    jshint: {
      options: {
        //configuration file to store rules for JSHint
        jshintrc: '<%= cfg.path.buildJshint %>/.jshintrc',
        reporter:'checkstyle',
       // reporter: require('jshint-jenkins-checkstyle-reporter'),
       // reporter: require('jshint-stylish'),
        reporterOutput:'<%= cfg.path.distReports %>/jshint/jshint.xml'
      },
      src: ['<%= cfg.path.srcJS %>/**/*.js']
    },

    // JavaScript Code Style Checker with jscs.
    jscs: {
      src: "<%= cfg.path.srcJS %>/**/*.js",
      options: {
        force:true,
        config: '<%= cfg.path.buildJscs %>/.jscsrc',
        reporter:'checkstyle',
        reporterOutput:'<%= cfg.path.distReports %>/jscs/jscs.xml'
      }
    },

   //Generate JavaScript document using YUIdoc
    yuidoc: {
      compile: {
        name: '<%= pkg.name %>',
        description: '<%= pkg.description %>',
        version: '<%= pkg.version %>',
        options: {
          paths: '<%= cfg.path.srcJS %>/',
          outdir: '<%= cfg.path.distReports %>/yuidocs/'
        }
      }
    },

   //Generate JavaScript document using angular doc
    ngdocs: {
      all: ['<%= cfg.path.src %>/**/*.js'],
      options: {
        dest: '<%= cfg.path.distReports %>/ngdocs/'
      },
      api: {
      src: ['<%= cfg.path.srcJS %>/**/*.js'],
      title: 'API Documentation'
      }
    },

    //Generate Javascript complexity analysis reports
    plato: {
      options : {
        complexity : {
          logicalor : true,
          switchcase : true,
          forin : true,
          trycatch : true
        },
        jshintrc : '.jshintrc'
      },
      main: {
        files: {
         '<%= cfg.path.distReports %>/complexity': ['<%= cfg.path.srcJS %>/**/*.js']
        }
      },
    },
    // HTML validator for angular templates
    htmlangular: {
      options: {
        angular:true,
        //List all the custom tags(directives).The validator will ignore warnings about these tags.
        customtags: [],
        //List all the custom attributes(directives).The validator will ignore warnings about these attributes.
        customattrs:[],
        //List the error strings you want explicitly ignored by the validator.
        relaxerror: [
            'The document is not mappable to XML 1.0 due to two consecutive hyphens in a comment.'
        ],
        reportpath:'<%= cfg.path.distReports %>/htmlAngularValidator/html-angular-validate-report.json'
      },
      files: {
        src: ['<%= cfg.path.src %>/index.html','<%= cfg.path.srcPartial %>/**/*.html']
      }
    },

    // execute tasks in parallel
    concurrent: {
      staticCodeAnalyzer: ["csslint","jshint","jscs"],
      htmlStaticValidators: ["htmlangular","htmlhint"],
      qualityReports: ["plato"],
      jsdocs: ["ngdocs","yuidoc"],
      perfMetrics: ["yslow_test","wpt" ]
    },

    // execute unit test using Karma runner
    karma: {
      unit: {
        configFile: '<%= cfg.path.buildUnit %>/karmaMainConfig.js'
      }
    },

  
    // execute e2e using protractor runner
    protractor: {
      options: {
        keepAlive: true  // If false, the grunt process stops when the test fails.
      },  
      e2e: {
        configFile: '<%= cfg.path.buildE2E %>/protractor-conf.js'
      }
    },

   // instrument the sources for e2e code coverage
    instrument: {
      options: {
        basePath: '<%= cfg.path.distInstrumented %>',
      },
      files: ['<%= cfg.path.distJS %>/**/*.js']
    },

    // execute e2e testing against the instrumented code and capture the code coverage using protractor
    protractor_coverage: {
      options: {
        coverageDir: '<%= cfg.path.distReports %>/<%= cfg.path.testingE2ECoverage %>/coverage/json',
        keepAlive: true // If false, the grunt process stops when the test fails.
      },
      e2ecoverage: {
          configFile: '<%= cfg.path.buildE2E %>/protractor-withcodecoverage-conf.js'
      }
    },
    // generate codecoverage in lcov format
    makeReport: {
      src: '<%= cfg.path.distReports %>/<%= cfg.path.testingE2ECoverage %>/coverage/json/*.json',
      options: {
        type: 'lcov',
        dir: '<%= cfg.path.distReports %>/<%= cfg.path.testingE2ECoverage %>/coverage/lcov',
        print: 'detail'
      }
    },

    //One time configuration setup to configure Jenkins CI server
    jenkins: {
      serverAddress: '<%= cfg.server.jenkinsHost %>',
      // path to all the predefined configuration files for various jobs
      pipelineDirectory: '<%= cfg.path.buildJenkins %>'
    },
    
    // yslow analyzes web pages using PhatomJS headless browser and logs the performance metrics
    yslow: {
      options: {
        viewport:"1280x1024",
        thresholds: {
          weight: 180,
          speed: 1000,
          score: 80,
          requests: 15
        }
      },
      pages: {
        files: [{src: '<%= cfg.server.perfBenchMarkHost %>/index.html'}] //array of urls,which will be analyzed
      }
    },
    
    // yslow analyzes web pages using PhatomJS headless browser and logs the performance metrics
    yslow_test: {
      options: {
        info: "all",  //specify the information to display
        format: "junit",
        viewport:"1280x1024",
        urls: ['<%= cfg.server.perfBenchMarkHost %>/index.html#/home'], //url of urls, which will be analyzed
        reports: ['<%= cfg.path.distPerfBenchMarkReports %>/yslow/homePerf.xml']
      },
      your_target: {
        files: []
      }
    },
    
    //web performance metrics collector and monitoring tool based on phantomas 
    devperf: {
      options: {
        urls: [
          '<%= cfg.server.perfBenchMarkHost %>/index.html#/home'
        ],  //  list of URLs you want to test. 
        numberOfRuns: 5,
        openResults:false,
        resultsFolder:'<%= cfg.path.distPerfBenchMarkReports %>/webperf/',
        phantomasOptions: {
       //   'proxy': '<%= cfg.server.proxyServer %>',
        //  'proxy-auth'='<%= cfg.server.proxyServerAuth %>'
        },
        warnings: [
          {
              variable : "jsErrors",
              limit : 0,
          },
          {
              variable : "requests",
              limit :10,
          }
        ]   
      }
    },

   // execute website speed test from multiple locations around the globe using real browsers (IE and Chrome) 
    wpt: {
      options: {
        locations: ['Tokyo', 'SanJose_IE9'],
        key: process.env.WPT_API_KEY
      },
      dev: {
        options: {
          url: ['<%= cfg.server.perfBenchMarkHost %>/index.html#/home'
          ]
        },
        dest: '<%= cfg.path.distPerfBenchMarkReports %>/webpagetest/'
      }
    },

    // To generate HTML5 Cache Manifest files to enable offline capability web app.
    manifest: {
      generate: {
        options: {
          basePath: '<%= cfg.path.distSrc %>/',
          cache: ['js/<%= pkg.name %>.min.js', 'styles/<%= pkg.name %>.min.css'],
          network: ['http://*', 'https://*'],
          fallback: ['/ /offline.html'],
          preferOnline: true,
          verbose: true,
          timestamp: true,
          hash: true,
          master: ['index.html']
        },
         src: [],
        dest: '<%= cfg.path.distSrc %>/manifest.appcache'
      }
    }
     
 
}); //End of config


  // notification when files are edited
  grunt.event.on('watch', function(action, filepath, target) {
    grunt.log.writeln(target + ': ' + filepath + ' has ' + action);
  });

  //loading the Jenkins plugin
  grunt.loadNpmTasks('grunt-jenkins');


  // Tell Grunt to register our custom tasks
  grunt.registerTask(
    'default',
    'Basic build for development purpose that copies all the source files to dist directory',
    [ 'clean:build','copy:vendor','copy:scripts','copy:html','copy:partials',
      'copy:stylesheets','copy:images','replace:defaultCacheBustVer']
  );

  grunt.registerTask(
    'server',
    'Start static web server "nodejs connect middleware",watch for file changes and enables live reload of changes to browser',
    [ 'connect','watch']
  );

  grunt.registerTask(
   'reports',
   'Scans source code to generate quality reports',
    ['clean:reports','concurrent:staticCodeAnalyzer','concurrent:qualityReports',
     'concurrent:jsdocs','concurrent:perfMetrics']
  );

  grunt.registerTask(
   'precompress',
   'Precompressing (Gzip or Deflate) static files like js,css and html',
    ['compress','clean:gzstylesheets','clean:gzscripts','clean:gzhtml','clean:gzvendor']
  );

  grunt.registerTask(
    'unit-test',
    'Execute unit testing, code coverage & test reports using Jasmine & Karma',
    [ 'clean:unittestreports','karma']
  );

  grunt.registerTask(
    'e2e-test',
    'Execute E2E testing & generates test reports using Protractor',
    [ 'clean:e2etestreports','mkdir:e2etestxmlreports','protractor']
  );

  grunt.registerTask(
    'e2e-test-coverage',
    'Execute E2E testing, generates coverage and test reports using protractor',
    ['clean:instrumented','clean:e2ecoveragereports','mkdir:e2ecoveragexmlreports','instrument',
    'copy:coverageE2E','protractor_coverage','makeReport']
  );

  grunt.registerTask(
    'test',
    'Execute both unit testing and E2E testing with code coverage using Jasmine, Karma and Protractor',
    [ 'unit-test','e2e-test','e2e-test-coverage']
  );

  grunt.registerTask(
   'base-build',
   'Base E2E integration build for other  environments - Dev-int,Nightly, QA & Production',
    [ 'clean:build','copy:vendor','copy:scripts','copy:html','useminPrepare','uncss','autoprefixer',
      'htmlmin:partials','cssmin','requirejs','uglify','usemin','dom_munger:release','htmlmin:index',
      'clean:scripts','clean:stylesheets','imagemin','manifest']
  );

  grunt.registerTask(
      'on-commit',
      'On every file commit,executes default build and unit testing',
      [ 'default','unit-test']
  );

  grunt.registerTask(
    'dev-int',
    'Development integration build for development integration  environment',
    [ 'base-build','replace:devCacheBustVer']
  );

  grunt.registerTask(
   'nightly',
   'Development Integration Build for development integration environment',
    [ 'base-build','replace:releaseCacheBustVer','reports','test']
  );

  grunt.registerTask(
    'qa',
    'Build for QA release',
    [ 'base-build','replace:releaseCacheBustVer']
  );

  grunt.registerTask(
    'prod',
    'Build for production release ',
      ['ngtemplates','base-build','clean:partials','replace:releaseCacheBustVer','precompress']
  );

};